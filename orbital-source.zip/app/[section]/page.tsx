import { Suspense } from "react";
import { notFound } from "next/navigation";
import { LaunchesPage } from "@/features/launches";
import { CalendarPage } from "@/features/calendar";
import { MapPage } from "@/features/map";
import { StatisticsPage } from "@/features/statistics";
import { RocketsPage, AgenciesPage, ComparePage } from "@/features/catalog";
import { FollowingPage, TodayPage, SettingsPage } from "@/features/personal";
import { SourcesPage } from "@/features/sources";
const pages: Record<string, React.ComponentType> = {
  launches: LaunchesPage,
  calendar: CalendarPage,
  map: MapPage,
  statistics: StatisticsPage,
  rockets: RocketsPage,
  agencies: AgenciesPage,
  following: FollowingPage,
  today: TodayPage,
  settings: SettingsPage,
  sources: SourcesPage,
  compare: ComparePage,
};
export function generateStaticParams() {
  return Object.keys(pages).map((section) => ({ section }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  return {
    title:
      section === "map"
        ? "Global Launch Sites"
        : section.charAt(0).toUpperCase() + section.slice(1),
    description:
      "Explore " + section + " on ORBITAL, the global space launch tracker.",
  };
}
export default async function Page({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  const Component = pages[section];
  if (!Component) notFound();
  return (
    <Suspense
      fallback={
        <div className="page-container">
          <div className="skeleton skeleton-hero" />
        </div>
      }
    >
      <Component />
    </Suspense>
  );
}
