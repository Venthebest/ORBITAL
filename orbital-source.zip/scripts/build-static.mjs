import {
  existsSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";

const runtimeRoutes = [
  [resolve("app/api/launch"), resolve(".sites-api-launch")],
  [resolve("app/api/launches/more"), resolve(".sites-api-more")],
];
function build() {
  for (const [route, parked] of runtimeRoutes) {
    if (!existsSync(route)) throw new Error(`Expected runtime route: ${route}`);
    if (existsSync(parked)) throw new Error(`Staging path exists: ${parked}`);
  }
  rmSync(resolve(".next"), { recursive: true, force: true });
  for (const [route, parked] of runtimeRoutes) renameSync(route, parked);
  try {
    const result = spawnSync(
      process.execPath,
      ["node_modules/next/dist/bin/next", "build"],
      {
        stdio: "inherit",
        env: {
          ...process.env,
          SITES_STATIC_EXPORT: "1",
          NEXT_PUBLIC_STATIC_DEPLOY: "1",
        },
      },
    );
    if (result.error) throw result.error;
    return result.status === 0;
  } finally {
    for (const [route, parked] of [...runtimeRoutes].reverse())
      renameSync(parked, route);
  }
}

if (!build()) process.exitCode = 1;
else {
  const output = resolve("out/api/launches"),
    client = resolve("data/client-snapshot.json"),
    latest = readFileSync(output);
  if (!existsSync(client) || !latest.equals(readFileSync(client))) {
    const temporary = client + ".tmp";
    writeFileSync(temporary, latest);
    renameSync(temporary, client);
    console.log("Client snapshot synchronized; rebuilding static output.");
    if (!build()) process.exitCode = 1;
  }
}
