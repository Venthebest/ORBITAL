"use client";
import Link from "next/link";
import { useOrbital } from "@/components/app-provider";
import { SourceLink } from "@/components/ui";
import { formatDate, formatTime, isUpcoming } from "@/lib/time";
import { useYearStatistics } from "@/hooks/use-year-statistics";
export function SourcesPage() {
  const yearStats = useYearStatistics();
  const { data, t } = useOrbital();
  return (
    <div className="page-container sources-page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">CONFIDENCE STARTS WITH TRANSPARENCY</div>
          <h1>
            {t("Data & sources")}
            <span className="accent">.</span>
          </h1>
          <p>Real missions. Clear provenance. Honest uncertainty.</p>
        </div>
      </div>
      <div className="coverage-strip">
        <div>
          <strong>{data.launches.filter(isUpcoming).length}</strong>
          <span>Upcoming records loaded</span>
        </div>
        <div>
          <strong>{data.launches.filter((l) => !isUpcoming(l)).length}</strong>
          <span>Recent records loaded</span>
        </div>
        <div>
          <strong>{data.pads.length}</strong>
          <span>Launch pads & locations</span>
        </div>
      </div>
      <section className="source-policy">
        <h2>The Space Devs · Launch Library 2</h2>
        <p>
          ORBITAL uses Launch Library 2, a curated global spaceflight database,
          as its primary mission schedule, rocket, agency and launch pad source.
          The internal provider normalizes all records into a consistent schema,
          validates them, preserves provenance and deduplicates by mission ID.
        </p>
        <p style={{ marginTop: 14 }}>
          Last successful data fetch: {formatDate(data.fetchedAt, "UTC")} ·{" "}
          {formatTime(data.fetchedAt, "UTC")}.{" "}
          {data.mode === "live"
            ? "Live source data is available."
            : "The verified local snapshot is currently displayed."}
        </p>
        <SourceLink url="https://thespacedevs.com/llapi">
          Launch Library 2
        </SourceLink>
        <span style={{ margin: "0 10px" }} />
        <SourceLink url="https://ll.thespacedevs.com/docs/">
          API documentation
        </SourceLink>
      </section>
      <section className="source-policy">
        <h2>Official mission sources</h2>
        <p>
          Mission records include official sources and external updates when
          provided by the database. Every task detail page exposes its own
          source links, source priority, confidence and update timestamp.
          Official NASA, ESA and launch provider updates rank ahead of database
          or independent references when a verified adapter supplies an explicit
          update.
        </p>
        <div className="stream-list">
          {[
            { name: "NASA", url: "https://www.nasa.gov/" },
            { name: "SpaceX", url: "https://www.spacex.com/" },
            { name: "ESA", url: "https://www.esa.int/" },
            { name: "Rocket Lab", url: "https://www.rocketlabcorp.com/" },
            { name: "ULA", url: "https://www.ulalaunch.com/" },
            { name: "ISRO", url: "https://www.isro.gov.in/" },
            { name: "JAXA", url: "https://global.jaxa.jp/" },
          ].map((s) => (
            <SourceLink key={s.name} url={s.url}>
              {s.name}
            </SourceLink>
          ))}
        </div>
        <p className="settings-note">
          Official websites are linked for verification. ORBITAL does not claim
          separate live NASA, SpaceX or ESA feeds where no integrated structured
          endpoint exists.
        </p>
      </section>
      <section className="source-policy">
        <h2>Time precision & launch status</h2>
        <ul>
          <li>
            All timestamps are stored as UTC and formatted with the Intl API
            using an IANA time zone.
          </li>
          <li>
            Exact countdowns require second- or minute-level precision. Day,
            month, quarter and year targets are never presented as precise
            countdowns.
          </li>
          <li>
            NET means “No Earlier Than”. TBD and TBC retain source uncertainty.
          </li>
          <li>
            HOLD pauses the countdown. Passing T−0 does not automatically
            declare liftoff.
          </li>
          <li>
            Success, partial success and failure come from reported mission
            status, not a clock or an animation.
          </li>
          <li>
            Planned timeline events remain marked “Scheduled”. No simulated
            telemetry is displayed.
          </li>
        </ul>
      </section>
      <section className="source-policy">
        <h2>Coverage & statistics</h2>
        <p>
          The source currently lists {data.upcomingTotal.toLocaleString()}{" "}
          upcoming missions and {data.pastTotal.toLocaleString()} historical
          missions. This installation loads the first 100 upcoming and the most
          recent 100 historical records for responsive discovery. Full-archive
          counts are distinct from loaded-sample charts.
        </p>
        <p style={{ marginTop: 14 }}>
          The {yearStats.year} global annual orbital totals ({yearStats.total}{" "}
          attempts; {yearStats.success} confirmed successful) were queried
          separately on {formatDate(yearStats.fetchedAt, "UTC")}. Annual success
          requires Launch Library status 3 and excludes partial failures and
          suborbital launches. Country, rocket, agency and orbit charts describe
          only the loaded recent sample.
        </p>
        <SourceLink url={yearStats.sourceUrl}>
          Annual orbital attempt query
        </SourceLink>
        <span style={{ margin: "0 10px" }} />
        <SourceLink url={yearStats.sourceUrl + "&status=3"}>
          Annual success query
        </SourceLink>
      </section>
      <section className="source-policy">
        <h2>Cache, refresh & availability</h2>
        <p>
          The anonymous Launch Library API has a limited hourly request quota.
          ORBITAL shares a ten-minute server cache for upcoming launches and
          caches historical data for 24 hours. A configured API token enables
          shorter refresh intervals during launch windows. Failed requests
          preserve the last successful dataset and display a visible update
          notice.
        </p>
        <p style={{ marginTop: 14 }}>
          Offline mode uses previously cached application resources and launch
          data. Device-local follows and reminders stay in your browser. Current
          reminders are checked while the app is open; background push delivery
          is not implemented.
        </p>
      </section>
      <section className="source-policy">
        <h2>Imagery & map attribution</h2>
        <p>
          The dashboard Earth photograph is NASA ISS image iss072e340644. The
          Falcon 9 reference photograph is NASA / Keegan Barber,
          NHQ202409270003, depicting the Crew-9 vehicle. Mission photographs and
          agency logos are attributed to their sources; their image licenses are
          independent of the API license and must be checked before commercial
          redistribution.
        </p>
        <div className="stream-list">
          <SourceLink url="https://images.nasa.gov/details/iss072e340644">
            Earth image · NASA
          </SourceLink>
          <SourceLink url="https://images.nasa.gov/details/NHQ202409270003">
            Falcon 9 · NASA / Keegan Barber
          </SourceLink>
          <SourceLink url="https://www.nasa.gov/nasa-brand-center/images-and-media/">
            NASA media guidelines
          </SourceLink>
          <SourceLink url="https://www.naturalearthdata.com/">
            Natural Earth map data
          </SourceLink>
          <SourceLink url="https://maplibre.org/">MapLibre</SourceLink>
        </div>
      </section>
      <Link href="/launches" className="button secondary">
        Explore the launch schedule
      </Link>
    </div>
  );
}
