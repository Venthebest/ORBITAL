"use client";
import { useEffect } from "react";
import { Logo } from "@/components/ui";
export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <div className="page-container">
      <div className="empty-state">
        <Logo small />
        <h1 style={{ fontSize: 28 }}>A brief interruption.</h1>
        <p>
          Unable to render this view. Your saved preferences remain on this
          device.
        </p>
        <button className="button secondary" onClick={reset}>
          Try again
        </button>
      </div>
    </div>
  );
}
