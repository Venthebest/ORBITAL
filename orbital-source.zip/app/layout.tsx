import type { Metadata, Viewport } from "next";
import { AppProvider } from "@/components/app-provider";
import { Shell } from "@/components/shell";
import { snapshot } from "@/services/launch-service";
import "./globals.css";
export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
  ),
  title: {
    default: "ORBITAL — Global Space Launch Tracker",
    template: "%s | ORBITAL",
  },
  description:
    "Explore the global space launch schedule, follow missions, discover rockets and track the next launch with transparent sources and precise time handling.",
  applicationName: "ORBITAL",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/favicon.svg", apple: "/icon-192.png" },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "ORBITAL",
  },
  openGraph: {
    title: "ORBITAL — Global Space Launch Tracker",
    description: "A global perspective on what comes next.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ORBITAL — Global Space Launch Tracker",
  },
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#090b10",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" data-theme="dark" suppressHydrationWarning>
      <body>
        <AppProvider
          initialData={
            process.env.SITES_STATIC_EXPORT === "1" ? undefined : snapshot
          }
        >
          <Shell>{children}</Shell>
        </AppProvider>
      </body>
    </html>
  );
}
