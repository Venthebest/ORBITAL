# ORBITAL

全球航天发射检索与跟踪产品。Next.js 16、React 19、TypeScript、TanStack Query、Zod、MapLibre、Recharts、Radix UI。默认深色，独立品牌与响应式设计；所有时间由 Intl / IANA 时区格式化。

## 运行

在项目目录中执行：

```bash
npm ci
npm run dev
```

打开 http://localhost:3000 。Node.js ≥20.9；推荐 Node.js 24 LTS。

```bash
npm run typecheck
npm run lint
npm run build
npm start
npx playwright install chromium
npm run test:e2e
```

本次验收已通过 TypeScript、ESLint 和生产构建；5 项 Playwright 回归全部通过，包括组合筛选、日期精度、收藏提醒与 ICS、键盘搜索、地图选择，以及 320px / Auckland 时区日历。生产版另实测地图聚合、全屏倒计时和 PWA 离线页面。

在本次云工作区，网络通过代理；启动时可使用 `NODE_USE_ENV_PROXY=1 npm run dev`（Node 24）。普通部署环境无需此设置。

## 功能

- 首页、Today、未来/历史日程、任务详情、火箭及机构列表/详情、全球地图、日历、收藏、统计、来源和设置。
- 日程 List / Timeline / Calendar，搜索、组合筛选及 URL 同步；可按需从原始数据库加载更远期及更早历史任务。
- Cmd/Ctrl+K 分组搜索，方向键、Enter、Esc；任务描述涵盖载荷关键字。
- 秒级真实倒计时、HOLD 暂停、TBD/TBC/NET、季度/半年/年精度，T−0 后等待官方状态更新。
- 来源提供的计划时间线、天气预报、任务图片、官方/独立直播区分；没有模拟遥测。
- Launch / Rocket / Agency 收藏、提醒配置、状态与时间变化提醒；本机持久化。
- ICS 下载（Apple Calendar/Outlook）与 Google Calendar；Web Share / 复制链接。
- MapLibre 地球地图、真实发射场坐标、自定义控制器、搜索、定位和任务面板；地图无需 API 密钥。
- 月/周/议程日历、年度轨道总量与独立标注的样本图表、三车比较。
- Dark / Light / System、UTC / Local / Launch Site、Metric / Imperial、减少动画；英文完整，中文为部分界面翻译。
- PWA 图标、manifest、生产 Service Worker、离线缓存、Skeleton、空状态、错误边界、键盘与 safe-area 支持。
- 动态任务 SEO / OpenGraph / Twitter、JSON-LD、robots、sitemap、JSON API；实验性 WebMCP 搜索/关注适配（仅支持该 API 的浏览器）。

## 真实数据与边界

目录之外的火箭与机构详情可按 ID 从来源检索，记录独立缓存三天。

主数据为 The Space Devs [Launch Library 2](https://thespacedevs.com/llapi)，生产 API v2.3.0。初始真实快照于 **2026-09-30 16:16:52 UTC** 抓取：100 个未来任务、100 个历史任务；火箭配置和机构由这些真实记录提取，地球发射场位置由 locations API 补充。NASA/ESA 组织简介有明确官方参考来源。

年度轨道发射总量来自独立计数请求；运行时每日重新查询并保留最后可靠快照。任务级官方链接、图片来源及更新时间随数据保留。NASA 提供 Earth Hero 与 Falcon 9 参考照片，Natural Earth 提供本地地图地理数据；字体使用 OFL 授权。

匿名 LL2 通常限制 **15 请求/小时**。未来任务共享缓存 10 分钟，历史 24 小时，临近发射时近期历史请求加快以跟踪状态变化；配置付费/授权 token 时未来数据可缩短到90秒。追加历史/未来页按需请求并缓存，源不可用时保留已载入任务。浏览器刷新不会无条件绕过服务端限流保护。

代码默认使用 Next Data Cache 加每实例的请求去重。Vercel 的托管 Data Cache 能共享缓存；自托管多副本或不同适配器需配置共享缓存处理器/KV/Redis，才能对所有副本统一控制请求配额。

当前提醒需要页面保持运行。未实现账户、跨设备同步、后台 Web Push、真实遥测、独立 NASA/SpaceX 实时数据流。精确提醒和日历导出仅在时间精度足够时执行。直播是否能播放取决于官方平台与用户网络。LL2 任务图片部分有非商业或不明许可；商用上线前请确认使用权或换成获准的官方资产。载荷质量、机构总部或火箭统计缺失时明确显示未公布。

日期不精确的任务不进入按日的日历或 Today；状态改变只能来自数据源。统计图表描述当前载入样本，年度全局总量单独说明。追加分页不代表所有筛选结果已在本地下载；覆盖与已载入数量会明确显示。

## 数据流程

`fetch → normalize → validate → cache → merge → deduplicate`

`LaunchProvider` 是数据入口契约；`LaunchLibraryProvider` 负责 API，`OfficialSourceProvider` 支持明确、已核实的官方字段覆盖。UI 使用内部类型，不依赖 LL2 JSON。Source 包含 priority / confidence / URL / updatedAt。机构关联只采用运营商身份和明确列出的任务参与机构，不把计划的所有成员推断为具体任务参与者。缺失坐标保持 null，月球位置不进入地球地图。

```bash
# 原子刷新部署附带的真实性快照；失败不会覆盖旧文件。
npm run data:refresh
```

## 部署

Vercel：导入此目录，框架选 Next.js。Netlify：使用仓库中的 `netlify.toml` 与平台官方 Next.js 适配器。构建命令 `npm run build`。

可选环境变量：

- `NEXT_PUBLIC_SITE_URL`：生产域名，用于 canonical metadata、robots 和 sitemap。生产环境必须配置。
- `LL2_API_TOKEN`：仅服务端读取，可选；勿写进任何 NEXT_PUBLIC 变量。

这是包含运行时 API 的完整 Next.js 应用，不能直接作为纯静态目录上传到 Cloudflare Pages。Cloudflare 部署应使用兼容当前 Next.js 版本的 OpenNext Cloudflare Workers 适配器；该适配器尚未验证。普通 Node 服务器可以使用 `npm run build && npm start`。

Sites 共享版使用经过验证的发布时快照，并保留搜索、筛选、详情、地图、收藏、提醒和离线体验。运行 `NEXT_PUBLIC_SITE_URL=https://your-domain.example npm run build:sites` 会生成 `out/`；构建脚本会同步唯一的客户端快照并在数据变化时自动重建。运行时 API、源分页及后台刷新仍由完整 Node/Vercel/Netlify 部署提供。

已发布的共享版：[ORBITAL](https://orbital-launch-tracker.venyh.chatgpt.site)。

## 主要结构

```text
app/          路由、动态 metadata、API、错误/加载页面
components/   导航、控件、卡片、倒计时、应用状态
features/     各产品页面与业务交互
providers/    可替换的数据源接口与实现
adapters/     外部 JSON → 内部统一模型
services/     合并、去重、服务端缓存、年度计数
hooks/        查询与浏览器能力适配
lib/          日期、日历导出、翻译、HTTP、客户端合并
types/        严格类型与校验
data/         带来源的真实快照、目录、图像归属
public/       图像、字体、地理数据、图标、PWA、地图 worker
scripts/      快照刷新与地图 worker 同步
tests/        核心交互与精度的 Playwright 回归
```
