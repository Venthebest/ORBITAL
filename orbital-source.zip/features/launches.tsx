"use client";
import { useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Search, List, AlignLeft, CalendarDays, X } from "lucide-react";
import { useOrbital } from "@/components/app-provider";
import { Picker, Segment, EmptyState } from "@/components/ui";
import { LaunchCard, LaunchRow } from "@/components/launch-card";
import { DatePicker } from "@/components/date-picker";
import {
  dateKey,
  isUpcoming,
  hasConfirmedDay,
  calendarWeekRange,
  zoneFor,
  statusLabel,
  formatDate,
} from "@/lib/time";
import type { Launch } from "@/types";
import { CalendarView } from "./calendar";
const staticDeploy = process.env.NEXT_PUBLIC_STATIC_DEPLOY === "1";
const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
export function LaunchesPage() {
  const { data, settings, now, t, loadMore, loadingMore } = useOrbital(),
    params = useSearchParams(),
    router = useRouter(),
    [limit, setLimit] = useState(30);
  const query = params.get("search") || "",
    range = params.get("range") || "upcoming",
    view = params.get("view") || "list";
  const set = (key: string, val: string) => {
    const p = new URLSearchParams(params);
    if (val) p.set(key, val);
    else p.delete(key);
    router.replace("/launches" + (p.size ? "?" + p.toString() : ""), {
      scroll: false,
    });
    setLimit(30);
  };
  const filters = [
    "date",
    "agency",
    "country",
    "rocket",
    "site",
    "orbit",
    "type",
    "status",
  ];
  const launches = useMemo(
    () =>
      data.launches
        .filter((l) => {
          if (range === "upcoming" && !isUpcoming(l)) return false;
          if (range === "archive" && isUpcoming(l)) return false;
          const q = query.toLowerCase();
          if (
            q &&
            !`${l.name} ${l.description} ${l.agency.name} ${l.launchPad.location} ${l.launchPad.name}`
              .toLowerCase()
              .includes(q)
          )
            return false;
          const match = (k: string, ...values: string[]) =>
            !params.get(k) ||
            values.some((v) => slug(v) === slug(params.get(k)!));
          if (
            !match(
              "agency",
              l.agency.id,
              l.agency.name,
              l.agency.abbrev,
              ...(l.mission.agencyIds || []).flatMap((id) => {
                const a = data.agencies.find((a) => a.id === id);
                return [id, a?.name || "", a?.abbrev || ""];
              }),
            ) ||
            !match("country", l.launchPad.countryCode, l.country) ||
            !match("rocket", l.rocket.id, l.rocket.name) ||
            !match(
              "site",
              l.launchPad.id,
              l.launchPad.name,
              l.launchPad.location,
            ) ||
            !match("orbit", l.orbit) ||
            !match("type", l.mission.type) ||
            !match(
              "status",
              l.status,
              l.status === "go" ? "confirmed" : l.status,
            )
          )
            return false;
          const date = params.get("date");
          if (date) {
            if (!hasConfirmedDay(l)) return false;
            const tz = zoneFor(settings, l),
              today = dateKey(new Date(now), tz),
              day = dateKey(l.net!, tz);
            const tomorrow = new Date(today + "T12:00:00Z");
            tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
            if (date === "today" && day !== today) return false;
            if (
              date === "tomorrow" &&
              day !== tomorrow.toISOString().slice(0, 10)
            )
              return false;
            if (date === "week") {
              const w = calendarWeekRange(now, tz);
              if (day < w.start || day > w.end) return false;
            }
            if (date === "month" && day.slice(0, 7) !== today.slice(0, 7))
              return false;
            if (
              date === "30days" &&
              (day < today || Date.parse(l.net!) > now + 30 * 86400000)
            )
              return false;
            if (
              date === "custom" &&
              ((params.get("start") && day < params.get("start")!) ||
                (params.get("end") && day > params.get("end")!))
            )
              return false;
          }
          return true;
        })
        .sort(
          (a, b) =>
            (range === "archive" ? -1 : 1) *
            (Date.parse(a.net || "9999-01-01") -
              Date.parse(b.net || "9999-01-01")),
        ),
    [data, params, query, range, settings, now],
  );
  const options = (
    kind:
      "agency" | "country" | "rocket" | "site" | "orbit" | "type" | "status",
  ) => {
    if (kind === "agency")
      return [
        { label: "All agencies", value: "" },
        ...data.agencies
          .filter((a) => a.id !== "unknown")
          .sort((a, b) => a.name.localeCompare(b.name))
          .map((a) => ({ label: a.name, value: slug(a.name) })),
      ];
    if (kind === "country")
      return [
        { label: "All countries", value: "" },
        ...Array.from(
          new Map(data.pads.map((p) => [p.countryCode, p])).values(),
        )
          .sort((a, b) => a.country.localeCompare(b.country))
          .map((p) => ({
            label: p.country,
            value: p.countryCode.toLowerCase(),
          })),
      ];
    if (kind === "rocket")
      return [
        { label: "All rockets", value: "" },
        ...[...data.rockets]
          .sort((a, b) => a.name.localeCompare(b.name))
          .map((r) => ({ label: r.name, value: r.id })),
      ];
    if (kind === "site")
      return [
        { label: "All launch sites", value: "" },
        ...[...data.pads]
          .sort((a, b) => a.location.localeCompare(b.location))
          .map((p) => ({
            label: p.location.split(",")[0] + " · " + p.name,
            value: p.id,
          })),
      ];
    if (kind === "orbit")
      return [
        { label: "All orbits", value: "" },
        ...Array.from(new Set(data.launches.map((l) => l.orbit)))
          .sort()
          .map((o) => ({ label: o, value: o.toLowerCase() })),
      ];
    if (kind === "type")
      return [
        { label: "All types", value: "" },
        ...Array.from(new Set(data.launches.map((l) => l.mission.type)))
          .sort()
          .map((o) => ({ label: o, value: slug(o) })),
      ];
    return [
      { label: "All statuses", value: "" },
      ...Object.entries(statusLabel).map(([value, label]) => ({
        value,
        label,
      })),
    ];
  };
  const visible = launches.slice(0, limit);
  const groups = visible.reduce<Record<string, Launch[]>>((groups, l) => {
    const day = hasConfirmedDay(l)
      ? dateKey(l.net!, zoneFor(settings, l))
      : "UNCONFIRMED";
    (groups[day] ||= []).push(l);
    return groups;
  }, {});
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">THE GLOBAL MANIFEST</div>
          <h1>
            {t("Launches")}
            <span className="accent">.</span>
          </h1>
          <p>Every mission. Every launch window. One clear perspective.</p>
        </div>
        <Segment
          value={range}
          options={[
            { label: "Upcoming", value: "upcoming" },
            { label: "Archive", value: "archive" },
          ]}
          onChange={(v) => set("range", v)}
        />
      </div>
      <section className="filter-surface" aria-label="Launch filters">
        <div className="filter-top">
          <div className="filter-search">
            <Search size={18} />
            <input
              aria-label="Search launch schedule"
              placeholder="Search mission, vehicle, or launch site…"
              value={query}
              onChange={(e) => set("search", e.target.value)}
            />
          </div>
          <Segment
            value={view}
            onChange={(v) => set("view", v)}
            options={[
              { value: "list", label: "List", icon: <List size={14} /> },
              {
                value: "timeline",
                label: "Timeline",
                icon: <AlignLeft size={14} />,
              },
              {
                value: "calendar",
                label: "Calendar",
                icon: <CalendarDays size={14} />,
              },
            ]}
          />
        </div>
        <div className="filters">
          <Picker
            label="Date"
            value={params.get("date") || ""}
            onChange={(v) => set("date", v)}
            options={[
              { value: "", label: "Any time" },
              { value: "today", label: "Today" },
              { value: "tomorrow", label: "Tomorrow" },
              { value: "week", label: "This week" },
              { value: "month", label: "This month" },
              { value: "30days", label: "Next 30 days" },
              { value: "custom", label: "Custom dates" },
            ]}
          />
          {(
            [
              "agency",
              "country",
              "rocket",
              "site",
              "orbit",
              "type",
              "status",
            ] as const
          ).map((k) => (
            <Picker
              key={k}
              label={k}
              value={params.get(k) || ""}
              options={options(k)}
              onChange={(v) => set(k, v)}
            />
          ))}
          {filters.some((k) => params.has(k)) && (
            <button
              className="button ghost"
              onClick={() =>
                router.replace("/launches?range=" + range + "&view=" + view, {
                  scroll: false,
                })
              }
            >
              <X size={14} />
              {t("Clear filters")}
            </button>
          )}
        </div>
        {params.get("date") === "custom" && (
          <div className="custom-range">
            <span className="eyebrow">FROM</span>
            <DatePicker
              label="Start date"
              value={params.get("start") || ""}
              onChange={(v) => set("start", v)}
            />
            <span className="eyebrow">TO</span>
            <DatePicker
              label="End date"
              value={params.get("end") || ""}
              onChange={(v) => set("end", v)}
            />
          </div>
        )}
      </section>
      <div className="result-bar">
        <span>
          {launches.length} missions{" "}
          <span>
            · {range === "archive" ? "recent archive" : "loaded schedule"}
          </span>
        </span>
        <span>
          {settings.timezone === "utc"
            ? "All times in UTC"
            : settings.timezone === "site"
              ? "Launch site time zones"
              : "Your local time zone"}{" "}
          · Dates may change
        </span>
      </div>
      {!launches.length ? (
        <EmptyState
          action={
            <button
              className="button secondary"
              onClick={() => router.replace("/launches")}
            >
              {t("Clear filters")}
            </button>
          }
        />
      ) : view === "calendar" ? (
        <CalendarView launches={launches} />
      ) : view === "timeline" ? (
        <div className="schedule-timeline">
          {Object.entries(groups).map(([day, missions]) => (
            <section className="timeline-day" key={day}>
              <div className="timeline-day-label">
                {day === "UNCONFIRMED"
                  ? "Date not confirmed"
                  : formatDate(day + "T12:00:00Z", "UTC", {
                      month: "short",
                      day: "numeric",
                      weekday: "short",
                    })}
                <small>{missions?.length} missions</small>
              </div>
              <div className="launch-table">
                {missions?.map((l) => (
                  <LaunchRow launch={l} key={l.id} />
                ))}
              </div>
            </section>
          ))}
        </div>
      ) : (
        <div className="launch-table">
          {visible.map((l) => (
            <LaunchRow launch={l} key={l.id} />
          ))}
        </div>
      )}
      {view !== "calendar" && launches.length > limit && (
        <div className="result-load">
          <button
            className="button secondary"
            onClick={() => setLimit((v) => v + 30)}
          >
            Load more missions · {launches.length - limit} remaining
          </button>
        </div>
      )}
      {!staticDeploy &&
        (data.pageOffsets?.[range as "upcoming" | "archive"] || 100) <
          (range === "archive" ? data.pastTotal : data.upcomingTotal) && (
          <div className="result-load">
            <button
              className="button secondary"
              disabled={loadingMore}
              onClick={() =>
                loadMore(range === "archive" ? "archive" : "upcoming")
              }
            >
              {loadingMore
                ? "Retrieving verified missions…"
                : range === "archive"
                  ? "Load older missions from source"
                  : "Load further missions from source"}
            </button>
          </div>
        )}
      <p className="settings-note">
        Coverage: {data.upcomingTotal} upcoming missions in the source archive;{" "}
        {data.launches.filter(isUpcoming).length} loaded here. Historical
        results cover the {data.launches.filter((l) => !isUpcoming(l)).length}{" "}
        most recently retrieved missions.
      </p>
    </div>
  );
}
export function LaunchGrid({ launches }: { launches: Launch[] }) {
  return (
    <div className="mission-grid schedule-grid">
      {launches.map((l) => (
        <LaunchCard key={l.id} launch={l} />
      ))}
    </div>
  );
}
