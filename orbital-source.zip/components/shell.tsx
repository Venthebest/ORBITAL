"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import * as Popover from "@radix-ui/react-popover";
import {
  Search,
  Command,
  RefreshCw,
  Star,
  LayoutGrid,
  Rocket,
  Globe2,
  ChartNoAxesCombined,
  CalendarDays,
  Sun,
  Ellipsis,
  Settings,
  Satellite,
  ArrowUpRight,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useWebMCP } from "@/hooks/use-webmcp";
import { useOrbital } from "./app-provider";
import { Logo } from "./ui";
import { ago, formatDate, formatTime } from "@/lib/time";
import { CommandPalette } from "@/features/search";
const nav = [
  { href: "/", label: "Overview", icon: LayoutGrid },
  { href: "/launches", label: "Launches", icon: Rocket },
  { href: "/map", label: "Launch sites", icon: Globe2 },
  { href: "/statistics", label: "Statistics", icon: ChartNoAxesCombined },
];
const more = [
  { href: "/today", label: "Today", icon: Sun },
  { href: "/calendar", label: "Calendar", icon: CalendarDays },
  { href: "/rockets", label: "Rockets", icon: Rocket },
  { href: "/agencies", label: "Agencies", icon: Satellite },
  { href: "/following", label: "Following", icon: Star },
  { href: "/settings", label: "Settings", icon: Settings },
  { href: "/sources", label: "Data & sources", icon: Globe2 },
];
export function Shell({ children }: { children: React.ReactNode }) {
  useWebMCP();
  const path = usePathname(),
    { t, data, now, refresh, refreshing, online } = useOrbital(),
    [search, setSearch] = useState(false);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearch((v) => !v);
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, []);
  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <header className="site-header">
        <div className="header-inner">
          <Link href="/" aria-label="ORBITAL home">
            <Logo />
          </Link>
          <nav className="desktop-nav" aria-label="Main navigation">
            {nav.map((n) => (
              <Link
                href={n.href}
                key={n.href}
                className={path === n.href ? "active" : ""}
              >
                {t(n.label)}
              </Link>
            ))}
            <MoreMenu path={path} />
          </nav>
          <div className="header-tools">
            <button
              className="search-trigger"
              onClick={() => setSearch(true)}
              aria-label="Search"
            >
              <Search size={17} />
              <span>{t("Search")}</span>
              <kbd>
                <Command size={10} /> K
              </kbd>
            </button>
            <Link
              href="/following"
              className={`icon-button ${path === "/following" ? "selected" : ""}`}
              aria-label="Following"
            >
              <Star size={18} />
            </Link>
            <Link
              href="/settings"
              className="profile-button"
              aria-label="Settings"
            >
              <span>O</span>
            </Link>
          </div>
        </div>
      </header>
      <div className="data-bar">
        <span className="data-status">
          <i className={online ? "" : "offline"} />
          {online ? "LAUNCH NETWORK" : "OFFLINE CACHE"}
          <span className="data-divider">/</span>
          <span className="data-update">
            {data.mode === "live" ? "Updated" : "Snapshot"}{" "}
            {now === Date.parse(data.fetchedAt)
              ? formatTime(data.fetchedAt, "UTC")
              : ago(data.fetchedAt, now)}
          </span>
        </span>
        <button
          className="data-refresh"
          onClick={refresh}
          aria-label="Refresh data"
        >
          <RefreshCw size={12} className={refreshing ? "spinning" : ""} />
          <span>{refreshing ? "Updating" : t("Refresh data")}</span>
        </button>
      </div>
      {data.error && (
        <div className="data-notice" role="status">
          {data.error}{" "}
          <span>
            Last successful sync:{" "}
            {formatDate(data.fetchedAt, "UTC", {
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}{" "}
            UTC.
          </span>
          <button onClick={refresh}>Retry</button>
        </div>
      )}
      <main id="main">{children}</main>
      <footer className="site-footer">
        <Logo />
        <span>Keeping an eye on what comes next.</span>
        <div>
          <Link href="/sources">{t("Data & sources")}</Link>
          <span>All times subject to change</span>
          <span>© {new Date(now).getUTCFullYear()} ORBITAL</span>
        </div>
      </footer>
      <nav className="bottom-nav" aria-label="Mobile navigation">
        {[
          { href: "/today", label: "Today", icon: Sun },
          { href: "/launches", label: "Launches", icon: Rocket },
          { href: "/map", label: "Launch sites", icon: Globe2 },
          { href: "/following", label: "Following", icon: Star },
        ].map((n) => (
          <Link
            href={n.href}
            key={n.href}
            className={path === n.href ? "active" : ""}
          >
            <n.icon size={20} />
            <span>{t(n.label === "Launch sites" ? "Map" : n.label)}</span>
          </Link>
        ))}
        <MoreMenu path={path} mobile />
      </nav>
      <CommandPalette open={search} onOpenChange={setSearch} />
    </>
  );
}
function MoreMenu({
  path,
  mobile = false,
}: {
  path: string;
  mobile?: boolean;
}) {
  const { t } = useOrbital();
  return (
    <Popover.Root>
      <Popover.Trigger asChild>
        <button
          className={`more-trigger ${mobile ? "mobile" : ""}`}
          aria-label="More navigation"
        >
          {mobile ? (
            <>
              <Ellipsis size={22} />
              <span>{t("More")}</span>
            </>
          ) : (
            <Ellipsis size={19} />
          )}
        </button>
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content
          className="popover more-menu"
          sideOffset={12}
          align="end"
        >
          {(mobile ? nav.concat(more) : more).map((n) => (
            <Popover.Close asChild key={n.href}>
              <Link href={n.href} className={path === n.href ? "active" : ""}>
                <n.icon size={17} />
                {t(n.label)}
                <ArrowUpRight size={13} />
              </Link>
            </Popover.Close>
          ))}
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}
