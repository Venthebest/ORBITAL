import { fetchJSON } from "@/lib/http";
import {
  normalizeLaunch,
  normalizeResponse,
  source,
} from "@/adapters/launch-library";
import type { LaunchProvider } from "./types";
export class LaunchLibraryProvider implements LaunchProvider {
  name = "Launch Library 2";
  priority = 80;
  private base = "https://ll.thespacedevs.com/2.3.0";
  private headers(): HeadersInit {
    return process.env.LL2_API_TOKEN
      ? { Authorization: `Token ${process.env.LL2_API_TOKEN}` }
      : { Accept: "application/json" };
  }
  private async fetchSet(path: string) {
    const fetchedAt = new Date().toISOString();
    const raw = await fetchJSON(`${this.base}${path}`, {
      headers: this.headers(),
      cache: "no-store",
    });
    return {
      ...normalizeResponse(raw, fetchedAt),
      fetchedAt,
      source: source(`${this.base}${path}`, fetchedAt),
    };
  }
  fetchUpcoming() {
    return this.fetchSet("/launches/upcoming/?limit=100&mode=detailed");
  }
  fetchRecent() {
    return this.fetchSet("/launches/previous/?limit=100&mode=detailed");
  }
  fetchPage(range: "upcoming" | "archive", offset: number) {
    return this.fetchSet(
      `/launches/${range === "archive" ? "previous" : "upcoming"}/?limit=100&offset=${offset}&mode=detailed`,
    );
  }
  async fetchLaunch(id: string) {
    if (!/^[a-z0-9-]{1,80}$/i.test(id)) throw new Error("Invalid mission ID");
    const raw = await fetchJSON(
      `${this.base}/launches/${encodeURIComponent(id)}/?mode=detailed`,
      { headers: this.headers(), cache: "no-store" },
    );
    return normalizeLaunch(raw, new Date().toISOString());
  }
}
