import type {
  Agency,
  Launch,
  LaunchPad,
  LaunchStatus,
  Rocket,
  Source,
  TimelineEvent,
} from "@/types";
import { LaunchValidation } from "@/types";
type Raw = Record<string, unknown>;
const object = (v: unknown): Raw =>
  v && typeof v === "object" && !Array.isArray(v) ? (v as Raw) : {};
const list = (v: unknown): Raw[] => (Array.isArray(v) ? v.map(object) : []);
const string = (v: unknown, f = "") =>
  typeof v === "string" ? v : typeof v === "number" ? String(v) : f;
const num = (v: unknown): number | null =>
  v !== null && v !== undefined && v !== "" && Number.isFinite(Number(v))
    ? Number(v)
    : null;
const bool = (v: unknown) => (typeof v === "boolean" ? v : null);
function safeURL(v: unknown): string | null {
  const s = string(v);
  try {
    const u = new URL(s);
    return ["https:", "http:"].includes(u.protocol) ? s : null;
  } catch {
    return null;
  }
}
function image(v: unknown): string | null {
  return safeURL(typeof v === "string" ? v : object(v).image_url);
}
const countryNames: Record<string, string> = {
  USA: "United States",
  CHN: "China",
  RUS: "Russia",
  IND: "India",
  JPN: "Japan",
  NZL: "New Zealand",
  FRA: "France",
  GUF: "French Guiana",
  KAZ: "Kazakhstan",
  IRN: "Iran",
  KOR: "South Korea",
  GBR: "United Kingdom",
  ISR: "Israel",
  DEU: "Germany",
  ITA: "Italy",
  AUS: "Australia",
  CAN: "Canada",
};
function country(r: Raw) {
  const c = Array.isArray(r.country) ? object(r.country[0]) : object(r.country);
  const code =
    string(c.alpha_3_code) || string(r.country_code).split(",")[0] || "UNK";
  return { code, name: countryNames[code] || string(c.name) || code };
}
export function source(
  url: string,
  updated: string,
  name = "Launch Library 2",
  priority = 80,
): Source {
  return {
    name,
    sourceUrl: url,
    sourcePriority: priority,
    lastUpdated: updated,
    confidence: priority >= 80 ? "high" : "medium",
  };
}
export function normalizeAgency(input: unknown, updated: string): Agency {
  const r = object(input),
    c = country(r);
  return {
    id: string(r.id, "unknown"),
    name: string(r.name, "Unknown agency"),
    abbrev: string(r.abbrev),
    country: c.name,
    countryCode: c.code,
    description: string(r.description),
    type: string(object(r.type).name) || string(r.type, "Unknown"),
    founded: r.founding_year ? string(r.founding_year) : null,
    headquarters: string(r.headquarters) || null,
    website: safeURL(r.info_url),
    logo: image(r.logo) || image(r.logo_url),
    image: image(r.image) || image(r.image_url),
    sources: [
      source(safeURL(r.url) || "https://thespacedevs.com/llapi", updated),
    ],
  };
}
export function normalizeRocket(input: unknown, updated: string): Rocket {
  const r = object(input),
    m = Array.isArray(r.manufacturer)
      ? object(r.manufacturer[0])
      : object(r.manufacturer),
    c = country(m);
  return {
    id: string(r.id, "unknown"),
    name: string(r.full_name) || string(r.name, "Unknown rocket"),
    family: string(r.family) || string(list(r.families)[0]?.name),
    manufacturer: string(m.name, "Unknown"),
    country: c.name,
    description: string(r.description),
    image: image(r.image) || image(r.image_url),
    imageSource: safeURL(r.info_url) || safeURL(r.url),
    height: num(r.length),
    diameter: num(r.diameter),
    mass: num(r.launch_mass),
    stages: num(r.max_stage),
    leoCapacity: num(r.leo_capacity),
    gtoCapacity: num(r.gto_capacity),
    firstFlight: string(r.maiden_flight) || null,
    active: bool(r.active),
    reusable: bool(r.reusable),
    totalLaunches: num(r.total_launch_count),
    successfulLaunches: num(r.successful_launches),
    failedLaunches: num(r.failed_launches),
    sources: [
      source(safeURL(r.url) || "https://thespacedevs.com/llapi", updated),
    ],
  };
}
export function normalizePad(input: unknown, updated: string): LaunchPad {
  const r = object(input),
    loc = object(r.location),
    c = country(Object.keys(object(r.country)).length ? r : loc);
  let tz = string(loc.timezone_name, "UTC");
  try {
    new Intl.DateTimeFormat("en", { timeZone: tz });
  } catch {
    tz = "UTC";
  }
  return {
    id: string(r.id, "unknown"),
    name: string(r.name, "Unknown pad"),
    celestialBody: string(object(loc.celestial_body).name, "Unknown"),
    location: string(loc.name, "Unknown location"),
    country: c.name,
    countryCode: c.code,
    latitude: num(r.latitude),
    longitude: num(r.longitude),
    timezone: tz,
    totalLaunches: num(r.total_launch_count),
    mapUrl: safeURL(r.map_url),
    sources: [
      source(safeURL(r.url) || "https://thespacedevs.com/llapi", updated),
    ],
  };
}
function date(v: unknown) {
  const s = string(v);
  return s && !Number.isNaN(Date.parse(s)) ? new Date(s).toISOString() : null;
}
function offset(v: unknown) {
  const s = string(v);
  const m = s.match(
    /^(-)?P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?$/,
  );
  return m
    ? (m[1] ? -1 : 1) *
        (Number(m[2] || 0) * 86400 +
          Number(m[3] || 0) * 3600 +
          Number(m[4] || 0) * 60 +
          Number(m[5] || 0)) *
        1000
    : null;
}
export function normalizeLaunch(input: unknown, fetchedAt: string): Launch {
  const r = object(input),
    status = object(r.status),
    mission = object(r.mission),
    orbit = object(mission.orbit),
    net = date(r.net),
    updated = date(r.last_updated) || fetchedAt;
  const statuses: Record<number, LaunchStatus> = {
    1: "go",
    2: "tbd",
    3: "success",
    4: "failure",
    5: "hold",
    6: "in-flight",
    7: "partial-success",
    8: "tbc",
    9: "success",
  };
  const p = num(object(r.net_precision).id);
  const precision: Launch["precision"] =
    p === 0
      ? "second"
      : p === 1
        ? "minute"
        : p === 2
          ? "hour"
          : p === 3 || p === 4 || p === 5
            ? "day"
            : p === 6
              ? "week"
              : p === 7
                ? "month"
                : p !== null && p >= 8 && p <= 11
                  ? "quarter"
                  : p === 12 || p === 13
                    ? "half-year"
                    : p === 14 || p === 15
                      ? "year"
                      : p === 16
                        ? "decade"
                        : "unknown";
  const url =
    safeURL(r.url) ||
    `https://ll.thespacedevs.com/2.3.0/launches/${string(r.id)}/`;
  const updates = list(r.updates);
  const links = [
    ...list(r.infoURLs || r.info_urls).map((u) => safeURL(u.url)),
    ...updates.map((u) => safeURL(u.info_url)),
  ].filter((u): u is string => !!u);
  const sources = [
    source(url, updated),
    ...Array.from(new Set(links))
      .slice(0, 8)
      .map((u) => {
        const official =
          /\.(nasa\.gov|spacex\.com|esa\.int|isro\.gov\.in|jaxa\.jp)\b/.test(
            new URL(u).hostname,
          ) ||
          /^(www\.)?(nasa\.gov|spacex\.com|esa\.int|rocketlabusa\.com|ulalaunch\.com|blueorigin\.com)$/.test(
            new URL(u).hostname,
          );
        return source(
          u,
          updated,
          official ? "Official mission update" : "Mission reference",
          official ? 100 : 60,
        );
      }),
  ];
  const timeline: TimelineEvent[] = list(r.timeline).map((e, i) => {
    const t = object(e.type),
      ms = offset(e.relative_time);
    return {
      id: `event-${i}`,
      name: string(t.abbrev, "Scheduled event"),
      description: string(t.description),
      time:
        net && ms !== null
          ? new Date(Date.parse(net) + ms).toISOString()
          : null,
      kind: "scheduled",
      completed: false,
    };
  });
  const launch: Launch = {
    id: string(r.id),
    name: string(r.name),
    slug: string(r.slug),
    description: string(mission.description) || string(r.description),
    status: statuses[Number(status.id)] || "tbd",
    statusDescription: string(status.description),
    net,
    windowStart: date(r.window_start),
    windowEnd: date(r.window_end),
    precision,
    precisionLabel: string(object(r.net_precision).name, "Unconfirmed"),
    lastUpdated: updated,
    latestUpdate: updates.length
      ? {
          text: string(updates[0].comment),
          time: date(updates[0].created_on) || updated,
          sourceUrl: safeURL(updates[0].info_url),
        }
      : null,
    agency: normalizeAgency(r.launch_service_provider, updated),
    rocket: normalizeRocket(object(r.rocket).configuration, updated),
    mission: {
      agencyIds: [
        ...new Set(
          list(mission.agencies)
            .map((a) =>
              String(a.id) === "44"
                ? "nasa"
                : String(a.id) === "27"
                  ? "esa"
                  : string(a.id),
            )
            .filter(Boolean),
        ),
      ],
      name:
        string(mission.name) ||
        string(r.name).split("|").at(-1)?.trim() ||
        "Unknown mission",
      description: string(mission.description),
      type: string(mission.type, "Unknown"),
      orbit: string(orbit.abbrev, "Unknown"),
      orbitName: string(orbit.name, "Unknown"),
    },
    payloads: [],
    launchPad: normalizePad(r.pad, updated),
    country: country(object(object(r.pad).location)).name,
    orbit: string(orbit.abbrev, "Unknown"),
    livestream: list(r.vidURLs || r.vid_urls)
      .filter((v) => safeURL(v.url))
      .map((v) => ({
        url: safeURL(v.url)!,
        title: string(v.title, "Mission webcast"),
        official: Number(object(v.type).id) === 1,
      })),
    image: image(r.image),
    imageSource: string(object(r.image).credit) || url,
    patch:
      image(list(r.mission_patches)[0]?.image_url) ||
      image(list(r.mission_patches)[0]?.image),
    weather: string(r.weather_concerns) || null,
    probability: num(r.probability),
    sources,
    timeline,
  };
  LaunchValidation.parse(launch);
  return launch;
}
export function normalizeResponse(input: unknown, fetchedAt: string) {
  const raw = object(input);
  if (!Array.isArray(raw.results))
    throw new Error("Source returned an invalid dataset");
  const results = list(raw.results);
  const launches = results.flatMap((r) => {
    try {
      return [normalizeLaunch(r, fetchedAt)];
    } catch {
      return [];
    }
  });
  if (results.length && !launches.length)
    throw new Error("Source returned no valid mission records");
  return { launches, total: num(raw.count) ?? results.length };
}
