import { getLaunch, snapshot } from "@/services/launch-service";
import { LaunchDetail } from "@/features/launch-detail";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
export function generateStaticParams() {
  return snapshot.launches.map(({ id }) => ({ id }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const l = await getLaunch((await params).id);
  if (!l) return { title: "Mission not found" };
  return {
    title: `${l.mission.name} Launch Date, Time & Live Tracking`,
    description: l.description.slice(0, 160) || l.name,
    openGraph: {
      title: l.name,
      description: l.description.slice(0, 160),
      images: l.image ? [{ url: l.image, alt: l.name }] : [],
    },
    twitter: {
      title: l.name,
      description: l.description.slice(0, 160),
      images: l.image ? [l.image] : [],
    },
  };
}
export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const l = await getLaunch((await params).id);
  if (!l) notFound();
  const json = {
    "@context": "https://schema.org",
    "@type": "Event",
    name: l.name,
    description: l.description,
    startDate:
      ["second", "minute", "hour", "day"].includes(l.precision) &&
      l.status !== "tbd"
        ? l.net
        : undefined,
    eventStatus: "https://schema.org/EventScheduled",
    location: {
      "@type": "Place",
      name: l.launchPad.name,
      geo: {
        "@type": "GeoCoordinates",
        latitude: l.launchPad.latitude,
        longitude: l.launchPad.longitude,
      },
    },
    organizer: { "@type": "Organization", name: l.agency.name },
    image: l.image || undefined,
  };
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(json).replace(/</g, "\\u003c"),
        }}
      />
      <LaunchDetail launch={l} />
    </>
  );
}
