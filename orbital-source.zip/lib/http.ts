export async function fetchJSON(
  url: string,
  options: RequestInit = {},
  attempts = 2,
): Promise<unknown> {
  let last: unknown;
  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      const response = await fetch(url, {
        ...options,
        signal: AbortSignal.timeout(10000),
      });
      if (!response.ok) {
        if (response.status === 429)
          throw new Error(
            "Launch Library rate limit reached. Cached data remains available.",
          );
        if (response.status < 500)
          throw new Error(`Source returned ${response.status}`);
        throw new Error(`Source unavailable (${response.status})`);
      }
      return await response.json();
    } catch (error) {
      last = error;
      if (error instanceof Error && /rate limit|returned/.test(error.message))
        break;
      if (attempt < attempts - 1)
        await new Promise((resolve) =>
          setTimeout(resolve, 400 * (attempt + 1)),
        );
    }
  }
  throw last instanceof Error ? last : new Error("Unable to reach source");
}
