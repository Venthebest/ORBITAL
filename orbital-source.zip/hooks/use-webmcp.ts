"use client";
import { useEffect, useRef } from "react";
import { z } from "zod";
import { useOrbital } from "@/components/app-provider";
interface ModelContext {
  registerTool(
    tool: {
      name: string;
      description: string;
      inputSchema: object;
      annotations: { readOnlyHint: boolean; untrustedContentHint: boolean };
      execute: (input: unknown) => unknown;
    },
    options: { signal: AbortSignal },
  ): void | Promise<void>;
}
export function useWebMCP() {
  const store = useOrbital(),
    latest = useRef(store);
  useEffect(() => {
    latest.current = store;
  }, [store]);
  useEffect(() => {
    const context = (document as Document & { modelContext?: ModelContext })
      .modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const register = (tool: Parameters<ModelContext["registerTool"]>[0]) => {
      try {
        void Promise.resolve(
          context.registerTool(tool, { signal: lifecycle.signal }),
        ).catch(() => {});
      } catch {}
    };
    register({
      name: "search_launches",
      description:
        "Search the loaded launch dataset by mission, vehicle, agency or launch site. Returns source-backed records.",
      inputSchema: {
        type: "object",
        properties: { query: { type: "string", maxLength: 200 } },
        required: ["query"],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: true, untrustedContentHint: true },
      execute(input) {
        const { query } = z
          .object({ query: z.string().max(200) })
          .strict()
          .parse(input);
        return latest.current.data.launches
          .filter((l) =>
            (
              l.name +
              " " +
              l.description +
              " " +
              l.agency.name +
              " " +
              l.launchPad.location
            )
              .toLowerCase()
              .includes(query.toLowerCase()),
          )
          .slice(0, 20)
          .map((l) => ({
            id: l.id,
            name: l.name,
            net: l.net,
            precision: l.precision,
            status: l.status,
            sourceUrl: l.sources[0].sourceUrl,
          }));
      },
    });
    register({
      name: "follow_launches",
      description:
        "Follow specified missions on this device using the same following state as the interface.",
      inputSchema: {
        type: "object",
        properties: {
          launchIds: { type: "array", items: { type: "string" }, maxItems: 20 },
        },
        required: ["launchIds"],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute(input) {
        const { launchIds } = z
          .object({ launchIds: z.array(z.string()).max(20) })
          .strict()
          .parse(input);
        if (
          launchIds.some(
            (id) => !latest.current.data.launches.some((l) => l.id === id),
          )
        )
          throw new Error("Unknown mission ID");
        const ids = [...new Set(launchIds)];
        for (const id of ids)
          if (!latest.current.isFollowed("launch", id))
            latest.current.toggleFollow("launch", id);
        return { followed: ids };
      },
    });
    return () => lifecycle.abort();
  }, []);
}
