import { writeFile, rename } from "node:fs/promises";
import { z } from "zod";
const base = "https://ll.thespacedevs.com/2.3.0";
const headers = process.env.LL2_API_TOKEN
  ? { Authorization: `Token ${process.env.LL2_API_TOKEN}` }
  : { Accept: "application/json" };
const schema = z
  .object({
    count: z.number().nonnegative(),
    results: z.array(
      z
        .object({
          id: z.string(),
          name: z.string(),
          net: z.string().nullable(),
          status: z.object({ id: z.number() }),
        })
        .passthrough(),
    ),
  })
  .passthrough();
async function get(path) {
  const response = await fetch(base + path, {
    headers,
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok)
    throw new Error(
      `Source returned ${response.status}; the prior snapshot is preserved.`,
    );
  return schema.parse(await response.json());
}
const upcoming = await get("/launches/upcoming/?limit=100&mode=detailed");
const previous = await get("/launches/previous/?limit=100&mode=detailed");
if (!upcoming.results.length || !previous.results.length)
  throw new Error("Empty source result; preserving previous snapshot.");
const fetchedAt = new Date().toISOString(),
  year = new Date().getUTCFullYear();
const params = `?include_suborbital=false&net__gte=${year}-01-01&net__lt=${year + 1}-01-01&limit=1`;
const total = await get("/launches/previous/" + params),
  success = await get("/launches/previous/" + params + "&status=3");
await writeFile(
  "data/raw-snapshot.json.tmp",
  JSON.stringify({ upcoming, previous, fetchedAt }),
);
await rename("data/raw-snapshot.json.tmp", "data/raw-snapshot.json");
await writeFile(
  "data/year-statistics.json.tmp",
  JSON.stringify({
    year,
    total: total.count,
    success: success.count,
    fetchedAt,
    sourceUrl: base + "/launches/previous/" + params,
  }),
);
await rename("data/year-statistics.json.tmp", "data/year-statistics.json");
console.log(
  `Verified snapshot saved: ${upcoming.results.length} upcoming, ${previous.results.length} recent. ${year}: ${total.count} orbital attempts.`,
);
