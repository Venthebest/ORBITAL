import type { NextConfig } from "next";
const staticExport = process.env.SITES_STATIC_EXPORT === "1";
const config: NextConfig = {
  poweredByHeader: false,
  images: { unoptimized: true },
  ...(staticExport ? { output: "export", trailingSlash: true } : {}),
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
        ],
      },
      {
        source: "/sw.js",
        headers: [{ key: "Cache-Control", value: "no-cache" }],
      },
    ];
  },
};
export default config;
