import type { MetadataRoute } from "next";
import { snapshot } from "@/services/launch-service";
export const dynamic = "force-static";
export default function sitemap(): MetadataRoute.Sitemap {
  const origin = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  return [
    ...[
      "",
      "launches",
      "today",
      "calendar",
      "rockets",
      "agencies",
      "map",
      "statistics",
      "sources",
      "following",
      "settings",
      "compare",
    ].map((p) => ({ url: origin + "/" + p, lastModified: snapshot.fetchedAt })),
    ...snapshot.launches.map((l) => ({
      url: origin + "/launch/" + l.id,
      lastModified: l.lastUpdated,
    })),
    ...snapshot.rockets.map((r) => ({
      url: origin + "/rocket/" + r.id,
      lastModified: snapshot.fetchedAt,
    })),
    ...snapshot.agencies.map((a) => ({
      url: origin + "/agency/" + a.id,
      lastModified: snapshot.fetchedAt,
    })),
  ];
}
