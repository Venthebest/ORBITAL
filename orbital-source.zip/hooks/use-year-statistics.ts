"use client";
import { useQuery } from "@tanstack/react-query";
import initial from "@/data/year-statistics.json";
import type { YearStatistics } from "@/services/statistics-service";
export function useYearStatistics() {
  return useQuery<YearStatistics>({
    queryKey: ["year-statistics"],
    initialData: initial,
    initialDataUpdatedAt: Date.parse(initial.fetchedAt),
    refetchInterval: 3600000,
    queryFn: async () => {
      const r = await fetch("/api/statistics", {
        signal: AbortSignal.timeout(25000),
      });
      if (!r.ok) throw new Error("Annual data unavailable");
      return r.json();
    },
    staleTime: 3600000,
    refetchOnWindowFocus: false,
    retry: 0,
    enabled: process.env.NEXT_PUBLIC_STATIC_DEPLOY !== "1",
  }).data!;
}
