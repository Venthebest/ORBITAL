import { z } from "zod";
import { getLaunchPage } from "@/services/launch-service";
const schema = z.object({
  range: z.enum(["upcoming", "archive"]),
  offset: z.coerce.number().int().min(0).max(100000),
});
export async function GET(request: Request) {
  if (process.env.NEXT_PUBLIC_STATIC_DEPLOY === "1")
    return Response.json(
      { error: "Additional pages require the live ORBITAL server." },
      { status: 503 },
    );
  const u = new URL(request.url);
  const parsed = schema.safeParse({
    range: u.searchParams.get("range"),
    offset: u.searchParams.get("offset"),
  });
  if (!parsed.success)
    return Response.json({ error: "Invalid page request" }, { status: 400 });
  try {
    const result = await getLaunchPage(parsed.data.range, parsed.data.offset);
    return Response.json(
      {
        ...result,
        nextOffset: parsed.data.offset + 100,
        hasMore: parsed.data.offset + 100 < result.total,
      },
      {
        headers: {
          "Cache-Control": "public,s-maxage=600,stale-while-revalidate=3600",
        },
      },
    );
  } catch (e) {
    return Response.json(
      {
        error:
          e instanceof Error
            ? e.message
            : "Source unavailable; your loaded missions remain available.",
      },
      { status: 503 },
    );
  }
}
