"use client";
import Link from "next/link";
import { MapPin, ArrowUpRight, CalendarDays, Share2 } from "lucide-react";
import type { Launch } from "@/types";
import { useOrbital } from "./app-provider";
import { Status, FollowButton, Countdown, SafeImage } from "./ui";
import { formatTime, launchDate, zoneFor, hasExactTime } from "@/lib/time";
export async function shareLaunch(l: Launch, toast: (s: string) => void) {
  const url = location.origin + "/launch/" + l.id;
  const text = `${l.name} · ${launchDate(l, "UTC")}${hasExactTime(l) ? " · " + formatTime(l.net, "UTC") : ""}`;
  try {
    if (navigator.share) await navigator.share({ title: l.name, text, url });
    else {
      await navigator.clipboard.writeText(url);
      toast("Mission link copied");
    }
  } catch (e) {
    if (!(e instanceof DOMException && e.name === "AbortError"))
      toast("Copy the mission URL from your address bar");
  }
}
export function LaunchCard({
  launch: l,
  featured = false,
}: {
  launch: Launch;
  featured?: boolean;
}) {
  const { settings, toast } = useOrbital();
  const zone = zoneFor(settings, l);
  return (
    <article className={`mission-card ${featured ? "featured" : ""}`}>
      <Link href={"/launch/" + l.id} className="mission-card-art" tabIndex={-1}>
        <SafeImage src={l.image} alt={l.name} />
        <span className="mission-art-shade" />
        <span className="mission-card-time">
          {launchDate(l, zone)}
          <strong>
            {hasExactTime(l)
              ? formatTime(l.net, zone)
              : l.precision.toUpperCase() + " · NET"}
          </strong>
        </span>
        <div className="mission-card-state">
          <Status launch={l} />
        </div>
      </Link>
      <div className="mission-card-body">
        <div className="mission-card-agency">
          {l.agency.name}
          <span>{l.orbit}</span>
        </div>
        <Link href={"/launch/" + l.id}>
          <h3>{l.mission.name}</h3>
          <div className="mission-rocket">{l.rocket.name}</div>
        </Link>
        <div className="mission-location">
          <MapPin size={13} />
          <span>{l.launchPad.location.split(",")[0]}</span>
        </div>
        <div className="mission-card-footer">
          <Countdown launch={l} compact />
          <div>
            <button
              className="icon-button"
              aria-label="Share mission"
              onClick={() => shareLaunch(l, toast)}
            >
              <Share2 size={16} />
            </button>
            <FollowButton type="launch" id={l.id} />
          </div>
        </div>
      </div>
    </article>
  );
}
export function LaunchRow({ launch: l }: { launch: Launch }) {
  const { settings } = useOrbital();
  const zone = zoneFor(settings, l);
  return (
    <article className="launch-row">
      <div className="launch-row-date">
        <strong>
          {hasExactTime(l) ? formatTime(l.net, zone) : "NET / TBD"}
        </strong>
        <span>{launchDate(l, zone)}</span>
      </div>
      <Link className="launch-row-main" href={"/launch/" + l.id}>
        <h3>{l.mission.name}</h3>
        <p>
          {l.rocket.name}
          <span>·</span>
          {l.agency.name}
        </p>
      </Link>
      <div className="launch-row-site">
        <MapPin size={14} />
        <span>{l.launchPad.location.split(",")[0]}</span>
      </div>
      <span className="orbit-tag">{l.orbit}</span>
      <div className="launch-row-status">
        <Status launch={l} />
        <Countdown launch={l} compact />
      </div>
      <FollowButton type="launch" id={l.id} />
      <Link
        href={"/launch/" + l.id}
        aria-label={`View ${l.mission.name}`}
        className="icon-button row-view"
      >
        <ArrowUpRight size={18} />
      </Link>
    </article>
  );
}
export function LaunchSkeleton() {
  return (
    <div className="mission-card skeleton-card">
      <div className="skeleton skeleton-image" />
      <div className="skeleton skeleton-line" />
      <div className="skeleton skeleton-line short" />
    </div>
  );
}
export { CalendarDays };
