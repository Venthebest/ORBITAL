"use client";
import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, CalendarDays } from "lucide-react";
import { useOrbital } from "@/components/app-provider";
import { Segment, SectionTitle, EmptyState } from "@/components/ui";
import { LaunchRow } from "@/components/launch-card";
import {
  dateKey,
  formatDate,
  formatTime,
  hasExactTime,
  zoneFor,
  isUpcoming,
} from "@/lib/time";
import type { Launch } from "@/types";
export function CalendarPage() {
  const { data, t } = useOrbital();
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">A MONTH ABOVE EARTH</div>
          <h1>
            {t("Calendar")}
            <span className="accent">.</span>
          </h1>
          <p>The global launch schedule, at a glance.</p>
        </div>
      </div>
      <CalendarView launches={data.launches} />
    </div>
  );
}
export function CalendarView({ launches }: { launches: Launch[] }) {
  const { settings, now, t } = useOrbital();
  const [month, setMonth] = useState(
      () => new Date(dateKey(new Date(now), zoneFor(settings)) + "T12:00:00Z"),
    ),
    [selected, setSelected] = useState(() =>
      dateKey(new Date(now), zoneFor(settings)),
    ),
    [mode, setMode] = useState("month");
  const timezone = zoneFor(settings);
  const today = dateKey(new Date(now), timezone);
  useEffect(() => {
    setSelected(today);
    setMonth(new Date(today + "T12:00:00Z"));
  }, [today]);
  const first = new Date(
    Date.UTC(month.getUTCFullYear(), month.getUTCMonth(), 1),
  );
  const start = new Date(mode === "week" ? selected + "T12:00:00Z" : first);
  start.setUTCDate(start.getUTCDate() - ((start.getUTCDay() + 6) % 7));
  const days = Array.from(
    { length: mode === "week" ? 7 : 42 },
    (_, i) => new Date(start.getTime() + i * 86400000),
  );
  const reliable = launches.filter(
    (l) => l.net && ["second", "minute", "hour", "day"].includes(l.precision),
  );
  const forDay = (key: string) =>
    reliable.filter((l) => dateKey(l.net!, zoneFor(settings, l)) === key);
  const list = forDay(selected);
  const change = (delta: number) => {
    if (mode === "week") {
      const day = new Date(selected + "T12:00:00Z");
      day.setUTCDate(day.getUTCDate() + delta * 7);
      setSelected(day.toISOString().slice(0, 10));
      setMonth(day);
    } else {
      const m = new Date(
        Date.UTC(month.getUTCFullYear(), month.getUTCMonth() + delta, 1),
      );
      setMonth(m);
      setSelected(m.toISOString().slice(0, 10));
    }
  };
  return (
    <>
      <div className="calendar-toolbar">
        <div className="calendar-title">
          <button
            className="icon-button"
            onClick={() => change(-1)}
            aria-label="Previous period"
          >
            <ChevronLeft size={18} />
          </button>
          <h2>
            {formatDate(month.toISOString(), "UTC", {
              month: "long",
              year: "numeric",
            })}
          </h2>
          <button
            className="icon-button"
            onClick={() => change(1)}
            aria-label="Next period"
          >
            <ChevronRight size={18} />
          </button>
          <button
            className="button ghost"
            onClick={() => {
              setMonth(new Date(now));
              setSelected(today);
            }}
          >
            {t("Today")}
          </button>
        </div>
        <Segment
          value={mode}
          onChange={setMode}
          options={[
            { value: "month", label: "Month" },
            { value: "week", label: "Week" },
            { value: "agenda", label: "Agenda" },
          ]}
        />
      </div>
      {mode === "agenda" ? (
        <div>
          {reliable.filter(
            (l) =>
              dateKey(l.net!, zoneFor(settings, l)).slice(0, 7) ===
              month.toISOString().slice(0, 7),
          ).length ? (
            reliable
              .filter(
                (l) =>
                  dateKey(l.net!, zoneFor(settings, l)).slice(0, 7) ===
                  month.toISOString().slice(0, 7),
              )
              .map((l) => <LaunchRow launch={l} key={l.id} />)
          ) : (
            <EmptyState
              title="No launches found"
              description="No confirmed launch dates in this month. Try another month."
            />
          )}
        </div>
      ) : (
        <>
          <div className="calendar-weekdays">
            {[
              "Monday",
              "Tuesday",
              "Wednesday",
              "Thursday",
              "Friday",
              "Saturday",
              "Sunday",
            ].map((d) => (
              <span key={d}>{d.slice(0, 3)}</span>
            ))}
          </div>
          <div
            className={`calendar-grid ${mode === "week" ? "calendar-week-grid" : ""}`}
          >
            {days.map((day) => {
              const key = day.toISOString().slice(0, 10),
                missions = forDay(key);
              return (
                <button
                  key={key}
                  className={`calendar-cell ${day.getUTCMonth() !== month.getUTCMonth() ? "outside" : ""} ${key === today ? "today" : ""} ${selected === key ? "selected" : ""}`}
                  aria-label={`${key}: ${missions.length} launches`}
                  aria-pressed={selected === key}
                  onClick={() => setSelected(key)}
                >
                  <span className="calendar-day">{day.getUTCDate()}</span>
                  {missions.slice(0, 3).map((l) => (
                    <span className="calendar-event" key={l.id}>
                      <small>
                        {hasExactTime(l)
                          ? formatTime(l.net, zoneFor(settings, l)).split(
                              " ",
                            )[0]
                          : "NET"}
                      </small>
                      {l.mission.name}
                    </span>
                  ))}
                  {missions.length > 3 && (
                    <span className="calendar-more">
                      +{missions.length - 3} more
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          <section className="selected-day">
            <SectionTitle
              title={formatDate(selected + "T12:00:00Z", "UTC", {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}
              aside={
                <span className="muted" style={{ fontSize: 11 }}>
                  {list.length} missions
                </span>
              }
            />
            {list.length ? (
              <div className="launch-table">
                {list.map((l) => (
                  <LaunchRow key={l.id} launch={l} />
                ))}
              </div>
            ) : (
              <EmptyState
                title="No launches found"
                description="No launches with a confirmed date on this day."
              />
            )}
          </section>
        </>
      )}
      <div className="settings-note">
        <CalendarDays size={14} /> Open any mission to export to Apple Calendar,
        Google Calendar or Outlook.{" "}
        {launches.filter((l) => isUpcoming(l) && !reliable.includes(l)).length}{" "}
        missions with uncertain day or month precision are excluded from date
        cells.
      </div>
    </>
  );
}
