import { unstable_cache } from "next/cache";
import { z } from "zod";
import initial from "@/data/year-statistics.json";
import { fetchJSON } from "@/lib/http";
export interface YearStatistics {
  year: number;
  total: number;
  success: number;
  fetchedAt: string;
  sourceUrl: string;
  error?: string;
}
const count = z.object({ count: z.number().int().nonnegative() });
const fetchTotals = unstable_cache(
  async (year: number): Promise<YearStatistics> => {
    const base = "https://ll.thespacedevs.com/2.3.0/launches/previous/";
    const params = new URLSearchParams({
      include_suborbital: "false",
      net__gte: `${year}-01-01`,
      net__lt: `${year + 1}-01-01`,
      limit: "1",
    });
    const sourceUrl = base + "?" + params;
    const headers: HeadersInit = process.env.LL2_API_TOKEN
      ? { Authorization: `Token ${process.env.LL2_API_TOKEN}` }
      : { Accept: "application/json" };
    const total = count.parse(
      await fetchJSON(sourceUrl, { headers, cache: "no-store" }),
    );
    const success = count.parse(
      await fetchJSON(sourceUrl + "&status=3", { headers, cache: "no-store" }),
    );
    return {
      year,
      total: total.count,
      success: success.count,
      fetchedAt: new Date().toISOString(),
      sourceUrl,
    };
  },
  ["ll2-year-totals-v1"],
  { revalidate: 86400 },
);
let cache: YearStatistics = initial;
let retryAfter = 0;
export async function getYearStatistics() {
  if (Date.now() < retryAfter) return cache;
  try {
    cache = await fetchTotals(new Date().getUTCFullYear());
    return cache;
  } catch {
    retryAfter = Date.now() + 3600000;
    return {
      ...cache,
      error:
        "Annual totals could not be updated. Displaying the verified snapshot.",
    };
  }
}
