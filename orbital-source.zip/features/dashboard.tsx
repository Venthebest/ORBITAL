"use client";
import Link from "next/link";
import {
  ArrowUpRight,
  MapPin,
  Orbit,
  Radio,
  CalendarDays,
  Globe2,
  Rocket,
  Activity,
} from "lucide-react";
import { useOrbital } from "@/components/app-provider";
import { Countdown, Status, SectionTitle, FollowButton } from "@/components/ui";
import { LaunchCard, LaunchRow } from "@/components/launch-card";
import {
  formatDate,
  formatTime,
  dateKey,
  isUpcoming,
  zoneFor,
  hasExactTime,
  hasConfirmedDay,
  calendarWeekRange,
  launchDate,
} from "@/lib/time";
import { useYearStatistics } from "@/hooks/use-year-statistics";
export function Dashboard() {
  const yearStats = useYearStatistics();
  const { data, now, settings, t } = useOrbital();
  const upcoming = data.launches
    .filter(isUpcoming)
    .filter((l) => !l.net || Date.parse(l.net) > now - 86400000);
  const next =
    upcoming.find((l) => l.net && Date.parse(l.net) > now) || upcoming[0];
  const recent = data.launches
    .filter((l) => !isUpcoming(l))
    .sort((a, b) => Date.parse(b.net || "") - Date.parse(a.net || ""));
  const today = data.launches.filter(
    (l) =>
      hasConfirmedDay(l) &&
      dateKey(l.net!, zoneFor(settings, l)) ===
        dateKey(new Date(now), zoneFor(settings, l)),
  );
  const week = upcoming.filter((l) => {
    if (!hasConfirmedDay(l)) return false;
    const z = zoneFor(settings, l),
      w = calendarWeekRange(now, z),
      day = dateKey(l.net!, z);
    return day >= w.start && day <= w.end;
  });
  return (
    <div className="dashboard page-container">
      <div className="page-intro">
        <div>
          <span className="eyebrow">GLOBAL SPACE LAUNCH TRACKER</span>
          <h1>
            Beyond the horizon<span className="accent">.</span>
          </h1>
          <p>Your view of the world&apos;s next giant leaps.</p>
        </div>
        <span className="intro-date">
          <CalendarDays size={15} />
          {formatDate(new Date(now).toISOString(), zoneFor(settings), {
            weekday: "long",
            month: "long",
            day: "numeric",
            year: "numeric",
          })}
        </span>
      </div>
      {next && (
        <section className="hero">
          <img
            className="hero-earth"
            src="/earth-horizon.webp"
            alt="Sunrise over the Earth's blue atmospheric rim photographed from the International Space Station"
            fetchPriority="high"
          />
          <div className="hero-shade" />
          <div className="hero-content">
            <div className="hero-eyebrow">
              <span className="eyebrow">{t("Next launch")}</span>
              <Status launch={next} />
            </div>
            <div className="hero-provider">
              <span className="agency-mark">
                {next.agency.name === "SpaceX"
                  ? "SPACE X"
                  : next.agency.abbrev || next.agency.name}
              </span>
              <span className="hero-divider" />
              <span>{next.mission.type}</span>
            </div>
            <h2>{next.mission.name}</h2>
            <p className="hero-rocket">{next.rocket.name}</p>
            <Countdown launch={next} />
            <div className="hero-actions">
              <Link href={"/launch/" + next.id} className="button primary">
                {t("View mission")}
                <ArrowUpRight size={16} />
              </Link>
              <FollowButton type="launch" id={next.id} full />
            </div>
          </div>
          <div className="hero-coordinate">
            <span>LOW EARTH ORBIT</span>
            <span>EARTH · NASA / ISS</span>
          </div>
          <div className="hero-details">
            <span>
              <CalendarDays size={16} />
              <strong>{launchDate(next, zoneFor(settings, next))}</strong>
              <small>
                {hasExactTime(next)
                  ? formatTime(next.net, zoneFor(settings, next))
                  : "Timing unconfirmed"}
              </small>
            </span>
            <span>
              <MapPin size={16} />
              <strong>{next.launchPad.location.split(",")[0]}</strong>
              <small>{next.launchPad.name}</small>
            </span>
            <span>
              <Orbit size={16} />
              <strong>{next.mission.orbitName}</strong>
              <small>Target orbit · {next.orbit}</small>
            </span>
            <Link href={"/launch/" + next.id + "#live"}>
              <Radio size={16} />
              <strong>Mission coverage</strong>
              <small>
                {next.livestream.some((v) => v.official)
                  ? "Official stream available"
                  : "Awaiting official broadcast"}
                <ArrowUpRight size={13} />
              </small>
            </Link>
          </div>
        </section>
      )}
      <div className="quick-stats">
        <Link href="/today">
          <span>{t("Launches today")}</span>
          <strong>
            {today.length.toString().padStart(2, "0")}
            <small>
              {today.length
                ? "missions on the schedule"
                : "a quiet day in orbit"}
            </small>
          </strong>
          <SunriseGlyph />
        </Link>
        <Link href="/launches?date=week">
          <span>{t("This week")}</span>
          <strong>
            {week.length.toString().padStart(2, "0")}
            <small>upcoming missions</small>
          </strong>
          <Activity size={23} />
        </Link>
        <Link href="/statistics">
          <span>Orbital launches · {yearStats.year}</span>
          <strong>
            {yearStats.total}
            <small>completed worldwide</small>
          </strong>
          <Globe2 size={23} />
        </Link>
        <Link href="/statistics">
          <span>Confirmed success · {yearStats.year}</span>
          <strong>
            {((yearStats.success / yearStats.total) * 100).toFixed(1)}
            <span className="stat-percent">%</span>
            <small>{yearStats.success} successful launches</small>
          </strong>
          <Orbit size={23} />
        </Link>
      </div>
      <section className="dashboard-section">
        <SectionTitle
          eyebrow="THE ROAD AHEAD"
          title="Upcoming launches"
          aside={
            <Link href="/launches" className="text-link">
              {t("View all launches")}
              <ArrowUpRight size={15} />
            </Link>
          }
        />
        <div className="mission-grid">
          {upcoming.slice(0, 4).map((l) => (
            <LaunchCard key={l.id} launch={l} />
          ))}
        </div>
      </section>
      <section className="network-section">
        <div>
          <span className="eyebrow">ONE PLANET. ENDLESS POSSIBILITIES.</span>
          <h2>A global perspective.</h2>
          <p>
            From the Florida coast to the shores of Mahia.
            <br />
            Explore the places that connect Earth to space.
          </p>
          <div className="network-numbers">
            <div>
              <strong>
                {data.pads.filter((p) => !p.id.startsWith("location-")).length}
              </strong>
              <span>Launch pads tracked</span>
            </div>
            <div>
              <strong>{new Set(data.pads.map((p) => p.country)).size}</strong>
              <span>Countries & territories</span>
            </div>
          </div>
          <Link href="/map" className="button secondary">
            <Globe2 size={17} />
            {t("Explore map")}
            <ArrowUpRight size={16} />
          </Link>
        </div>
        <div className="network-map">
          <img
            src="/world-map.svg"
            alt="Global launch network world map"
            loading="lazy"
          />
          <span className="map-label label-cape">Cape Canaveral</span>
          <span className="map-label label-kourou">Kourou</span>
          <span className="map-label label-wenchang">Wenchang</span>
          <span className="map-label label-mahia">Mahia</span>
          <Link
            href="/map"
            className="network-map-link"
            aria-label="Open interactive map"
          />
        </div>
      </section>
      <section className="dashboard-section">
        <SectionTitle
          eyebrow="BACK ON EARTH"
          title="Recent launches"
          aside={
            <Link href="/launches?range=archive" className="text-link">
              Mission archive
              <ArrowUpRight size={15} />
            </Link>
          }
        />
        <div className="launch-table">
          {recent.slice(0, 4).map((l) => (
            <LaunchRow key={l.id} launch={l} />
          ))}
        </div>
      </section>
      <div className="directory-split">
        <section>
          <SectionTitle
            eyebrow="THE VEHICLES"
            title="Popular rockets"
            aside={
              <Link
                href="/rockets"
                className="icon-button"
                aria-label="All rockets"
              >
                <ArrowUpRight size={18} />
              </Link>
            }
          />
          {data.rockets
            .filter((r) =>
              ["Falcon 9 Block 5", "Starship", "Electron", "Ariane 62"].some(
                (n) => r.name.includes(n),
              ),
            )
            .slice(0, 4)
            .map((r) => (
              <Link
                className="directory-row"
                href={"/rocket/" + r.id}
                key={r.id}
              >
                <span className="directory-row-icon">
                  <Rocket size={19} />
                </span>
                <span>
                  <strong>{r.name}</strong>
                  <small>{r.manufacturer}</small>
                </span>
                <span className="directory-row-value">
                  {r.active === true ? "Active" : "Vehicle details"}
                </span>
                <ArrowUpRight size={16} />
              </Link>
            ))}
        </section>
        <section>
          <SectionTitle
            eyebrow="THE PEOPLE"
            title="Agencies"
            aside={
              <Link
                href="/agencies"
                className="icon-button"
                aria-label="All agencies"
              >
                <ArrowUpRight size={18} />
              </Link>
            }
          />
          {data.agencies
            .filter((a) =>
              [
                "SpaceX",
                "Rocket Lab",
                "United Launch Alliance",
                "Arianespace",
              ].includes(a.name),
            )
            .slice(0, 4)
            .map((a) => (
              <Link
                className="directory-row"
                href={"/agency/" + a.id}
                key={a.id}
              >
                <span className="directory-row-icon agency-initial">
                  {a.name.slice(0, 1)}
                </span>
                <span>
                  <strong>{a.name}</strong>
                  <small>{a.country}</small>
                </span>
                <span className="directory-row-value">
                  {upcoming.filter((l) => l.agency.id === a.id).length} upcoming
                </span>
                <ArrowUpRight size={16} />
              </Link>
            ))}
        </section>
      </div>
      <div className="dashboard-source-note">
        Launch schedule: The Space Devs · Year totals: orbital attempts through{" "}
        {formatDate(yearStats.fetchedAt, "UTC")} ·{" "}
        <Link href="/sources">View sources & coverage</Link>
      </div>
    </div>
  );
}
function SunriseGlyph() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="24"
      height="24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      aria-hidden="true"
    >
      <path d="M3 17h18M6 17a6 6 0 0 1 12 0M12 2v3M3 8l2 2M21 8l-2 2M2 21h20" />
    </svg>
  );
}
