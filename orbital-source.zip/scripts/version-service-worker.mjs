import { readdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
const hash = createHash("sha256");
async function add(path) {
  for (const entry of (await readdir(path, { withFileTypes: true })).sort(
    (a, b) => a.name.localeCompare(b.name),
  )) {
    const name = path + "/" + entry.name;
    if (entry.isDirectory()) await add(name);
    else if (/\.(tsx?|css|json)$/.test(name)) {
      hash.update(name);
      hash.update(await readFile(name));
    }
  }
}
for (const folder of [
  "app",
  "components",
  "features",
  "hooks",
  "lib",
  "providers",
  "services",
  "adapters",
  "types",
  "data",
])
  await add(folder);
const version = hash.digest("hex").slice(0, 12),
  file = "public/sw.js";
const source = await readFile(file, "utf8");
await writeFile(
  file,
  source.replace(
    /const CACHE = "orbital-[^"]+";/,
    `const CACHE = "orbital-${version}";`,
  ),
);
console.log("PWA cache version synchronized with application source.");
