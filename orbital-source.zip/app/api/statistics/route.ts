import { getYearStatistics } from "@/services/statistics-service";
export const dynamic = "force-static";
export const revalidate = 3600;
export async function GET() {
  return Response.json(await getYearStatistics(), {
    headers: {
      "Cache-Control": "public,s-maxage=3600,stale-while-revalidate=86400",
    },
  });
}
