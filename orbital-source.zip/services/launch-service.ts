import { unstable_cache } from "next/cache";
import rawCatalog from "@/data/raw-catalog.json";
import { officialAgencies } from "@/data/official-agencies";
import rawSnapshot from "@/data/raw-snapshot.json";
import {
  normalizeResponse,
  normalizeAgency,
  normalizeRocket,
  normalizePad,
} from "@/adapters/launch-library";
import { LaunchLibraryProvider } from "@/providers/launch-library";
import type { Launch, LaunchDataset } from "@/types";
const upcoming = normalizeResponse(rawSnapshot.upcoming, rawSnapshot.fetchedAt),
  past = normalizeResponse(rawSnapshot.previous, rawSnapshot.fetchedAt);
function unique<T extends { id: string }>(items: T[]) {
  return [...new Map(items.map((i) => [i.id, i])).values()];
}
export function mergeLaunches(items: Launch[]): Launch[] {
  const m = new Map<string, Launch>();
  for (const l of items) {
    const previous = m.get(l.id);
    if (
      !previous ||
      Date.parse(l.lastUpdated) > Date.parse(previous.lastUpdated)
    )
      m.set(l.id, l);
  }
  return [...m.values()].sort(
    (a, b) =>
      Date.parse(a.net || "9999-01-01") - Date.parse(b.net || "9999-01-01"),
  );
}
export function makeDataset(
  launches: Launch[],
  fetchedAt: string,
  upcomingTotal: number,
  pastTotal: number,
  mode: LaunchDataset["mode"],
  error: string | null = null,
): LaunchDataset {
  const ls = mergeLaunches(launches);
  return {
    launches: ls,
    agencies: unique([
      ...rawCatalog.agencies.map((a) =>
        normalizeAgency(a, rawSnapshot.fetchedAt),
      ),
      ...ls.map((l) => l.agency),
      ...officialAgencies,
    ]),
    rockets: unique([
      ...rawCatalog.rockets.map((r) =>
        normalizeRocket(r, rawSnapshot.fetchedAt),
      ),
      ...ls.map((l) => l.rocket),
    ]),
    pads: unique([
      ...rawCatalog.pads.map((p) => normalizePad(p, rawSnapshot.fetchedAt)),
      ...ls.map((l) => l.launchPad),
    ]),
    updatedAt: ls.reduce(
      (a, l) => (Date.parse(l.lastUpdated) > Date.parse(a) ? l.lastUpdated : a),
      fetchedAt,
    ),
    fetchedAt,
    upcomingTotal,
    pastTotal,
    mode,
    error,
    coverage: `${upcoming.launches.length} upcoming and ${past.launches.length} recent launches. Statistics describe the loaded records, not the complete global archive.`,
  };
}
export const snapshot = makeDataset(
  [...past.launches, ...upcoming.launches],
  rawSnapshot.fetchedAt,
  upcoming.total,
  past.total,
  "cached",
);
const provider = new LaunchLibraryProvider();
const fetchUpcomingCached = unstable_cache(
  () => provider.fetchUpcoming(),
  ["ll2-upcoming-v3"],
  { revalidate: process.env.LL2_API_TOKEN ? 90 : 600 },
);
const fetchRecentActiveCached = unstable_cache(
  () => provider.fetchRecent(),
  ["ll2-recent-active-v3"],
  { revalidate: 600 },
);
const fetchRecentCached = unstable_cache(
  () => provider.fetchRecent(),
  ["ll2-recent-v3"],
  { revalidate: 86400 },
);
let cache = snapshot;
let lastUpcoming = 0,
  lastRecent = 0;
let inFlight: Promise<LaunchDataset> | null = null;
let cooldown = 0;
export async function getLaunchDataset(): Promise<LaunchDataset> {
  const now = Date.now();
  const near = cache.launches.some(
    (l) =>
      l.net &&
      ["go", "in-flight", "hold"].includes(l.status) &&
      Math.abs(Date.parse(l.net) - now) < 86400000,
  );
  const ttl = process.env.LL2_API_TOKEN ? (near ? 90000 : 600000) : 600000;
  if (now - lastUpcoming < ttl || now < cooldown) return cache;
  if (inFlight) return inFlight;
  inFlight = (async () => {
    try {
      const next = await fetchUpcomingCached();
      let recent = cache.launches.filter((l) =>
        ["success", "failure", "partial-success", "cancelled"].includes(
          l.status,
        ),
      );
      let pastTotal = cache.pastTotal;
      if (now - lastRecent > (near ? 600000 : 86400000)) {
        try {
          const p = await (near
            ? fetchRecentActiveCached()
            : fetchRecentCached());
          recent = p.launches;
          pastTotal = p.total;
          lastRecent = now;
        } catch {
          /* preserve historical cache */
        }
      }
      cache = makeDataset(
        [
          ...cache.launches.filter(
            (l) =>
              !["success", "failure", "partial-success", "cancelled"].includes(
                l.status,
              ),
          ),
          ...recent,
          ...next.launches,
        ],
        next.fetchedAt,
        next.total,
        pastTotal,
        "live",
      );
      lastUpcoming = now;
      return cache;
    } catch (e) {
      cooldown = now + 600000;
      cache = {
        ...cache,
        mode: "cached",
        error: e instanceof Error ? e.message : "Unable to update launch data",
      };
      return cache;
    } finally {
      inFlight = null;
    }
  })();
  return inFlight;
}
const details = new Map<string, { launch: Launch; time: number }>();
export async function getLaunch(id: string) {
  const d = details.get(id);
  if (d && Date.now() - d.time < 600000) return d.launch;
  const cached = cache.launches.find((l) => l.id === id);
  if (cached) {
    if (Date.now() - lastUpcoming > 600000) void getLaunchDataset();
    return cached;
  }
  try {
    const l = await provider.fetchLaunch(id);
    details.set(id, { launch: l, time: Date.now() });
    return l;
  } catch {
    return null;
  }
}

const cachedPage = unstable_cache(
  (range: "upcoming" | "archive", offset: number) =>
    provider.fetchPage(range, offset),
  ["ll2-mission-pages-v3"],
  { revalidate: 3600 },
);
export async function getLaunchPage(
  range: "upcoming" | "archive",
  offset: number,
) {
  const page = await cachedPage(range, offset);
  for (const launch of page.launches)
    details.set(launch.id, { launch, time: Date.now() });
  return page;
}
