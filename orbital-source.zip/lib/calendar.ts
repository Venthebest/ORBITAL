import type { Launch } from "@/types";
import { hasExactTime } from "./time";
const escapeICS = (s: string) =>
  s
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\r?\n/g, "\\n");
const stamp = (s: string) =>
  new Date(s)
    .toISOString()
    .replace(/[-:]/g, "")
    .replace(/\.\d{3}/, "");
export function createICS(l: Launch, url: string) {
  if (!hasExactTime(l))
    throw new Error("Calendar export requires a confirmed time.");
  const start = stamp(l.net!),
    end = stamp(
      new Date(Date.parse(l.windowEnd || l.net!) + 3600000).toISOString(),
    );
  return (
    [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//ORBITAL//Launch Tracker//EN",
      "CALSCALE:GREGORIAN",
      "METHOD:PUBLISH",
      "BEGIN:VEVENT",
      `UID:${l.id}@orbital`,
      `DTSTAMP:${stamp(new Date().toISOString())}`,
      `DTSTART:${start}`,
      `DTEND:${end}`,
      `SUMMARY:${escapeICS(l.name)}`,
      `DESCRIPTION:${escapeICS(l.description + "\nTimes may change. Verify official source before travel.\n" + url)}`,
      `LOCATION:${escapeICS(l.launchPad.name + ", " + l.launchPad.location)}`,
      `URL:${url}`,
      "BEGIN:VALARM",
      "TRIGGER:-PT1H",
      "ACTION:DISPLAY",
      "DESCRIPTION:Launch in one hour",
      "END:VALARM",
      "END:VEVENT",
      "END:VCALENDAR",
    ]
      .map(foldICS)
      .join("\r\n") + "\r\n"
  );
}
export function downloadICS(l: Launch) {
  const url = URL.createObjectURL(
    new Blob([createICS(l, location.origin + "/launch/" + l.id)], {
      type: "text/calendar;charset=utf-8",
    }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = l.slug + ".ics";
  a.click();
  URL.revokeObjectURL(url);
}
export function googleCalendarURL(l: Launch) {
  const p = new URLSearchParams({
    action: "TEMPLATE",
    text: l.name,
    dates: `${stamp(l.net!)}/${stamp(new Date(Date.parse(l.net!) + 3600000).toISOString())}`,
    details: l.description,
    location: l.launchPad.name,
  });
  return "https://calendar.google.com/calendar/render?" + p;
}

function foldICS(line: string) {
  const encoder = new TextEncoder();
  let output = "",
    width = 0;
  for (const character of line) {
    const size = encoder.encode(character).length;
    if (width + size > 74) {
      output += "\r\n ";
      width = 1;
    }
    output += character;
    width += size;
  }
  return output;
}
