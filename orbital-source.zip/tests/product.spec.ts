import { test, expect } from "@playwright/test";
import type { LaunchDataset } from "../types";
test("combined filters, shareable views and precision labels", async ({
  page,
  request,
}) => {
  const response = await request.get("/api/launches");
  const data: LaunchDataset = await response.json();
  expect(data.launches.length).toBeGreaterThan(100);
  expect(data.launches.every((l) => l.sources.length > 0)).toBeTruthy();
  await page.goto("/launches?agency=spacex&orbit=leo");
  await expect(page.locator(".launch-row").first()).toBeVisible();
  const rows = await page.locator(".launch-row").allTextContents();
  expect(rows.every((row) => row.includes("SpaceX"))).toBeTruthy();
  await page.getByRole("button", { name: "Timeline", exact: true }).click();
  await expect(page).toHaveURL(/agency=spacex.*orbit=leo.*view=timeline/);
  await page.getByRole("button", { name: "Calendar", exact: true }).click();
  await expect(page.locator(".calendar-grid")).toBeVisible();
  const coarse = data.launches.find((l) => l.precision === "quarter");
  expect(coarse).toBeTruthy();
  await page.goto("/launch/" + coarse!.id);
  await expect(page.locator(".detail-info-box")).toContainText(/NET Q[1-4]/);
  await expect(page.locator(".countdown-number")).toHaveCount(0);
});
test("mission follow, reminder and ICS export persist", async ({ page }) => {
  await page.goto("/");
  const href = await page
    .getByRole("link", { name: "View mission", exact: true })
    .getAttribute("href");
  await page.goto(href!);
  await page.getByRole("button", { name: "Follow", exact: true }).click();
  await page.getByRole("button", { name: "Set reminder", exact: true }).click();
  await page.getByRole("button", { name: "10 minutes before" }).click();
  await page.getByRole("button", { name: "Save reminder" }).click();
  await page.reload();
  await expect(
    page.getByRole("button", { name: "Unfollow", exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () =>
        JSON.parse(localStorage.getItem("orbital-preferences-v1")!).reminders[0]
          .offset,
    ),
  ).toBe(10);
  await page
    .getByRole("button", { name: "Add to calendar", exact: true })
    .click();
  const download = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Apple Calendar / Outlook · .ics" })
    .click();
  expect((await download).suggestedFilename()).toMatch(/\.ics$/);
});
test("command palette supports keyboard selection", async ({ page }) => {
  await page.goto("/");
  await page.keyboard.press("Control+k");
  const search = page.getByRole("combobox");
  await search.fill("Starship");
  await expect(page.getByRole("option").first()).toBeVisible();
  await page.keyboard.press("ArrowDown");
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(/\/(launch|rocket)\//);
  await page.keyboard.press("Control+k");
  await page.keyboard.press("Escape");
  await expect(search).not.toBeVisible();
});
test("Earth map has real markers and interactive site panels", async ({
  page,
}) => {
  await page.goto("/map");
  await expect(page.locator(".map-marker").first()).toBeVisible({
    timeout: 25000,
  });
  expect(await page.locator(".map-sites-list button").count()).toBeGreaterThan(
    30,
  );
  await page
    .getByRole("textbox", { name: "Search launch sites" })
    .fill("Ariane Launch Area 4");
  await page.locator(".map-results button").first().click();
  await expect(
    page.getByRole("region", { name: "Selected launch site" }),
  ).toBeVisible();
  await expect(page.locator(".map-site-panel")).toContainText("Coordinates");
  await page.getByRole("button", { name: "Zoom in", exact: true }).click();
  await page.getByRole("button", { name: "Reset global view" }).click();
  await expect(
    page.getByRole("region", { name: "Selected launch site" }),
  ).not.toBeVisible();
});
test("320px calendar and Auckland UTC selection stay consistent", async ({
  browser,
}) => {
  const context = await browser.newContext({
    viewport: { width: 320, height: 720 },
    timezoneId: "Pacific/Auckland",
    serviceWorkers: "block",
  });
  const page = await context.newPage();
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(
    (process.env.PLAYWRIGHT_BASE_URL || "http://localhost:3000") + "/calendar",
  );
  await expect(page.locator(".calendar-cell.today.selected")).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBeTruthy();
  expect(errors).toEqual([]);
  await context.close();
});
