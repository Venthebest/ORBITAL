"use client";
import Link from "next/link";
import {
  Moon,
  Clock,
  Ruler,
  Sparkles,
  Languages,
  Bell,
  Star,
  Sunrise,
  Download,
  ShieldCheck,
} from "lucide-react";
import { useOrbital } from "@/components/app-provider";
import { Segment, EmptyState, SectionTitle, Countdown } from "@/components/ui";
import { LaunchRow } from "@/components/launch-card";
import { RocketCard, AgencyCard } from "./catalog";
import { LaunchGrid } from "./launches";
import {
  isUpcoming,
  dateKey,
  zoneFor,
  hasExactTime,
  formatDate,
} from "@/lib/time";
import type { UserSettings } from "@/types";
export function FollowingPage() {
  const { data, isFollowed, t, reminders } = useOrbital();
  const launches = data.launches.filter((l) => isFollowed("launch", l.id)),
    rockets = data.rockets.filter((r) => isFollowed("rocket", r.id)),
    agencies = data.agencies.filter((a) => isFollowed("agency", a.id));
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">THE MISSIONS THAT MATTER TO YOU</div>
          <h1>
            {t("Your orbit")}
            <span className="accent">.</span>
          </h1>
          <p>Follow the next chapter. Keep your favorites close.</p>
        </div>
        <span className="muted" style={{ fontSize: 12 }}>
          <Star size={14} />{" "}
          {launches.length + rockets.length + agencies.length} followed ·{" "}
          {reminders.length} reminders
        </span>
      </div>
      <SectionTitle title="Upcoming launches" />
      {launches.filter(isUpcoming).length ? (
        <LaunchGrid launches={launches.filter(isUpcoming)} />
      ) : (
        <EmptyState
          title="No saved missions yet"
          description="Follow a mission to keep its launch window and latest status in your orbit."
          action={
            <Link href="/launches" className="button secondary">
              {t("Browse launches")}
            </Link>
          }
        />
      )}
      <section className="dashboard-section">
        <SectionTitle title="Favorite rockets" />
        {rockets.length ? (
          <div className="collection-grid">
            {rockets.map((r) => (
              <RocketCard key={r.id} rocket={r} />
            ))}
          </div>
        ) : (
          <p className="settings-note">
            Follow launch vehicles in the{" "}
            <Link className="accent" href="/rockets">
              rocket directory
            </Link>
            .
          </p>
        )}
      </section>
      <section className="dashboard-section">
        <SectionTitle title="Favorite agencies" />
        {agencies.length ? (
          <div className="collection-grid">
            {agencies.map((a) => (
              <AgencyCard key={a.id} agency={a} />
            ))}
          </div>
        ) : (
          <p className="settings-note">
            Follow your favorite{" "}
            <Link className="accent" href="/agencies">
              space agencies
            </Link>
            .
          </p>
        )}
      </section>
      {launches.filter((l) => !isUpcoming(l)).length > 0 && (
        <section className="dashboard-section">
          <SectionTitle title="Recent launches" />
          {launches
            .filter((l) => !isUpcoming(l))
            .map((l) => (
              <LaunchRow key={l.id} launch={l} />
            ))}
        </section>
      )}
      <p className="settings-note">
        Following and reminders are saved on this browser. They persist between
        visits; clearing site data removes them.
      </p>
    </div>
  );
}
export function TodayPage() {
  const { data, now, settings, t } = useOrbital();
  const today = data.launches.filter(
    (l) =>
      l.net &&
      ["second", "minute", "hour", "day"].includes(l.precision) &&
      dateKey(l.net, zoneFor(settings, l)) ===
        dateKey(new Date(now), zoneFor(settings, l)),
  );
  const next = data.launches.find(
    (l) => isUpcoming(l) && l.net && Date.parse(l.net) > now && hasExactTime(l),
  );
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">
            {formatDate(new Date(now).toISOString(), zoneFor(settings), {
              weekday: "long",
              month: "long",
              day: "numeric",
            }).toUpperCase()}
          </div>
          <h1>
            {t("Today")} in space<span className="accent">.</span>
          </h1>
          <p>What&apos;s leaving Earth today?</p>
        </div>
        <span className="muted" style={{ fontSize: 12 }}>
          {today.length} launches in the loaded schedule
        </span>
      </div>
      {today.length ? (
        <LaunchGrid launches={today} />
      ) : (
        <div className="today-empty">
          <Sunrise size={34} />
          <h2>{t("No orbital launches scheduled today.")}</h2>
          <p>
            A quiet day on the launch pads. The next mission is already on the
            horizon.
          </p>
          <Link href="/launches" className="button secondary">
            {t("Browse launches")}
          </Link>
        </div>
      )}
      {next && (
        <section className="today-next">
          <SectionTitle eyebrow="COMING UP NEXT" title="Next launch" />
          <LaunchRow launch={next} />
          <div style={{ paddingTop: 25 }}>
            <Countdown launch={next} />
          </div>
        </section>
      )}
      <p className="settings-note">
        Today is calculated in your selected time zone. Unknown dates and
        month-only schedules are excluded. Coverage is limited to the loaded
        upcoming and recent records.
      </p>
    </div>
  );
}
export function SettingsPage() {
  const { settings, setSettings, t, toast } = useOrbital();
  const update = (key: keyof UserSettings, value: string) =>
    setSettings({ [key]: value });
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">MAKE ORBITAL YOUR OWN</div>
          <h1>
            {t("Settings")}
            <span className="accent">.</span>
          </h1>
          <p>A quieter interface. A clearer perspective.</p>
        </div>
      </div>
      <div className="setting-sections">
        <section className="settings-section">
          <h2>Appearance</h2>
          <Setting
            icon={<Moon size={20} />}
            title="Theme"
            description="Choose how ORBITAL looks on this device."
          >
            <Segment
              value={settings.theme}
              onChange={(v) => update("theme", v)}
              options={[
                { label: "Dark", value: "dark" },
                { label: "Light", value: "light" },
                { label: "System", value: "system" },
              ]}
            />
          </Setting>
          <Setting
            icon={<Sparkles size={20} />}
            title="Animations"
            description="System reduced-motion preference is always respected."
          >
            <Segment
              value={settings.animations}
              onChange={(v) => update("animations", v)}
              options={[
                { label: "Full", value: "full" },
                { label: "Reduced", value: "reduced" },
              ]}
            />
          </Setting>
        </section>
        <section className="settings-section">
          <h2>Time & region</h2>
          <Setting
            icon={<Clock size={20} />}
            title="Time zone"
            description="All source timestamps remain stored in UTC."
          >
            <Segment
              value={settings.timezone}
              onChange={(v) => update("timezone", v)}
              options={[
                { label: "UTC", value: "utc" },
                { label: "Local time", value: "local" },
                { label: "Launch site time", value: "site" },
              ]}
            />
          </Setting>
          <Setting
            icon={<Languages size={20} />}
            title="Language"
            description="Mission names and source content retain their original language."
          >
            <Segment
              value={settings.language}
              onChange={(v) => update("language", v)}
              options={[
                { label: "English", value: "en" },
                { label: "简体中文", value: "zh" },
              ]}
            />
          </Setting>
          <Setting
            icon={<Ruler size={20} />}
            title="Units"
            description="Vehicle specifications use your preferred units."
          >
            <Segment
              value={settings.units}
              onChange={(v) => update("units", v)}
              options={[
                { label: "Metric", value: "metric" },
                { label: "Imperial", value: "imperial" },
              ]}
            />
          </Setting>
        </section>
        <section className="settings-section">
          <h2>Notifications & privacy</h2>
          <Setting
            icon={<Bell size={20} />}
            title="Browser notifications"
            description="Optional alerts while ORBITAL is open."
          >
            <button
              className="button secondary"
              onClick={async () => {
                if ("Notification" in window) {
                  const p = await Notification.requestPermission();
                  toast(
                    p === "granted"
                      ? "Notifications enabled"
                      : "Notifications blocked or unavailable",
                  );
                } else toast("This browser does not support notifications");
              }}
            >
              Enable
            </button>
          </Setting>
          <Setting
            icon={<ShieldCheck size={20} />}
            title="On-device storage"
            description="Your follows, reminders and preferences stay on this device."
          >
            <Link href="/following" className="button ghost">
              {t("Following")}
            </Link>
          </Setting>
        </section>
        <section className="settings-section">
          <h2>Install ORBITAL</h2>
          <p className="settings-note">
            <Download size={15} /> On iPhone, open Safari&apos;s Share menu and
            choose “Add to Home Screen”. On supported desktop and Android
            browsers, use the install control in the address bar. Previously
            visited pages and the latest cached data remain available offline.
          </p>
        </section>
        <p className="settings-note">
          ORBITAL 1.0 · Powered by The Space Devs Launch Library 2.
          <br />
          English is fully supported. Chinese navigation and common controls are
          available; mission descriptions and some detailed interface copy
          remain in English.
        </p>
      </div>
    </div>
  );
}
function Setting({
  icon,
  title,
  description,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  const { t } = useOrbital();
  return (
    <div className="setting-row">
      <div>
        {icon}
        <span>
          <strong>{t(title)}</strong>
          <p>{description}</p>
        </span>
      </div>
      {children}
    </div>
  );
}
