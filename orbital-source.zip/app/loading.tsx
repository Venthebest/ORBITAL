import { LaunchSkeleton } from "@/components/launch-card";
export default function Loading() {
  return (
    <div className="page-container" aria-label="Loading launch data">
      <div
        className="skeleton"
        style={{ height: 32, width: 240, marginBottom: 25 }}
      />
      <div className="skeleton skeleton-hero" />
      <div className="mission-grid" style={{ marginTop: 30 }}>
        {[1, 2, 3, 4].map((i) => (
          <LaunchSkeleton key={i} />
        ))}
      </div>
    </div>
  );
}
