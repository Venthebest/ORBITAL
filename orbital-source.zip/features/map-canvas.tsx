"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import * as maplibregl from "maplibre-gl";
import Link from "next/link";
import {
  Plus,
  Minus,
  Globe2,
  Search,
  X,
  MapPin,
  Navigation,
  ArrowUpRight,
} from "lucide-react";
import { useOrbital } from "@/components/app-provider";
import { isUpcoming } from "@/lib/time";
import type { LaunchPad } from "@/types";
type LocatedPad = LaunchPad & { latitude: number; longitude: number };
export default function MapCanvas() {
  const { data, settings, toast } = useOrbital(),
    params = useSearchParams();
  const container = useRef<HTMLDivElement>(null),
    map = useRef<maplibregl.Map | null>(null),
    markers = useRef<maplibregl.Marker[]>([]);
  const [ready, setReady] = useState(false),
    [mapRevision, setMapRevision] = useState(0),
    [failed, setFailed] = useState(false),
    [query, setQuery] = useState(""),
    [selected, setSelected] = useState<LocatedPad | null>(null),
    [coords, setCoords] = useState("00.000° N / 00.000° E");
  const pads = useMemo(
    () =>
      data.pads.filter(
        (p): p is LocatedPad =>
          p.latitude !== null &&
          p.longitude !== null &&
          Number.isFinite(p.latitude) &&
          Number.isFinite(p.longitude) &&
          p.id !== "unknown" &&
          p.celestialBody === "Earth",
      ),
    [data.pads],
  );
  const visible = useMemo(
    () =>
      pads.filter(
        (p) =>
          !p.id.startsWith("location-") ||
          !pads.some(
            (other) =>
              !other.id.startsWith("location-") &&
              other.location === p.location,
          ),
      ),
    [pads],
  );
  const focus = (p: LocatedPad) => {
    setSelected(p);
    setQuery("");
    if (map.current)
      map.current.flyTo({
        center: [p.longitude, p.latitude],
        zoom: 10,
        speed: 1.15,
        essential: false,
        animate:
          settings.animations !== "reduced" &&
          !window.matchMedia("(prefers-reduced-motion: reduce)").matches,
      });
  };
  useEffect(() => {
    if (!container.current || map.current) return;
    try {
      maplibregl.setWorkerUrl("/vendor/maplibre/maplibre-gl-worker.mjs");
      const m = new maplibregl.Map({
        container: container.current,
        center: [12, 19],
        zoom: 1.45,
        minZoom: 1,
        maxZoom: 12,
        attributionControl: { compact: true },
        style: {
          version: 8,
          sources: {
            countries: { type: "geojson", data: "/countries.geojson" },
          },
          layers: [
            {
              id: "background",
              type: "background",
              paint: { "background-color": "#0a111b" },
            },
            {
              id: "land",
              type: "fill",
              source: "countries",
              paint: { "fill-color": "#17212d" },
            },
            {
              id: "borders",
              type: "line",
              source: "countries",
              paint: {
                "line-color": "#2c3746",
                "line-width": 0.6,
                "line-opacity": 0.6,
              },
            },
          ],
        },
      });
      map.current = m;
      m.on("load", () => setReady(true));
      m.on("moveend", () => setMapRevision((n) => n + 1));
      m.on("move", () => {
        const c = m.getCenter();
        setCoords(
          `${Math.abs(c.lat).toFixed(3)}° ${c.lat >= 0 ? "N" : "S"} / ${Math.abs(c.lng).toFixed(3)}° ${c.lng >= 0 ? "E" : "W"}`,
        );
      });
      m.on("error", (e) => {
        if (e.error.message.includes("WebGL")) setFailed(true);
      });
      return () => {
        m.remove();
        map.current = null;
      };
    } catch {
      setFailed(true);
    }
  }, []);
  useEffect(() => {
    if (!ready || !map.current) return;
    markers.current.forEach((m) => m.remove());
    const current = map.current;
    const clusters: { pads: LocatedPad[]; x: number; y: number }[] = [];
    for (const pad of visible) {
      const point = current.project([pad.longitude, pad.latitude]);
      const cluster = clusters.find(
        (c) => Math.hypot(point.x - c.x, point.y - c.y) < 48,
      );
      if (cluster) cluster.pads.push(pad);
      else clusters.push({ pads: [pad], x: point.x, y: point.y });
    }
    markers.current = clusters.map((cluster) => {
      const group = cluster.pads,
        p = group[0],
        button = document.createElement("button");
      button.className =
        "map-marker" + (group.length > 1 ? " map-cluster" : "");
      button.setAttribute(
        "aria-label",
        group.length > 1
          ? `Explore ${group.length} nearby launch pads and sites`
          : p.name + ", " + p.country,
      );
      button.title =
        group.length > 1 ? `${group.length} nearby launch sites` : p.name;
      if (group.length > 1) button.textContent = String(group.length);
      button.onclick = () => {
        setQuery("");
        if (group.length > 1) {
          const bounds = new maplibregl.LngLatBounds();
          group.forEach((p) => bounds.extend([p.longitude, p.latitude]));
          current.fitBounds(bounds, {
            padding: 95,
            maxZoom: 12,
            animate:
              settings.animations !== "reduced" &&
              !window.matchMedia("(prefers-reduced-motion: reduce)").matches,
          });
        } else {
          setSelected(p);
          current.flyTo({
            center: [p.longitude, p.latitude],
            zoom: 10,
            animate: settings.animations !== "reduced",
          });
        }
      };
      return new maplibregl.Marker({ element: button })
        .setLngLat([p.longitude, p.latitude])
        .addTo(current);
    });
    return () => markers.current.forEach((m) => m.remove());
  }, [ready, visible, settings.animations, mapRevision]);
  useEffect(() => {
    const id = params.get("site");
    if (id && ready) {
      const p = pads.find((p) => p.id === id);
      if (p) {
        setSelected(p);
        map.current?.jumpTo({ center: [p.longitude, p.latitude], zoom: 10 });
      }
    }
  }, [params, ready, pads]);
  const nearby = selected
    ? data.launches.filter(
        (l) =>
          l.launchPad.id === selected.id ||
          l.launchPad.location === selected.location,
      )
    : [];
  const next = nearby.find(isUpcoming);
  return (
    <>
      <div className="map-container">
        <div
          className="map-canvas"
          ref={container}
          aria-label="Interactive map of global launch sites"
        />
        {failed && (
          <div className="map-fallback">
            <Globe2 size={40} />
            <h2 style={{ margin: "20px 0" }}>Interactive map unavailable</h2>
            <p>
              Your browser may not support WebGL. Explore the complete launch
              site directory below.
            </p>
          </div>
        )}
        <div className="map-search">
          <div className="map-search-input">
            <Search size={16} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Find a launch site…"
              aria-label="Search launch sites"
            />
            {query && (
              <button
                aria-label="Clear map search"
                onClick={() => setQuery("")}
              >
                <X size={14} />
              </button>
            )}
          </div>
          {query && (
            <div className="map-results">
              {pads
                .filter((p) =>
                  (p.name + " " + p.location + " " + p.country)
                    .toLowerCase()
                    .includes(query.toLowerCase()),
                )
                .slice(0, 15)
                .map((p) => (
                  <button key={p.id} onClick={() => focus(p)}>
                    {p.name}
                    <small>{p.location}</small>
                  </button>
                ))}
            </div>
          )}
        </div>
        <div className="map-controls">
          <button
            className="icon-button"
            aria-label="Zoom in"
            onClick={() => map.current?.zoomIn()}
          >
            <Plus size={18} />
          </button>
          <button
            className="icon-button"
            aria-label="Zoom out"
            onClick={() => map.current?.zoomOut()}
          >
            <Minus size={18} />
          </button>
          <button
            className="icon-button"
            aria-label="Reset global view"
            onClick={() => {
              setSelected(null);
              map.current?.flyTo({
                center: [12, 19],
                zoom: 1.45,
                animate: settings.animations !== "reduced",
              });
            }}
          >
            <Globe2 size={18} />
          </button>
          <button
            className="icon-button"
            aria-label="Locate me"
            onClick={() => {
              if (!navigator.geolocation) {
                toast("Location is unavailable");
                return;
              }
              navigator.geolocation.getCurrentPosition(
                (p) =>
                  map.current?.flyTo({
                    center: [p.coords.longitude, p.coords.latitude],
                    zoom: 4,
                  }),
                () =>
                  toast(
                    "Location access unavailable. You can search any launch site.",
                  ),
              );
            }}
          >
            <Navigation size={17} />
          </button>
        </div>
        <div className="map-readout">
          <span>{coords}</span>
          <span>WGS 84 · {visible.length} SITES</span>
        </div>
        {selected && (
          <div
            className="map-site-panel"
            role="region"
            aria-label="Selected launch site"
          >
            <button
              className="icon-button panel-close"
              onClick={() => setSelected(null)}
              aria-label="Close launch site"
            >
              <X size={16} />
            </button>
            <div
              className="eyebrow"
              style={{ color: "#bd906f", marginBottom: 8 }}
            >
              LAUNCH SITE
            </div>
            <h3>{selected.name}</h3>
            <p>{selected.location}</p>
            <dl className="data-list">
              <div>
                <dt>Coordinates</dt>
                <dd>
                  {selected.latitude.toFixed(4)}°,{" "}
                  {selected.longitude.toFixed(4)}°
                </dd>
              </div>
              <div>
                <dt>Country</dt>
                <dd>{selected.country}</dd>
              </div>
              <div>
                <dt>Historical launches</dt>
                <dd>
                  {selected.totalLaunches === null
                    ? "Not published"
                    : selected.totalLaunches.toLocaleString()}
                </dd>
              </div>
              <div>
                <dt>Upcoming in loaded schedule</dt>
                <dd>{nearby.filter(isUpcoming).length}</dd>
              </div>
            </dl>
            {next ? (
              <Link href={"/launch/" + next.id} className="button primary">
                Next:{" "}
                {next.mission.name.length > 24
                  ? next.mission.name.slice(0, 24) + "…"
                  : next.mission.name}
                <ArrowUpRight size={15} />
              </Link>
            ) : (
              <p style={{ marginTop: 14 }}>
                No upcoming mission in the loaded schedule.
              </p>
            )}
          </div>
        )}
      </div>
      <div className="section-title">
        <h2>Launch site directory</h2>
        <span className="muted" style={{ fontSize: 11 }}>
          Select a site to explore
        </span>
      </div>
      <div className="map-sites-list">
        {visible
          .sort((a, b) => a.location.localeCompare(b.location))
          .map((p) => (
            <button
              key={p.id}
              onClick={() => {
                focus(p);
                container.current?.scrollIntoView({
                  behavior: "smooth",
                  block: "center",
                });
              }}
            >
              <MapPin size={16} />
              <span>
                <strong>{p.name}</strong>
                <small>{p.location}</small>
              </span>
              <span>{p.totalLaunches?.toLocaleString() || "—"}</span>
            </button>
          ))}
      </div>
    </>
  );
}
