import type { Launch } from "@/types";
/** Provider identity and explicitly listed mission agencies, excluding program-wide membership. */
export function launchMatchesAgency(l: Launch, id: string) {
  return l.agency.id === id || l.mission.agencyIds?.includes(id) === true;
}
