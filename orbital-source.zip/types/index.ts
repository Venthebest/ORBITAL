import { z } from "zod";
export const SourceSchema = z.object({
  name: z.string(),
  sourceUrl: z.string(),
  sourcePriority: z.number(),
  lastUpdated: z.string(),
  confidence: z.enum(["high", "medium", "low"]),
});
export type Source = z.infer<typeof SourceSchema>;
export type LaunchStatus =
  | "scheduled"
  | "go"
  | "tbc"
  | "tbd"
  | "delayed"
  | "hold"
  | "in-flight"
  | "success"
  | "failure"
  | "partial-success"
  | "cancelled";
export interface Agency {
  id: string;
  name: string;
  abbrev: string;
  country: string;
  countryCode: string;
  description: string;
  type: string;
  founded: string | null;
  headquarters: string | null;
  website: string | null;
  logo: string | null;
  image: string | null;
  sources: Source[];
}
export interface Rocket {
  id: string;
  name: string;
  family: string;
  manufacturer: string;
  country: string;
  description: string;
  image: string | null;
  imageSource: string | null;
  height: number | null;
  diameter: number | null;
  mass: number | null;
  stages: number | null;
  leoCapacity: number | null;
  gtoCapacity: number | null;
  firstFlight: string | null;
  active: boolean | null;
  reusable: boolean | null;
  totalLaunches: number | null;
  successfulLaunches: number | null;
  failedLaunches: number | null;
  sources: Source[];
}
export interface LaunchPad {
  celestialBody: string;
  id: string;
  name: string;
  location: string;
  country: string;
  countryCode: string;
  latitude: number | null;
  longitude: number | null;
  timezone: string;
  totalLaunches: number | null;
  mapUrl: string | null;
  sources: Source[];
}
export interface Payload {
  name: string;
  type: string;
  description: string;
  mass: number | null;
  sourceUrl: string;
}
export interface Mission {
  agencyIds?: string[];
  name: string;
  description: string;
  type: string;
  orbit: string;
  orbitName: string;
}
export interface TimelineEvent {
  id: string;
  name: string;
  time: string | null;
  description: string;
  kind: "official" | "scheduled" | "estimated";
  completed: boolean;
}
export interface Launch {
  id: string;
  name: string;
  slug: string;
  description: string;
  status: LaunchStatus;
  statusDescription: string;
  net: string | null;
  windowStart: string | null;
  windowEnd: string | null;
  precision:
    | "second"
    | "minute"
    | "hour"
    | "day"
    | "week"
    | "month"
    | "quarter"
    | "half-year"
    | "year"
    | "decade"
    | "unknown";
  precisionLabel: string;
  lastUpdated: string;
  latestUpdate: { text: string; time: string; sourceUrl: string | null } | null;
  agency: Agency;
  rocket: Rocket;
  mission: Mission;
  payloads: Payload[];
  launchPad: LaunchPad;
  country: string;
  orbit: string;
  livestream: { url: string; title: string; official: boolean }[];
  image: string | null;
  imageSource: string | null;
  patch: string | null;
  weather: string | null;
  probability: number | null;
  sources: Source[];
  timeline: TimelineEvent[];
}
export interface LaunchDataset {
  pageOffsets?: { upcoming: number; archive: number };
  launches: Launch[];
  agencies: Agency[];
  rockets: Rocket[];
  pads: LaunchPad[];
  updatedAt: string;
  fetchedAt: string;
  upcomingTotal: number;
  pastTotal: number;
  mode: "live" | "cached";
  error: string | null;
  coverage: string;
}
export const LaunchValidation = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  net: z.string().datetime().nullable(),
  windowStart: z.string().datetime().nullable(),
  windowEnd: z.string().datetime().nullable(),
  status: z.enum([
    "scheduled",
    "go",
    "tbc",
    "tbd",
    "delayed",
    "hold",
    "in-flight",
    "success",
    "failure",
    "partial-success",
    "cancelled",
  ]),
  precisionLabel: z.string(),
  agency: z.object({ id: z.string(), name: z.string() }),
  rocket: z.object({ id: z.string(), name: z.string() }),
  mission: z.object({ name: z.string(), type: z.string(), orbit: z.string() }),
  timeline: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      kind: z.enum(["official", "scheduled", "estimated"]),
    }),
  ),
  launchPad: z.object({
    celestialBody: z.string(),
    latitude: z.number().min(-90).max(90).nullable(),
    longitude: z.number().min(-180).max(180).nullable(),
  }),
  sources: z.array(SourceSchema).min(1),
});
export interface UserSettings {
  theme: "dark" | "light" | "system";
  timezone: "utc" | "local" | "site";
  language: "en" | "zh";
  units: "metric" | "imperial";
  animations: "full" | "reduced";
}
export interface Reminder {
  launchId: string;
  offset: number;
  changes: boolean;
  firedFor: string | null;
  lastNet: string | null;
  lastStatus: LaunchStatus;
  createdAt: string;
  lastChecked?: string;
}

export const UserSettingsSchema = z.object({
  theme: z.enum(["dark", "light", "system"]),
  timezone: z.enum(["utc", "local", "site"]),
  language: z.enum(["en", "zh"]),
  units: z.enum(["metric", "imperial"]),
  animations: z.enum(["full", "reduced"]),
});
