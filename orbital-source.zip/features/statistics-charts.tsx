"use client";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useOrbital } from "@/components/app-provider";
import { isUpcoming } from "@/lib/time";
import type { Launch } from "@/types";
function groups(items: Launch[], get: (l: Launch) => string) {
  const m = new Map<string, number>();
  items.forEach((l) => m.set(get(l), (m.get(get(l)) || 0) + 1));
  return [...m]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);
}
function Bars({ items }: { items: { name: string; count: number }[] }) {
  const max = Math.max(1, ...items.map((i) => i.count));
  return (
    <div className="bar-list">
      {items.slice(0, 6).map((i) => (
        <div key={i.name}>
          <div className="bar-item-head">
            <span>{i.name}</span>
            <span>{i.count}</span>
          </div>
          <div className="bar-track">
            <div
              className="bar-fill"
              style={{ width: (i.count / max) * 100 + "%" }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: readonly { value?: number | string }[];
  label?: string | number;
}) {
  return active && payload?.length ? (
    <div className="chart-tooltip">
      {label}
      <strong>{payload[0].value} loaded launches</strong>
    </div>
  ) : null;
}
export default function StatisticsCharts() {
  const { data } = useOrbital();
  const recent = data.launches.filter((l) => !isUpcoming(l));
  const months = groups(
    data.launches.filter(
      (l) =>
        l.net &&
        ["second", "minute", "hour", "day", "month"].includes(l.precision),
    ),
    (l) => l.net!.slice(0, 7),
  )
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((i) => ({
      name: new Intl.DateTimeFormat("en", {
        month: "short",
        year: "2-digit",
        timeZone: "UTC",
      }).format(new Date(i.name + "-01T00:00:00Z")),
      count: i.count,
    }));
  return (
    <div className="chart-grid">
      <section className="chart-block" style={{ gridColumn: "1 / -1" }}>
        <h3>Mission activity by month</h3>
        <p>
          Recent & upcoming missions in the loaded dataset · timing may change
        </p>
        <div className="chart">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={months}
              margin={{ left: -15, right: 10, top: 15, bottom: 0 }}
            >
              <defs>
                <linearGradient id="activity-fill" x1="0" y1="0" x2="0" y2="1">
                  <stop
                    offset="0%"
                    stopColor="var(--accent)"
                    stopOpacity={0.18}
                  />
                  <stop
                    offset="100%"
                    stopColor="var(--accent)"
                    stopOpacity={0}
                  />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--line)" vertical={false} />
              <XAxis
                dataKey="name"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "var(--muted)", fontSize: 10 }}
                minTickGap={25}
                dy={8}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: "var(--muted)", fontSize: 10 }}
                allowDecimals={false}
              />
              <Tooltip
                content={<ChartTooltip />}
                cursor={{ stroke: "var(--line-strong)" }}
              />
              <Area
                type="monotone"
                dataKey="count"
                stroke="var(--accent)"
                strokeWidth={2}
                fill="url(#activity-fill)"
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>
      <section className="chart-block">
        <h3>Launches by country</h3>
        <p>Recent sample · launch site country</p>
        <Bars items={groups(recent, (l) => l.launchPad.country)} />
      </section>
      <section className="chart-block">
        <h3>Launches by agency</h3>
        <p>Recent sample · launch service provider</p>
        <Bars items={groups(recent, (l) => l.agency.name)} />
      </section>
      <section className="chart-block">
        <h3>Launches by rocket</h3>
        <p>Recent sample · vehicle configuration</p>
        <Bars items={groups(recent, (l) => l.rocket.name)} />
      </section>
      <section className="chart-block">
        <h3>Launches by orbit</h3>
        <p>Recent sample · target orbit</p>
        <Bars items={groups(recent, (l) => l.mission.orbitName)} />
      </section>
    </div>
  );
}
