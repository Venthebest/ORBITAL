"use client";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useMemo,
} from "react";
import {
  QueryClient,
  QueryClientProvider,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import type { LaunchDataset, UserSettings, Reminder, Launch } from "@/types";
import { hasExactTime } from "@/lib/time";
import { LaunchValidation, UserSettingsSchema } from "@/types";
import { mergeClientData } from "@/lib/merge";
import { translate } from "@/lib/i18n";
import staticSnapshot from "@/data/client-snapshot.json";
const staticDeploy = process.env.NEXT_PUBLIC_STATIC_DEPLOY === "1";
const defaults: UserSettings = {
  theme: "dark",
  timezone: "utc",
  language: "en",
  units: "metric",
  animations: "full",
};
interface Store {
  settings: UserSettings;
  setSettings: (s: Partial<UserSettings>) => void;
  following: string[];
  toggleFollow: (type: string, id: string) => void;
  isFollowed: (type: string, id: string) => boolean;
  reminders: Reminder[];
  saveReminder: (r: Reminder) => void;
  removeReminder: (id: string) => void;
  toast: (message: string) => void;
  t: (s: string) => string;
  now: number;
  data: LaunchDataset;
  loadMore: (range: "upcoming" | "archive") => Promise<void>;
  loadingMore: boolean;
  refresh: () => void;
  refreshing: boolean;
  online: boolean;
}
const Context = createContext<Store | null>(null);
export function useOrbital() {
  const value = useContext(Context);
  if (!value) throw new Error("ORBITAL provider missing");
  return value;
}
export function AppProvider({
  children,
  initialData,
}: {
  children: React.ReactNode;
  initialData?: LaunchDataset;
}) {
  const [client] = useState(() => new QueryClient());
  const bootstrap = initialData || (staticSnapshot as LaunchDataset);
  return (
    <QueryClientProvider client={client}>
      <StoreProvider initialData={bootstrap}>{children}</StoreProvider>
    </QueryClientProvider>
  );
}
function StoreProvider({
  children,
  initialData,
}: {
  children: React.ReactNode;
  initialData: LaunchDataset;
}) {
  const [settings, updateSettings] = useState(defaults),
    [following, setFollowing] = useState<string[]>([]),
    [reminders, setReminders] = useState<Reminder[]>([]),
    [hydrated, setHydrated] = useState(false),
    [now, setNow] = useState(() => Date.parse(initialData.fetchedAt)),
    [message, setMessage] = useState(""),
    [online, setOnline] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const client = useQueryClient();
  const {
    data = initialData,
    refetch,
    isFetching,
    error,
  } = useQuery({
    queryKey: ["launches"],
    queryFn: async () => {
      const r = await fetch("/api/launches", {
        signal: AbortSignal.timeout(25000),
      });
      if (!r.ok) throw new Error("Unable to refresh data");
      const fresh: LaunchDataset = await r.json();
      const prior = client.getQueryData<LaunchDataset>(["launches"]);
      const d = {
        ...mergeClientData(fresh, prior?.launches || []),
        pageOffsets: prior?.pageOffsets,
      };
      try {
        localStorage.setItem("orbital-data-v2", JSON.stringify(d));
      } catch {}
      return d;
    },
    initialData,
    initialDataUpdatedAt: Date.parse(initialData.fetchedAt),
    staleTime: 60000,
    refetchInterval: (query) =>
      query.state.data?.launches.some(
        (l) =>
          l.net &&
          ["go", "hold", "in-flight"].includes(l.status) &&
          Math.abs(Date.parse(l.net) - Date.now()) < 86400000,
      )
        ? 60000
        : 300000,
    refetchOnWindowFocus: true,
    retry: 1,
  });
  const displayData = useMemo(
    () =>
      error
        ? {
            ...data,
            error: online
              ? "Unable to update launch data. Showing the last successful cache."
              : "Offline. Showing cached launch data.",
          }
        : data,
    [data, error, online],
  );
  const toast = useCallback((s: string) => setMessage(s), []);
  useEffect(() => {
    try {
      const local: LaunchDataset = JSON.parse(
        localStorage.getItem("orbital-data-v2") || "null",
      );
      if (
        local &&
        Date.parse(local.fetchedAt) > Date.parse(initialData.fetchedAt) &&
        Array.isArray(local.launches) &&
        Array.isArray(local.agencies) &&
        Array.isArray(local.rockets) &&
        Array.isArray(local.pads) &&
        local.launches.every((l) => LaunchValidation.safeParse(l).success)
      ) {
        client.setQueryData(["launches"], local);
      }
    } catch {}
    try {
      const saved = JSON.parse(
        localStorage.getItem("orbital-preferences-v1") || "null",
      );
      if (saved) {
        const parsed = UserSettingsSchema.safeParse({
          ...defaults,
          ...saved.settings,
        });
        if (parsed.success) updateSettings(parsed.data);
        setFollowing(
          Array.isArray(saved.following)
            ? saved.following.filter((v: unknown) => typeof v === "string")
            : [],
        );
        setReminders(Array.isArray(saved.reminders) ? saved.reminders : []);
      }
    } catch {}
    setHydrated(true);
    setOnline(navigator.onLine);
    const net = () => setOnline(navigator.onLine);
    window.addEventListener("online", net);
    window.addEventListener("offline", net);
    setNow(Date.now());
    const tick = setInterval(() => setNow(Date.now()), 1000);
    if (process.env.NODE_ENV === "production" && "serviceWorker" in navigator)
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    return () => {
      clearInterval(tick);
      window.removeEventListener("online", net);
      window.removeEventListener("offline", net);
    };
  }, [client, initialData.fetchedAt]);
  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(
        "orbital-preferences-v1",
        JSON.stringify({ settings, following, reminders }),
      );
    } catch {}
    const media = window.matchMedia("(prefers-color-scheme: light)");
    const apply = () => {
      document.documentElement.dataset.theme =
        settings.theme === "system"
          ? media.matches
            ? "light"
            : "dark"
          : settings.theme;
      document.documentElement.dataset.motion = settings.animations;
      document.documentElement.lang =
        settings.language === "zh" ? "zh-CN" : "en";
    };
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [settings, following, reminders, hydrated]);
  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => setMessage(""), 4200);
    return () => clearTimeout(timer);
  }, [message]);
  useEffect(() => {
    if (!hydrated || !reminders.length) return;
    let changed = false;
    const next = reminders.map((r) => {
      const l = data.launches.find((l) => l.id === r.launchId);
      if (!l) return r;
      const netChange = r.changes && r.lastNet !== l.net,
        statusChange = r.changes && r.lastStatus !== l.status;
      const threshold = l.net ? Date.parse(l.net) - r.offset * 60000 : Infinity;
      const due =
        hasExactTime(l) &&
        ["go", "scheduled", "in-flight"].includes(l.status) &&
        threshold <= now &&
        threshold > Date.parse(r.lastChecked || r.createdAt) &&
        now - threshold < 90000 &&
        r.firedFor !== l.net;
      if (netChange || statusChange || due) {
        const remaining = l.net
          ? Math.max(0, Math.ceil((Date.parse(l.net) - now) / 60000))
          : 0;
        const text = netChange
          ? `${l.mission.name}: launch time changed.`
          : statusChange
            ? `${l.mission.name}: ${l.status}.`
            : remaining
              ? `${l.mission.name}: published launch time in ${remaining} minutes.`
              : `${l.mission.name}: published launch time reached. Awaiting source status.`;
        toast(text);
        if (
          "Notification" in window &&
          Notification.permission === "granted" &&
          "serviceWorker" in navigator
        )
          void navigator.serviceWorker.ready
            .then((reg) =>
              reg.showNotification("ORBITAL · Mission reminder", {
                body: text,
                icon: "/icon-192.png",
                tag: l.id,
              }),
            )
            .catch(() => {});
        changed = true;
        return {
          ...r,
          firedFor: due ? l.net : r.firedFor,
          lastNet: l.net,
          lastStatus: l.status,
          lastChecked: new Date(now).toISOString(),
        };
      }
      return r;
    });
    if (changed) setReminders(next);
  }, [now, data, reminders, hydrated, toast]);
  const loadMore = useCallback(
    async (range: "upcoming" | "archive") => {
      if (staticDeploy) {
        toast("This shared edition displays the verified deployment snapshot");
        return;
      }
      if (loadingMore) return;
      setLoadingMore(true);
      try {
        const current =
          client.getQueryData<LaunchDataset>(["launches"]) || initialData;
        const offset = current.pageOffsets?.[range] || 100;
        const response = await fetch(
          `/api/launches/more?range=${range}&offset=${offset}`,
          { signal: AbortSignal.timeout(25000) },
        );
        const page = await response.json();
        if (!response.ok)
          throw new Error(page.error || "Unable to load more missions");
        if (
          !Array.isArray(page.launches) ||
          !page.launches.every(
            (l: unknown) => LaunchValidation.safeParse(l).success,
          )
        )
          throw new Error("The source page could not be validated");
        const next = {
          ...mergeClientData(current, page.launches),
          pageOffsets: {
            upcoming: current.pageOffsets?.upcoming || 100,
            archive: current.pageOffsets?.archive || 100,
            [range]: page.nextOffset,
          },
        };
        client.setQueryData(["launches"], next);
        try {
          localStorage.setItem("orbital-data-v2", JSON.stringify(next));
        } catch {}
        toast(`${page.launches.length} additional source missions loaded`);
      } catch (e) {
        toast(e instanceof Error ? e.message : "Unable to load more missions");
      } finally {
        setLoadingMore(false);
      }
    },
    [client, initialData, loadingMore, toast],
  );
  const toggleFollow = useCallback(
    (type: string, id: string) => {
      const key = `${type}:${id}`;
      setFollowing((prev) =>
        prev.includes(key) ? prev.filter((x) => x !== key) : [...prev, key],
      );
      toast(
        following.includes(key)
          ? "Removed from following"
          : "Added to your orbit",
      );
    },
    [following, toast],
  );
  const value = useMemo(
    () => ({
      settings,
      setSettings: (s: Partial<UserSettings>) =>
        updateSettings((prev) => ({ ...prev, ...s })),
      following,
      toggleFollow,
      isFollowed: (type: string, id: string) =>
        following.includes(`${type}:${id}`),
      reminders,
      saveReminder: (r: Reminder) => {
        setReminders((p) => [...p.filter((i) => i.launchId !== r.launchId), r]);
        toast("Reminder saved on this device");
      },
      removeReminder: (id: string) =>
        setReminders((p) => p.filter((r) => r.launchId !== id)),
      toast,
      t: (s: string) => translate(s, settings.language),
      now,
      data: displayData,
      refresh: () => {
        if (staticDeploy)
          toast(
            "This shared edition displays the verified deployment snapshot",
          );
        else void refetch();
      },
      refreshing: isFetching,
      online,
      loadingMore,
      loadMore,
    }),
    [
      settings,
      following,
      reminders,
      toggleFollow,
      toast,
      now,
      displayData,
      refetch,
      isFetching,
      online,
      loadingMore,
      loadMore,
    ],
  );
  return (
    <Context.Provider value={value}>
      {children}
      <div className={`toast ${message ? "visible" : ""}`} role="status">
        {message}
      </div>
    </Context.Provider>
  );
}
export function remindFor(
  launch: Launch,
  offset: number,
  changes: boolean,
): Reminder {
  return {
    launchId: launch.id,
    offset,
    changes,
    firedFor: null,
    lastNet: launch.net,
    lastStatus: launch.status,
    createdAt: new Date().toISOString(),
  };
}
