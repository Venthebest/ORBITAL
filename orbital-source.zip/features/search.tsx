"use client";
import * as Dialog from "@radix-ui/react-dialog";
import {
  Search,
  Rocket,
  Satellite,
  MapPin,
  CornerDownLeft,
  ArrowUp,
  ArrowDown,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useOrbital } from "@/components/app-provider";
export function CommandPalette({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { data, t } = useOrbital(),
    [query, setQuery] = useState(""),
    [active, setActive] = useState(0),
    router = useRouter(),
    input = useRef<HTMLInputElement>(null);
  const results = useMemo(() => {
    const q = query.toLowerCase();
    const all = [
      ...data.launches.map((l) => ({
        id: l.id,
        title: l.mission.name,
        subtitle: l.rocket.name,
        category: "Launches",
        href: "/launch/" + l.id,
        icon: Rocket,
        search: l.name + " " + l.description,
      })),
      ...data.rockets.map((r) => ({
        id: r.id,
        title: r.name,
        subtitle: r.manufacturer,
        category: "Rockets",
        href: "/rocket/" + r.id,
        icon: Rocket,
        search: r.name,
      })),
      ...data.agencies.map((a) => ({
        id: a.id,
        title: a.name,
        subtitle: a.country,
        category: "Agencies",
        href: "/agency/" + a.id,
        icon: Satellite,
        search: a.name + " " + a.abbrev,
      })),
      ...data.pads.map((p) => ({
        id: p.id,
        title: p.name,
        subtitle: p.location,
        category: "Launch sites",
        href: "/map?site=" + p.id,
        icon: MapPin,
        search: p.name + " " + p.location,
      })),
    ].filter(
      (r) =>
        !q ||
        (r.search + " " + r.title + " " + r.subtitle).toLowerCase().includes(q),
    );
    return ["Launches", "Rockets", "Agencies", "Launch sites"].flatMap(
      (category) =>
        all
          .filter((r) => r.category === category)
          .slice(0, category === "Launches" ? 8 : 5),
    );
  }, [data, query]);
  useEffect(() => {
    if (open) {
      setQuery("");
      setActive(0);
    }
  }, [open]);
  useEffect(() => {
    document
      .getElementById(`result-${active}`)
      ?.scrollIntoView({ block: "nearest" });
  }, [active]);
  const go = (href: string) => {
    router.push(href);
    onOpenChange(false);
  };
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="modal-overlay search-overlay" />
        <Dialog.Content
          className="command-panel"
          onOpenAutoFocus={(e) => {
            e.preventDefault();
            input.current?.focus();
          }}
        >
          <Dialog.Title className="sr-only">Global launch search</Dialog.Title>
          <Dialog.Description className="sr-only">
            Search missions, payload descriptions, rockets, agencies and launch
            sites. Use arrow keys to select a result.
          </Dialog.Description>
          <div className="command-input">
            <Search size={22} />
            <input
              ref={input}
              placeholder={t("Search missions, rockets, agencies…")}
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setActive(0);
              }}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown") {
                  e.preventDefault();
                  setActive((i) =>
                    Math.max(0, Math.min(i + 1, results.length - 1)),
                  );
                }
                if (e.key === "ArrowUp") {
                  e.preventDefault();
                  setActive((i) => Math.max(i - 1, 0));
                }
                if (e.key === "Enter" && results[active])
                  go(results[active].href);
              }}
              role="combobox"
              aria-label="Search missions, rockets, agencies and sites"
              aria-expanded={true}
              aria-controls="search-results"
              aria-activedescendant={`result-${active}`}
            />
            <Dialog.Close className="icon-button" aria-label="Close search">
              <X size={17} />
            </Dialog.Close>
          </div>
          <div className="command-results" id="search-results" role="listbox">
            {!query && (
              <div className="eyebrow command-hint">
                EXPLORE THE LAUNCH NETWORK
              </div>
            )}
            {results.map((r, i) => (
              <div key={r.category + r.id}>
                {(i === 0 || results[i - 1].category !== r.category) && (
                  <div className="command-category">{t(r.category)}</div>
                )}
                <button
                  id={`result-${i}`}
                  role="option"
                  aria-selected={i === active}
                  className={i === active ? "active" : ""}
                  onMouseEnter={() => setActive(i)}
                  onClick={() => go(r.href)}
                >
                  <span className="command-icon">
                    <r.icon size={18} />
                  </span>
                  <span>
                    <strong>{r.title}</strong>
                    <small>{r.subtitle}</small>
                  </span>
                  <CornerDownLeft size={15} />
                </button>
              </div>
            ))}
            {!results.length && (
              <div className="empty-state">
                <p>No results for “{query}”</p>
              </div>
            )}
          </div>
          <div className="command-footer">
            <span>
              <ArrowUp size={12} />
              <ArrowDown size={12} /> Navigate
            </span>
            <span>
              <CornerDownLeft size={12} /> Open
            </span>
            <span>
              <kbd>esc</kbd> Close
            </span>
            <span className="command-count">{results.length} results</span>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
