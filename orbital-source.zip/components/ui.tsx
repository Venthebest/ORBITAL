"use client";
import { useState } from "react";
import * as Popover from "@radix-ui/react-popover";
import * as Dialog from "@radix-ui/react-dialog";
import {
  ChevronDown,
  X,
  Star,
  SearchX,
  ExternalLink,
  Rocket as RocketIcon,
} from "lucide-react";
import { useOrbital } from "./app-provider";
import type { Launch } from "@/types";
import { countdown, hasExactTime, statusLabel } from "@/lib/time";
export function Logo({ small = false }: { small?: boolean }) {
  return (
    <span className={`brand ${small ? "small" : ""}`}>
      <svg viewBox="0 0 36 36" aria-hidden="true">
        <circle
          cx="18"
          cy="18"
          r="10.5"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.2"
        />
        <ellipse
          cx="18"
          cy="18"
          rx="18"
          ry="5.7"
          transform="rotate(-35 18 18)"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.7"
        />
        <circle cx="29.5" cy="10" r="2.2" fill="var(--accent)" />
      </svg>
      {!small && (
        <span>
          ORBITAL<span className="brand-stop">.</span>
        </span>
      )}
    </span>
  );
}
export function Status({ launch }: { launch: Launch }) {
  const { t } = useOrbital();
  return (
    <span className={`status status-${launch.status}`}>
      <i />
      {t(statusLabel[launch.status])}
    </span>
  );
}
export function FollowButton({
  type,
  id,
  full = false,
}: {
  type: string;
  id: string;
  full?: boolean;
}) {
  const { isFollowed, toggleFollow, t } = useOrbital();
  const yes = isFollowed(type, id);
  return (
    <button
      className={`${full ? "button secondary" : "icon-button"} follow ${yes ? "selected" : ""}`}
      aria-label={yes ? "Unfollow" : "Follow"}
      aria-pressed={yes}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleFollow(type, id);
      }}
    >
      <Star size={17} fill={yes ? "currentColor" : "none"} />
      {full && t(yes ? "Following mission" : "Follow mission")}
    </button>
  );
}
export function Countdown({
  launch,
  compact = false,
}: {
  launch: Launch;
  compact?: boolean;
}) {
  const { now } = useOrbital();
  const value = countdown(launch, now);
  if (compact) return <span className="countdown-compact">{value}</span>;
  if (!hasExactTime(launch) || !value.startsWith("T−"))
    return (
      <div className="countdown-unconfirmed">
        <span className="eyebrow">
          {launch.status === "hold" ? "COUNTDOWN PAUSED" : "LAUNCH TIME"}
        </span>
        <strong>{value}</strong>
        <span className="muted">
          {launch.status === "hold"
            ? "Awaiting an official resume update"
            : "Timing is subject to mission updates"}
        </span>
      </div>
    );
  const parts = value.slice(2).split(":");
  return (
    <div className="countdown" aria-label={value}>
      <span className="countdown-prefix">T−</span>
      {parts.map((part, i) => (
        <div className="countdown-group" key={i}>
          <span className="countdown-number" key={part}>
            {part}
          </span>
          <span>{["DAYS", "HOURS", "MINUTES", "SECONDS"][i]}</span>
        </div>
      ))}
    </div>
  );
}
export function Picker({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: { label: string; value: string }[];
  onChange: (value: string) => void;
}) {
  const { t } = useOrbital();
  return (
    <Popover.Root>
      <Popover.Trigger asChild>
        <button
          className={`picker ${value ? "active" : ""}`}
          aria-label={label}
        >
          <span>
            {t(options.find((o) => o.value === value)?.label || label)}
          </span>
          <ChevronDown size={14} />
        </button>
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content
          className="popover picker-menu"
          sideOffset={8}
          align="start"
        >
          <span className="eyebrow">{label}</span>
          <div className="picker-options">
            {options.map((o) => (
              <Popover.Close asChild key={o.value}>
                <button
                  className={value === o.value ? "chosen" : ""}
                  onClick={() => onChange(o.value)}
                >
                  {t(o.label)}
                  {value === o.value && <span className="accent">✓</span>}
                </button>
              </Popover.Close>
            ))}
          </div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}
export function Segment({
  value,
  options,
  onChange,
}: {
  value: string;
  options: { value: string; label: string; icon?: React.ReactNode }[];
  onChange: (value: string) => void;
}) {
  const { t } = useOrbital();
  return (
    <div className="segmented" role="group">
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          aria-pressed={value === o.value}
          className={value === o.value ? "active" : ""}
        >
          {o.icon}
          {t(o.label)}
        </button>
      ))}
    </div>
  );
}
export function Modal({
  open,
  onOpenChange,
  title,
  description,
  children,
  fullscreen = false,
}: {
  fullscreen?: boolean;
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="modal-overlay" />
        <Dialog.Content
          className={`modal-panel ${fullscreen ? "fullscreen-panel" : ""}`}
        >
          <div className="modal-head">
            <Dialog.Title>{title}</Dialog.Title>
            <Dialog.Close className="icon-button" aria-label="Close">
              <X size={20} />
            </Dialog.Close>
          </div>
          <Dialog.Description className="muted">
            {description || "Manage your mission preferences."}
          </Dialog.Description>
          {children}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
export function EmptyState({
  title = "No launches found",
  description = "Try clearing some filters.",
  action,
}: {
  title?: string;
  description?: string;
  action?: React.ReactNode;
}) {
  const { t } = useOrbital();
  return (
    <div className="empty-state">
      <SearchX size={32} />
      <h3>{t(title)}</h3>
      <p>{t(description)}</p>
      {action}
    </div>
  );
}
export function SectionTitle({
  eyebrow,
  title,
  aside,
}: {
  eyebrow?: string;
  title: string;
  aside?: React.ReactNode;
}) {
  const { t } = useOrbital();
  return (
    <div className="section-title">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h2>{t(title)}</h2>
      </div>
      {aside}
    </div>
  );
}
export function SafeImage({
  src,
  alt,
  className,
  priority = false,
}: {
  src: string | null;
  alt: string;
  className?: string;
  priority?: boolean;
}) {
  const [failed, setFailed] = useState<string | null>(null);
  return src && failed !== src ? (
    <img
      className={className}
      src={src}
      alt={alt}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      onError={() => setFailed(src)}
    />
  ) : (
    <div className={`image-fallback ${className || ""}`}>
      <RocketIcon size={32} />
    </div>
  );
}
export function SourceLink({
  url,
  children,
}: {
  url: string;
  children: React.ReactNode;
}) {
  return (
    <a href={url} target="_blank" rel="noreferrer" className="source-link">
      {children}
      <ExternalLink size={14} />
    </a>
  );
}
