import type { Launch, Source } from "@/types";
/** Official updates are explicitly authored facts, never inferred from unstructured pages. */
export interface VerifiedMissionUpdate {
  launchId: string;
  source: Source;
  patch: Partial<
    Pick<
      Launch,
      "net" | "windowStart" | "windowEnd" | "status" | "weather" | "probability"
    >
  >;
}
export class OfficialSourceProvider {
  name = "Official sources";
  priority = 100;
  merge(launch: Launch, updates: VerifiedMissionUpdate[]): Launch {
    return updates
      .filter((u) => u.launchId === launch.id && u.source.sourcePriority >= 80)
      .sort(
        (a, b) =>
          Date.parse(a.source.lastUpdated) - Date.parse(b.source.lastUpdated),
      )
      .reduce(
        (l, u) => ({
          ...l,
          ...u.patch,
          lastUpdated: u.source.lastUpdated,
          sources: [u.source, ...l.sources],
        }),
        launch,
      );
  }
}
