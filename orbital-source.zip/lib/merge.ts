import type { Launch, LaunchDataset } from "@/types";
export function mergeClientData(
  dataset: LaunchDataset,
  extra: Launch[],
): LaunchDataset {
  const missions = new Map<string, Launch>();
  for (const l of [...extra, ...dataset.launches]) {
    const old = missions.get(l.id);
    if (!old || Date.parse(l.lastUpdated) >= Date.parse(old.lastUpdated))
      missions.set(l.id, l);
  }
  const launches = [...missions.values()].sort(
    (a, b) =>
      Date.parse(a.net || "9999-01-01") - Date.parse(b.net || "9999-01-01"),
  );
  const unique = <T extends { id: string }>(items: T[]) => [
    ...new Map(items.map((i) => [i.id, i])).values(),
  ];
  return {
    ...dataset,
    launches,
    agencies: unique([...dataset.agencies, ...launches.map((l) => l.agency)]),
    rockets: unique([...dataset.rockets, ...launches.map((l) => l.rocket)]),
    pads: unique([...dataset.pads, ...launches.map((l) => l.launchPad)]),
  };
}
