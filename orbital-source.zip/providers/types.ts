import type { Launch, Source } from "@/types";
export interface ProviderResult {
  launches: Launch[];
  fetchedAt: string;
  total: number;
  source: Source;
}
export interface LaunchProvider {
  name: string;
  priority: number;
  fetchUpcoming(): Promise<ProviderResult>;
  fetchRecent(): Promise<ProviderResult>;
  fetchLaunch(id: string): Promise<Launch>;
}
