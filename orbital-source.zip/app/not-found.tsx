import Link from "next/link";
import { Logo } from "@/components/ui";
export default function NotFound() {
  return (
    <div className="page-container">
      <div className="empty-state">
        <Logo small />
        <div className="eyebrow">404 / OUTSIDE THE FLIGHT PATH</div>
        <h1 style={{ fontSize: 30 }}>Mission not found.</h1>
        <p>
          This page may have moved, or the mission is not in the available
          source data.
        </p>
        <Link href="/launches" className="button primary">
          Explore launches
        </Link>
      </div>
    </div>
  );
}
