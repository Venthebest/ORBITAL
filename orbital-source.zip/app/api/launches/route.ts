import { getLaunchDataset, snapshot } from "@/services/launch-service";
export const dynamic = "force-static";
export const revalidate = 600;
export async function GET() {
  const data =
    process.env.NEXT_PUBLIC_STATIC_DEPLOY === "1"
      ? snapshot
      : await getLaunchDataset();
  return Response.json(data, {
    headers: {
      "Cache-Control": "public, s-maxage=120, stale-while-revalidate=600",
    },
  });
}
