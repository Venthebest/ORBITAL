"use client";
import dynamic from "next/dynamic";
import { useOrbital } from "@/components/app-provider";
const InteractiveMap = dynamic(() => import("./map-canvas"), {
  ssr: false,
  loading: () => (
    <div
      className="skeleton skeleton-map"
      aria-label="Loading launch site map"
    />
  ),
});
export function MapPage() {
  const { t, data } = useOrbital();
  return (
    <div className="page-container map-page">
      <div className="page-heading">
        <div>
          <div className="eyebrow">THE WORLD&apos;S GATEWAYS TO SPACE</div>
          <h1>
            {t("Launch network")}
            <span className="accent">.</span>
          </h1>
          <p>Explore the launch pads connecting our planet to the universe.</p>
        </div>
        <span className="muted" style={{ fontSize: 12 }}>
          {data.pads.length} launch pads & locations · Global coverage
        </span>
      </div>
      <InteractiveMap />
      <p className="settings-note" style={{ marginBottom: 30 }}>
        Geography: Natural Earth · Map rendering: MapLibre · Launch site data:
        Launch Library 2. Historical counts are source-reported totals, not
        counts from the loaded mission sample.
      </p>
    </div>
  );
}
