import { unstable_cache } from "next/cache";
import { snapshot } from "./launch-service";
import { fetchJSON } from "@/lib/http";
import { normalizeAgency, normalizeRocket } from "@/adapters/launch-library";
const fetchRecord = unstable_cache(
  async (kind: "agency" | "rocket", id: string) => {
    const headers: HeadersInit = process.env.LL2_API_TOKEN
      ? { Authorization: `Token ${process.env.LL2_API_TOKEN}` }
      : { Accept: "application/json" };
    const url = `https://ll.thespacedevs.com/2.3.0/${kind === "agency" ? "agencies" : "launcher_configurations"}/${id}/?mode=detailed`;
    return fetchJSON(url, { headers, cache: "no-store" });
  },
  ["ll2-entity-record-v1"],
  { revalidate: 259200 },
);
export async function getRocket(id: string) {
  const known = snapshot.rockets.find((r) => r.id === id);
  if (known) return known;
  if (!/^\d{1,8}$/.test(id)) return null;
  try {
    const r = normalizeRocket(
      await fetchRecord("rocket", id),
      new Date().toISOString(),
    );
    return r.id === id ? r : null;
  } catch {
    return null;
  }
}
export async function getAgency(id: string) {
  const known = snapshot.agencies.find((a) => a.id === id);
  if (known) return known;
  if (!/^\d{1,8}$/.test(id)) return null;
  try {
    const a = normalizeAgency(
      await fetchRecord("agency", id),
      new Date().toISOString(),
    );
    return a.id === id ? a : null;
  } catch {
    return null;
  }
}
