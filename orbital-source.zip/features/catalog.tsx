"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import {
  Search,
  ArrowUpRight,
  Rocket as RocketIcon,
  Satellite,
  GitCompareArrows,
  ExternalLink,
  ChevronRight,
} from "lucide-react";
import { useOrbital } from "@/components/app-provider";
import {
  Picker,
  FollowButton,
  SafeImage,
  EmptyState,
  SectionTitle,
  SourceLink,
} from "@/components/ui";
import { LaunchRow } from "@/components/launch-card";
import { launchMatchesAgency } from "@/lib/agency";
import { isUpcoming } from "@/lib/time";
import type { Agency, Rocket } from "@/types";
export function RocketsPage() {
  const { data, t } = useOrbital(),
    [q, setQ] = useState(""),
    [country, setCountry] = useState(""),
    [active, setActive] = useState("");
  const rockets = data.rockets.filter(
    (r) =>
      (r.name + " " + r.manufacturer + " " + r.family)
        .toLowerCase()
        .includes(q.toLowerCase()) &&
      (!country || r.country === country) &&
      (!active || String(r.active) === active),
  );
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">ENGINEERED TO LEAVE EARTH</div>
          <h1>
            {t("Fleet directory")}
            <span className="accent">.</span>
          </h1>
          <p>Explore the vehicles that make space accessible.</p>
        </div>
        <Link href="/compare" className="button secondary">
          <GitCompareArrows size={16} />
          Compare vehicles
        </Link>
      </div>
      <div className="filter-surface">
        <div className="filter-top">
          <div className="filter-search">
            <Search size={17} />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Find a rocket or manufacturer…"
              aria-label="Search rockets"
            />
          </div>
          <div className="filters">
            <Picker
              label="Country"
              value={country}
              options={[
                { label: "All countries", value: "" },
                ...Array.from(new Set(data.rockets.map((r) => r.country)))
                  .sort()
                  .map((c) => ({ label: c, value: c })),
              ]}
              onChange={setCountry}
            />
            <Picker
              label="Vehicle status"
              value={active}
              onChange={setActive}
              options={[
                { label: "All statuses", value: "" },
                { label: "Active vehicles", value: "true" },
                { label: "Retired vehicles", value: "false" },
              ]}
            />
          </div>
        </div>
      </div>
      <div className="result-bar">
        <span>{rockets.length} vehicle configurations</span>
        <span>Source-verified specifications</span>
      </div>
      {rockets.length ? (
        <div className="collection-grid">
          {rockets.map((r) => (
            <RocketCard key={r.id} rocket={r} />
          ))}
        </div>
      ) : (
        <EmptyState />
      )}
      <p className="settings-note">
        Different variants are listed as separate configurations. Manufacturer
        totals and variant totals are kept separate. Unpublished specifications
        remain unavailable.
      </p>
    </div>
  );
}
function RocketCard({ rocket: r }: { rocket: Rocket }) {
  return (
    <article className="entity-card">
      <Link href={"/rocket/" + r.id} className="entity-art">
        <SafeImage
          src={r.name.includes("Falcon 9") ? "/falcon9-pad.jpg" : r.image}
          alt={r.name + " launch vehicle"}
        />
      </Link>
      <div className="entity-body">
        <div className="entity-top">
          <span className="eyebrow">{r.manufacturer}</span>
          <FollowButton type="rocket" id={r.id} />
        </div>
        <Link href={"/rocket/" + r.id}>
          <h3>{r.name}</h3>
        </Link>
        <p>
          {r.country} ·{" "}
          {r.active === true
            ? "Active"
            : r.active === false
              ? "Retired"
              : "Status unpublished"}
          {r.reusable ? " · Reusable" : ""}
        </p>
        <div className="entity-footer">
          <span>
            {r.height !== null ? r.height + " m tall" : "Height not published"}
          </span>
          <Link href={"/rocket/" + r.id} className="text-link">
            Vehicle details
            <ArrowUpRight size={15} />
          </Link>
        </div>
      </div>
    </article>
  );
}
export function RocketDetail({ rocket: initial }: { rocket: Rocket }) {
  const { data, settings, t } = useOrbital(),
    r = data.rockets.find((v) => v.id === initial.id) || initial;
  const related = data.launches.filter((l) => l.rocket.id === r.id);
  const length = (v: number | null) =>
    v === null
      ? "Not published"
      : settings.units === "imperial"
        ? (v * 3.28084).toLocaleString("en", { maximumFractionDigits: 1 }) +
          " ft"
        : v.toLocaleString() + " m";
  const mass = (v: number | null, tonnes = false) =>
    v === null
      ? "Not published"
      : settings.units === "imperial"
        ? ((tonnes ? v * 1000 : v) * 2.20462).toLocaleString("en", {
            maximumFractionDigits: 0,
          }) + " lb"
        : v.toLocaleString() + (tonnes ? " t" : " kg");
  return (
    <div className="page-container">
      <div className="breadcrumb">
        <Link href="/rockets">{t("Rockets")}</Link>
        <ChevronRight size={12} />
        {r.name}
      </div>
      <section className="detail-hero">
        <div className="detail-hero-content">
          <div className="eyebrow">{r.manufacturer} / VEHICLE PROFILE</div>
          <h1>{r.name}</h1>
          <p>
            {r.country} · {r.family || "Launch vehicle"}
          </p>
          <div className="detail-actions">
            <FollowButton type="rocket" id={r.id} full />
            <Link href="/compare" className="button secondary">
              <GitCompareArrows size={15} />
              Compare
            </Link>
          </div>
          <div
            className="entity-fact-strip"
            style={{ gridTemplateColumns: "1fr 1fr", marginBottom: 0 }}
          >
            <div>
              <span>Height</span>
              <strong>{length(r.height)}</strong>
            </div>
            <div>
              <span>LEO payload</span>
              <strong style={{ fontSize: 21 }}>{mass(r.leoCapacity)}</strong>
            </div>
          </div>
        </div>
        <div className="detail-hero-photo">
          <SafeImage
            src={r.name.includes("Falcon 9") ? "/falcon9-pad.jpg" : r.image}
            alt={r.name + " rocket at launch pad"}
          />
          <span className="photo-caption">
            {r.name.includes("Falcon 9")
              ? "NASA / Keegan Barber · Crew-9 vehicle"
              : r.imageSource}
          </span>
        </div>
      </section>
      <div className="detail-layout" style={{ marginTop: 35 }}>
        <div>
          <section className="detail-section">
            <h2>Vehicle overview</h2>
            <p>
              {r.description ||
                "The source has not published a detailed description for this vehicle."}
            </p>
          </section>
          <section className="detail-section">
            <h2>Technical specifications</h2>
            <dl className="data-list">
              <Fact label="Manufacturer" value={r.manufacturer} />
              <Fact label="Country" value={r.country} />
              <Fact label="Height" value={length(r.height)} />
              <Fact label="Diameter" value={length(r.diameter)} />
              <Fact label="Launch mass" value={mass(r.mass, true)} />
              <Fact label="Stages" value={r.stages ?? "Not published"} />
              <Fact label="LEO payload" value={mass(r.leoCapacity)} />
              <Fact label="GTO payload" value={mass(r.gtoCapacity)} />
              <Fact
                label="First flight (configuration)"
                value={r.firstFlight || "Not published"}
              />
              <Fact
                label="Reusable"
                value={
                  r.reusable === null
                    ? "Not published"
                    : r.reusable
                      ? "Yes"
                      : "No"
                }
              />
            </dl>
          </section>
          <SectionTitle title="Upcoming launches" />
          {related.filter(isUpcoming).length ? (
            related
              .filter(isUpcoming)
              .slice(0, 10)
              .map((l) => <LaunchRow key={l.id} launch={l} />)
          ) : (
            <EmptyState
              title="No launches found"
              description="No upcoming launches for this vehicle in the loaded schedule."
            />
          )}
          <SectionTitle title="Recent launches" />
          {related
            .filter((l) => !isUpcoming(l))
            .slice(0, 6)
            .map((l) => (
              <LaunchRow key={l.id} launch={l} />
            ))}
        </div>
        <aside className="detail-info-box">
          <h3>Configuration record</h3>
          <dl className="data-list">
            <Fact
              label="Total launches"
              value={r.totalLaunches ?? "Not published"}
            />
            <Fact
              label="Successful"
              value={r.successfulLaunches ?? "Not published"}
            />
            <Fact label="Failed" value={r.failedLaunches ?? "Not published"} />
            <Fact
              label="Success rate"
              value={
                r.totalLaunches && r.successfulLaunches !== null
                  ? ((r.successfulLaunches / r.totalLaunches) * 100).toFixed(
                      1,
                    ) + "%"
                  : "Not available"
              }
            />
            <Fact
              label="Vehicle status"
              value={
                r.active === null
                  ? "Not published"
                  : r.active
                    ? "Active"
                    : "Retired"
              }
            />
          </dl>
          <p className="settings-note">
            Counts describe this configuration as reported by Launch Library 2.
            Definitions and data completeness can vary by vehicle.
          </p>
          {r.sources.map((s) => (
            <div style={{ marginTop: 15 }} key={s.sourceUrl}>
              <SourceLink url={s.sourceUrl}>{s.name}</SourceLink>
            </div>
          ))}
        </aside>
      </div>
    </div>
  );
}
export function AgenciesPage() {
  const { data, t } = useOrbital(),
    [q, setQ] = useState(""),
    [country, setCountry] = useState("");
  const agencies = data.agencies.filter(
    (a) =>
      a.id !== "unknown" &&
      a.name !== "Unknown" &&
      (a.name + " " + a.abbrev).toLowerCase().includes(q.toLowerCase()) &&
      (!country || a.country === country),
  );
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">PEOPLE BEHIND THE MISSIONS</div>
          <h1>
            {t("Agency directory")}
            <span className="accent">.</span>
          </h1>
          <p>The organizations expanding our place in the universe.</p>
        </div>
      </div>
      <div className="filter-surface">
        <div className="filter-top">
          <div className="filter-search">
            <Search size={17} />
            <input
              aria-label="Search agencies"
              placeholder="Search an agency or operator…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <Picker
            label="Country"
            value={country}
            onChange={setCountry}
            options={[
              { label: "All countries", value: "" },
              ...Array.from(new Set(data.agencies.map((a) => a.country)))
                .sort()
                .map((c) => ({ label: c, value: c })),
            ]}
          />
        </div>
      </div>
      {agencies.length ? (
        <div className="collection-grid">
          {agencies.map((a) => (
            <AgencyCard agency={a} key={a.id} />
          ))}
        </div>
      ) : (
        <EmptyState />
      )}
    </div>
  );
}
function AgencyCard({ agency: a }: { agency: Agency }) {
  const { data } = useOrbital();
  return (
    <article className="entity-card">
      <Link href={"/agency/" + a.id} className="agency-art">
        {a.logo ? (
          <SafeImage src={a.logo} alt={a.name + " logo"} />
        ) : (
          <span>{a.abbrev || a.name.slice(0, 2)}</span>
        )}
      </Link>
      <div className="entity-body">
        <div className="entity-top">
          <span className="eyebrow">{a.country}</span>
          <FollowButton type="agency" id={a.id} />
        </div>
        <Link href={"/agency/" + a.id}>
          <h3>{a.name}</h3>
        </Link>
        <p>
          {a.type}
          {a.founded ? " · Founded " + a.founded : ""}
        </p>
        <div className="entity-footer">
          <span>
            {
              data.launches.filter(
                (l) => launchMatchesAgency(l, a.id) && isUpcoming(l),
              ).length
            }{" "}
            upcoming missions
          </span>
          <Link
            href={"/agency/" + a.id}
            aria-label={"View " + a.name}
            className="icon-button"
          >
            <ArrowUpRight size={17} />
          </Link>
        </div>
      </div>
    </article>
  );
}
export function AgencyDetail({ agency: initial }: { agency: Agency }) {
  const { data, t } = useOrbital(),
    a = data.agencies.find((x) => x.id === initial.id) || initial;
  const launches = data.launches.filter((l) => launchMatchesAgency(l, a.id));
  const upcoming = launches.filter(isUpcoming),
    recent = launches.filter((l) => !isUpcoming(l));
  const fleet = data.rockets.filter((r) => r.manufacturer === a.name);
  return (
    <div className="page-container">
      <div className="breadcrumb">
        <Link href="/agencies">{t("Agencies")}</Link>
        <ChevronRight size={12} />
        {a.name}
      </div>
      <div className="agency-profile">
        <div className="agency-profile-logo">
          {a.logo ? (
            <SafeImage src={a.logo} alt={a.name + " logo"} />
          ) : (
            <Satellite size={32} />
          )}
        </div>
        <div className="page-heading">
          <div>
            <div className="eyebrow">{a.country} / AGENCY PROFILE</div>
            <h1>{a.name}</h1>
            <p>
              {a.type}
              {a.founded ? " · Est. " + a.founded : ""}
            </p>
          </div>
        </div>
      </div>
      <div className="detail-actions">
        <FollowButton full type="agency" id={a.id} />
        {a.website && (
          <a
            href={a.website}
            className="button secondary"
            target="_blank"
            rel="noreferrer"
          >
            Official website
            <ExternalLink size={15} />
          </a>
        )}
      </div>
      <div className="entity-fact-strip">
        <div>
          <span>Upcoming in loaded schedule</span>
          <strong>{upcoming.length}</strong>
        </div>
        <div>
          <span>Recent in loaded archive</span>
          <strong>{recent.length}</strong>
        </div>
        <div>
          <span>Vehicle configurations</span>
          <strong>{fleet.length}</strong>
        </div>
        <div>
          <span>Founded</span>
          <strong>{a.founded || "—"}</strong>
        </div>
      </div>
      <div className="detail-layout">
        <div>
          <section className="detail-section">
            <h2>About {a.abbrev || a.name}</h2>
            <p>
              {a.description ||
                "The source has not provided a detailed organization profile."}
            </p>
          </section>
          <SectionTitle title="Upcoming launches" />
          {upcoming.length ? (
            upcoming
              .slice(0, 10)
              .map((l) => <LaunchRow key={l.id} launch={l} />)
          ) : (
            <EmptyState
              title="No launches found"
              description="No upcoming missions in the loaded schedule."
            />
          )}
          <div style={{ marginTop: 30 }}>
            <SectionTitle title="Recent launches" />
            {recent.slice(0, 8).map((l) => (
              <LaunchRow key={l.id} launch={l} />
            ))}
          </div>
          <div style={{ marginTop: 35 }}>
            <SectionTitle title="Rocket fleet" />
            {fleet.length ? (
              fleet.slice(0, 12).map((r) => (
                <Link
                  className="directory-row"
                  href={"/rocket/" + r.id}
                  key={r.id}
                >
                  <RocketIcon size={18} />
                  <strong>{r.name}</strong>
                  <span className="directory-row-value">
                    {r.active ? "Active" : "Vehicle details"}
                  </span>
                  <ArrowUpRight size={15} />
                </Link>
              ))
            ) : (
              <p className="muted">
                No manufacturer-linked vehicles in this dataset.
              </p>
            )}
          </div>
        </div>
        <aside className="detail-info-box">
          <h3>Organization</h3>
          <dl className="data-list">
            <Fact label="Country" value={a.country} />
            <Fact label="Type" value={a.type} />
            <Fact label="Founded" value={a.founded || "Not published"} />
            <Fact
              label="Headquarters"
              value={a.headquarters || "Not published"}
            />
          </dl>
          <p className="settings-note">
            Launch activity is calculated from loaded missions. Space agencies
            may participate in launches operated by another provider.
          </p>
          {a.sources.map((s) => (
            <div style={{ marginTop: 15 }} key={s.sourceUrl}>
              <SourceLink url={s.sourceUrl}>{s.name}</SourceLink>
            </div>
          ))}
        </aside>
      </div>
    </div>
  );
}
function Fact({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}
export function ComparePage() {
  const { data, settings } = useOrbital();
  const defaults = ["Falcon 9 Block 5", "Vulcan", "Ariane 62"];
  const [ids, setIDs] = useState(() =>
    defaults.map(
      (n) =>
        data.rockets.find((r) => r.name.includes(n))?.id || data.rockets[0].id,
    ),
  );
  const rows = useMemo(
    () => [
      { label: "Manufacturer", get: (r: Rocket) => r.manufacturer },
      { label: "Country", get: (r: Rocket) => r.country },
      {
        label: "Height",
        get: (r: Rocket) =>
          r.height === null
            ? "Not published"
            : settings.units === "metric"
              ? r.height + " m"
              : (r.height * 3.28084).toFixed(1) + " ft",
      },
      {
        label: "Mass",
        get: (r: Rocket) =>
          r.mass === null
            ? "Not published"
            : settings.units === "metric"
              ? r.mass.toLocaleString() + " t"
              : (r.mass * 1000 * 2.20462).toLocaleString("en", {
                  maximumFractionDigits: 0,
                }) + " lb",
      },
      { label: "Stages", get: (r: Rocket) => r.stages ?? "Not published" },
      {
        label: "LEO payload",
        get: (r: Rocket) =>
          r.leoCapacity === null
            ? "Not published"
            : settings.units === "metric"
              ? r.leoCapacity.toLocaleString() + " kg"
              : (r.leoCapacity * 2.20462).toLocaleString("en", {
                  maximumFractionDigits: 0,
                }) + " lb",
      },
      {
        label: "GTO payload",
        get: (r: Rocket) =>
          r.gtoCapacity === null
            ? "Not published"
            : settings.units === "metric"
              ? r.gtoCapacity.toLocaleString() + " kg"
              : (r.gtoCapacity * 2.20462).toLocaleString("en", {
                  maximumFractionDigits: 0,
                }) + " lb",
      },
      {
        label: "First flight",
        get: (r: Rocket) => r.firstFlight || "Not published",
      },
      {
        label: "Total launches",
        get: (r: Rocket) => r.totalLaunches ?? "Not published",
      },
      {
        label: "Successful",
        get: (r: Rocket) => r.successfulLaunches ?? "Not published",
      },
      {
        label: "Failed",
        get: (r: Rocket) => r.failedLaunches ?? "Not published",
      },
      {
        label: "Success rate",
        get: (r: Rocket) =>
          r.totalLaunches && r.successfulLaunches !== null
            ? ((r.successfulLaunches / r.totalLaunches) * 100).toFixed(1) + "%"
            : "Not published",
      },
    ],
    [settings.units],
  );
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">VEHICLES, SIDE BY SIDE</div>
          <h1>
            Launch vehicle comparison<span className="accent">.</span>
          </h1>
          <p>Compare source-reported configuration specifications.</p>
        </div>
      </div>
      <div className="filters">
        {ids.map((id, i) => (
          <Picker
            label={"Vehicle " + (i + 1)}
            value={id}
            key={i}
            onChange={(id) =>
              setIDs((p) => p.map((v, n) => (n === i ? id : v)))
            }
            options={data.rockets.map((r) => ({ label: r.name, value: r.id }))}
          />
        ))}
      </div>
      <div className="compare-scroll">
        <table className="compare-table">
          <thead>
            <tr>
              <th>Specification</th>
              {ids.map((id, i) => (
                <th key={i}>{data.rockets.find((r) => r.id === id)?.name}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.label}>
                <td>{row.label}</td>
                {ids.map((id, i) => (
                  <td key={i}>
                    {data.rockets.find((r) => r.id === id)
                      ? row.get(data.rockets.find((r) => r.id === id)!)
                      : "—"}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="settings-note">
        Variant-specific counts from Launch Library 2. Payload performance
        depends on the mission profile, orbit inclination and recovery
        requirements; figures do not guarantee identical mission capability.
      </p>
    </div>
  );
}
export { RocketCard, AgencyCard };
