import type { Agency } from "@/types";
export const officialAgencies: Agency[] = [
  {
    id: "nasa",
    name: "NASA",
    abbrev: "NASA",
    country: "United States",
    countryCode: "USA",
    description:
      "The National Aeronautics and Space Administration is the United States civil space agency. NASA conducts science, exploration, aeronautics research and human spaceflight, working with international partners and commercial launch providers.",
    type: "Government",
    founded: "1958",
    headquarters: "Washington, D.C.",
    website: "https://www.nasa.gov/",
    logo: null,
    image: null,
    sources: [
      {
        name: "NASA · About",
        sourceUrl: "https://www.nasa.gov/about/",
        sourcePriority: 100,
        lastUpdated: "2026-09-30T00:00:00Z",
        confidence: "high",
      },
    ],
  },
  {
    id: "esa",
    name: "European Space Agency",
    abbrev: "ESA",
    country: "Europe",
    countryCode: "EUR",
    description:
      "The European Space Agency coordinates the space programs of its member states. Its activities include science, Earth observation, human and robotic exploration, navigation, telecommunications and space transportation.",
    type: "Intergovernmental",
    founded: "1975",
    headquarters: "Paris, France",
    website: "https://www.esa.int/",
    logo: null,
    image: null,
    sources: [
      {
        name: "ESA · About",
        sourceUrl: "https://www.esa.int/About_Us",
        sourcePriority: 100,
        lastUpdated: "2026-09-30T00:00:00Z",
        confidence: "high",
      },
    ],
  },
];
