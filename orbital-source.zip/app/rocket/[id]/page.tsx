import { getRocket } from "@/services/catalog-service";
import { RocketDetail } from "@/features/catalog";
import { notFound } from "next/navigation";
import { snapshot } from "@/services/launch-service";
export function generateStaticParams() {
  return snapshot.rockets.map(({ id }) => ({ id }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const id = (await params).id;
  const r = await getRocket(id);
  return {
    title: r ? `${r.name} — Specifications & Launches` : "Rocket not found",
  };
}
export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const id = (await params).id;
  const r = await getRocket(id);
  if (!r) notFound();
  return <RocketDetail rocket={r} />;
}
