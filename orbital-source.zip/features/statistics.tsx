"use client";
import dynamic from "next/dynamic";
import { useOrbital } from "@/components/app-provider";
import { isUpcoming, formatDate } from "@/lib/time";
import { useYearStatistics } from "@/hooks/use-year-statistics";
const Charts = dynamic(() => import("./statistics-charts"), {
  ssr: false,
  loading: () => (
    <div className="chart-grid">
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="skeleton chart-block" />
      ))}
    </div>
  ),
});
export function StatisticsPage() {
  const yearStats = useYearStatistics();
  const { data, t } = useOrbital();
  const completed = data.launches.filter((l) => !isUpcoming(l));
  const success = completed.filter((l) => l.status === "success").length;
  return (
    <div className="page-container">
      <div className="page-heading">
        <div>
          <div className="eyebrow">THE BIGGER PICTURE</div>
          <h1>
            {t("Statistics")}
            <span className="accent">.</span>
          </h1>
          <p>A measured view of global launch activity.</p>
        </div>
        <span className="muted" style={{ fontSize: 12 }}>
          {yearStats.year} · Global orbital totals
        </span>
      </div>
      <div className="stats-top">
        <div className="stat-block">
          <span>Orbital launches this year</span>
          <strong>{yearStats.total}</strong>
          <small>Completed attempts · {yearStats.year}</small>
        </div>
        <div className="stat-block">
          <span>Confirmed success rate</span>
          <strong>
            {((yearStats.success / yearStats.total) * 100).toFixed(1)}
            <span style={{ fontSize: 24 }}>%</span>
          </strong>
          <small>
            {yearStats.success} / {yearStats.total} attempts
          </small>
        </div>
        <div className="stat-block">
          <span>Upcoming in source archive</span>
          <strong>{data.upcomingTotal}</strong>
          <small>
            {data.launches.filter(isUpcoming).length} loaded in ORBITAL
          </small>
        </div>
        <div className="stat-block">
          <span>Recent sample success</span>
          <strong>
            {((success / Math.max(1, completed.length)) * 100).toFixed(1)}
            <span style={{ fontSize: 24 }}>%</span>
          </strong>
          <small>
            {success} / {completed.length} loaded missions
          </small>
        </div>
      </div>
      <Charts />
      <p className="settings-note">
        Global annual totals were independently queried from Launch Library 2 on{" "}
        {formatDate(yearStats.fetchedAt, "UTC")} at{" "}
        {new Date(yearStats.fetchedAt).toISOString().slice(11, 16)} UTC and
        exclude suborbital flights. Charts below summarize the loaded mission
        sample. They are not complete annual country, agency or rocket
        statistics. Partial success is excluded from confirmed full-success
        counts.
      </p>
    </div>
  );
}
