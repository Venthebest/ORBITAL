import { getAgency } from "@/services/catalog-service";
import { AgencyDetail } from "@/features/catalog";
import { notFound } from "next/navigation";
import { snapshot } from "@/services/launch-service";
export function generateStaticParams() {
  return snapshot.agencies.map(({ id }) => ({ id }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const id = (await params).id;
  const a = await getAgency(id);
  return {
    title: a ? `${a.name} — Missions & Rocket Fleet` : "Agency not found",
  };
}
export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const id = (await params).id;
  const a = await getAgency(id);
  if (!a) notFound();
  return <AgencyDetail agency={a} />;
}
