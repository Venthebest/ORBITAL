"use client";
import * as Popover from "@radix-ui/react-popover";
import { CalendarDays, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
const key = (d: Date) => d.toISOString().slice(0, 10);
export function DatePicker({
  value,
  onChange,
  label,
}: {
  value: string;
  onChange: (s: string) => void;
  label: string;
}) {
  const [month, setMonth] = useState(
    () => new Date(value ? value + "T12:00:00Z" : Date.now()),
  );
  const first = new Date(
    Date.UTC(month.getUTCFullYear(), month.getUTCMonth(), 1),
  );
  const start = new Date(first);
  start.setUTCDate(start.getUTCDate() - ((start.getUTCDay() + 6) % 7));
  return (
    <Popover.Root>
      <Popover.Trigger asChild>
        <button className="picker">
          <CalendarDays size={14} />
          {value || label}
        </button>
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content className="popover date-picker" sideOffset={8}>
          <div className="mini-calendar-head">
            <button
              className="icon-button"
              aria-label="Previous month"
              onClick={() =>
                setMonth(
                  new Date(
                    Date.UTC(
                      month.getUTCFullYear(),
                      month.getUTCMonth() - 1,
                      1,
                    ),
                  ),
                )
              }
            >
              <ChevronLeft size={15} />
            </button>
            <span>
              {new Intl.DateTimeFormat("en", {
                month: "long",
                year: "numeric",
                timeZone: "UTC",
              }).format(month)}
            </span>
            <button
              className="icon-button"
              aria-label="Next month"
              onClick={() =>
                setMonth(
                  new Date(
                    Date.UTC(
                      month.getUTCFullYear(),
                      month.getUTCMonth() + 1,
                      1,
                    ),
                  ),
                )
              }
            >
              <ChevronRight size={15} />
            </button>
          </div>
          <div className="mini-calendar-grid">
            {["M", "T", "W", "T", "F", "S", "S"].map((s, i) => (
              <span key={i}>{s}</span>
            ))}
            {Array.from({ length: 42 }, (_, i) => {
              const d = new Date(start);
              d.setUTCDate(start.getUTCDate() + i);
              return (
                <Popover.Close asChild key={i}>
                  <button
                    aria-label={key(d)}
                    className={value === key(d) ? "selected" : ""}
                    style={{
                      opacity:
                        d.getUTCMonth() === month.getUTCMonth() ? 1 : 0.35,
                    }}
                    onClick={() => onChange(key(d))}
                  >
                    {d.getUTCDate()}
                  </button>
                </Popover.Close>
              );
            })}
          </div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}
