import { getLaunch, snapshot } from "@/services/launch-service";
export function generateStaticParams() {
  return snapshot.launches.map(({ id }) => ({ id }));
}
export async function GET(
  _: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const l = await getLaunch(id);
  return l
    ? Response.json(l, {
        headers: {
          "Cache-Control": "public,s-maxage=120,stale-while-revalidate=600",
        },
      })
    : Response.json({ error: "Mission not found" }, { status: 404 });
}
