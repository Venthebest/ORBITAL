"use client";
import Link from "next/link";
import { useState } from "react";
import * as Popover from "@radix-ui/react-popover";
import * as Switch from "@radix-ui/react-switch";
import {
  ChevronRight,
  Share2,
  CalendarPlus,
  Bell,
  Radio,
  ExternalLink,
  MapPin,
  Maximize2,
  Check,
  ArrowUpRight,
  Clock,
} from "lucide-react";
import { useOrbital, remindFor } from "@/components/app-provider";
import {
  Status,
  Countdown,
  FollowButton,
  SafeImage,
  Modal,
  SourceLink,
} from "@/components/ui";
import { shareLaunch } from "@/components/launch-card";
import { downloadICS, googleCalendarURL } from "@/lib/calendar";
import {
  hasExactTime,
  formatTime,
  formatDate,
  launchDate,
  zoneFor,
  isUpcoming,
} from "@/lib/time";
import type { Launch } from "@/types";
export function LaunchDetail({ launch: initial }: { launch: Launch }) {
  const {
      data,
      now,
      settings,
      t,
      toast,
      reminders,
      saveReminder,
      removeReminder,
    } = useOrbital(),
    l = data.launches.find((x) => x.id === initial.id) || initial,
    zone = zoneFor(settings, l);
  const [expanded, setExpanded] = useState(false),
    [remind, setRemind] = useState(false),
    [fullscreen, setFullscreen] = useState(false),
    [offset, setOffset] = useState(
      reminders.find((r) => r.launchId === l.id)?.offset ?? 60,
    ),
    [changes, setChanges] = useState(true);
  const near =
    l.net &&
    isUpcoming(l) &&
    Date.parse(l.net) - now < 86400000 &&
    Date.parse(l.net) - now > -21600000;
  const official = l.livestream.filter((v) => v.official),
    youtube = official.find((v) => v.url.includes("youtube.com/watch"));
  const videoID = youtube ? new URL(youtube.url).searchParams.get("v") : null;
  const reminder = reminders.find((r) => r.launchId === l.id);
  const save = () => {
    saveReminder(remindFor(l, offset, changes));
    setRemind(false);
  };
  return (
    <div className="page-container">
      <div className="breadcrumb">
        <Link href="/launches">{t("Launches")}</Link>
        <ChevronRight size={12} />
        <span>{l.mission.name}</span>
      </div>
      <section className="detail-hero">
        <div className="detail-hero-content">
          <div className="eyebrow">{l.agency.name} / MISSION BRIEFING</div>
          <h1>{l.mission.name}</h1>
          <p>
            {l.rocket.name} · {l.mission.type}
          </p>
          <div style={{ marginTop: 16 }}>
            <Status launch={l} />
          </div>
          <Countdown launch={l} />
          <div className="detail-actions">
            <FollowButton full type="launch" id={l.id} />
            <button
              className="icon-button"
              aria-label="Set reminder"
              onClick={() => setRemind(true)}
            >
              <Bell size={17} />
            </button>
            <CalendarMenu launch={l} />
            <button
              className="icon-button"
              aria-label="Share mission"
              onClick={() => shareLaunch(l, toast)}
            >
              <Share2 size={17} />
            </button>
            <button
              className="icon-button"
              aria-label="Fullscreen countdown"
              onClick={() => setFullscreen(true)}
            >
              <Maximize2 size={17} />
            </button>
          </div>
        </div>
        <div className="detail-hero-photo">
          <SafeImage src={l.image} alt={l.name} priority />
          <div className="photo-caption">Mission image · {l.imageSource}</div>
        </div>
        {l.patch && (
          <SafeImage
            src={l.patch}
            alt={l.mission.name + " mission patch"}
            className="detail-patch"
          />
        )}
      </section>
      <nav className="detail-tabs" aria-label="Mission sections">
        {[
          "Overview",
          "Timeline",
          "Rocket",
          "Payload",
          "Orbit",
          "Launch site",
          "Live",
          "Sources",
        ].map((label) => (
          <a href={"#" + label.toLowerCase().replace(" ", "-")} key={label}>
            {t(label)}
          </a>
        ))}
      </nav>
      <div className="detail-layout">
        <div>
          <section className="detail-section" id="overview">
            <h2>{t("Mission overview")}</h2>
            <p className={`overview-text ${expanded ? "" : "collapsed"}`}>
              {l.description ||
                "An official mission description has not been published. Check the source links for the latest details."}
            </p>
            {l.description.length > 500 && (
              <button
                className="text-link"
                onClick={() => setExpanded(!expanded)}
              >
                {expanded ? "Show less" : "Read full mission overview"}
                <ChevronRight size={14} />
              </button>
            )}
            <dl className="data-list" style={{ marginTop: 20 }}>
              <Fact label="Mission" value={l.mission.name} />
              <Fact label="Mission type" value={l.mission.type} />
              <Fact
                label="Provider"
                value={
                  <Link href={"/agency/" + l.agency.id}>{l.agency.name}</Link>
                }
              />
              <Fact label="Target orbit" value={l.mission.orbitName} />
            </dl>
          </section>
          <section className="detail-section" id="timeline">
            <h2>{t("Timeline")}</h2>
            <div className="timeline-note">
              Scheduled event sequence from Launch Library 2. These are planned
              milestones, not confirmed telemetry. Events remain unconfirmed
              until a verified source reports them.
            </div>
            {l.timeline.length ? (
              <div className="mission-timeline">
                {l.timeline.map((e) => (
                  <div className="mission-event" key={e.id}>
                    <i />
                    <div>
                      <strong>{e.name}</strong>
                      <p>{e.description}</p>
                    </div>
                    <small>
                      {e.time && hasExactTime(l)
                        ? formatTime(e.time, zone)
                        : "Time unconfirmed"}
                      <br />
                      SCHEDULED
                    </small>
                  </div>
                ))}
              </div>
            ) : (
              <p>
                A verified event timeline has not been published for this
                mission.
              </p>
            )}
          </section>
          <section className="detail-section" id="rocket">
            <h2>{t("Rocket")}</h2>
            <Link href={"/rocket/" + l.rocket.id} className="rocket-summary">
              <span>
                <strong>{l.rocket.name}</strong>
                <small>
                  {l.rocket.manufacturer} · {l.rocket.country}
                </small>
              </span>
              <ArrowUpRight size={20} />
            </Link>
            <p style={{ marginTop: 20 }}>
              {l.rocket.description ||
                "Vehicle specifications are available in the rocket directory when published by the data source."}
            </p>
          </section>
          <section className="detail-section" id="payload">
            <h2>{t("Payload")}</h2>
            {l.payloads.length ? (
              l.payloads.map((p) => (
                <div key={p.name}>
                  <h3>{p.name}</h3>
                  <p>{p.description}</p>
                </div>
              ))
            ) : (
              <>
                <p>{l.mission.name}</p>
                <p style={{ marginTop: 12 }}>
                  Payload details are described in the mission overview. No
                  independently structured payload manifest or payload mass has
                  been provided by the source.
                </p>
              </>
            )}
          </section>
          <section className="detail-section" id="orbit">
            <h2>{t("Target orbit")}</h2>
            <div className="orbit-visual">
              <svg
                viewBox="0 0 280 180"
                aria-label="Illustrative orbit schematic"
              >
                <circle
                  cx="140"
                  cy="90"
                  r="37"
                  stroke="var(--line-strong)"
                  fill="var(--surface)"
                />
                <line x1="0" y1="90" x2="280" y2="90" stroke="var(--line)" />
                <line x1="140" y1="0" x2="140" y2="180" stroke="var(--line)" />
                <ellipse
                  cx="140"
                  cy="90"
                  rx="118"
                  ry="58"
                  transform="rotate(-17 140 90)"
                  stroke="var(--accent)"
                  strokeWidth="1.2"
                  fill="none"
                />
                <circle cx="245" cy="54" r="3" fill="var(--accent)" />
                <text
                  x="140"
                  y="94"
                  fill="var(--muted)"
                  fontSize="9"
                  textAnchor="middle"
                >
                  EARTH
                </text>
              </svg>
              <span>SCHEMATIC · NOT A FLIGHT TRAJECTORY</span>
            </div>
            <dl className="data-list">
              <Fact label="Orbit" value={l.mission.orbitName} />
              <Fact label="Classification" value={l.orbit} />
            </dl>
          </section>
          <section className="detail-section" id="launch-site">
            <h2>{t("Launch site")}</h2>
            <p>{l.launchPad.name}</p>
            <p>{l.launchPad.location}</p>
            <dl className="data-list">
              <Fact
                label="Latitude"
                value={
                  l.launchPad.latitude !== null
                    ? l.launchPad.latitude.toFixed(5) + "°"
                    : "Not published"
                }
              />
              <Fact
                label="Longitude"
                value={
                  l.launchPad.longitude !== null
                    ? l.launchPad.longitude.toFixed(5) + "°"
                    : "Not published"
                }
              />
              <Fact label="Country" value={l.launchPad.country} />
              <Fact label="Time zone" value={l.launchPad.timezone} />
            </dl>
            <Link href={"/map?site=" + l.launchPad.id} className="text-link">
              <MapPin size={15} />
              View on global launch map
              <ArrowUpRight size={14} />
            </Link>
          </section>
          <section className="detail-section" id="live">
            <h2>{t("Live")} & mission coverage</h2>
            {official.length ? (
              <>
                <p>
                  Official mission broadcast. Stream availability is controlled
                  by the provider.
                </p>
                {videoID && /^[a-zA-Z0-9_-]{11}$/.test(videoID) && (
                  <iframe
                    className="stream-embed"
                    loading="lazy"
                    src={`https://www.youtube-nocookie.com/embed/${videoID}`}
                    title={youtube!.title}
                    allow="encrypted-media; picture-in-picture"
                    allowFullScreen
                  />
                )}
                <div className="stream-list">
                  {official.map((v) => (
                    <SourceLink url={v.url} key={v.url}>
                      <Radio size={15} />
                      {v.title}
                    </SourceLink>
                  ))}
                </div>
              </>
            ) : (
              <p>
                No verified official livestream has been announced. Check
                mission sources for coverage updates.
              </p>
            )}
            {l.livestream.some((v) => !v.official) && (
              <details style={{ marginTop: 20 }}>
                <summary
                  className="muted"
                  style={{ fontSize: 12, cursor: "pointer" }}
                >
                  Independent coverage (
                  {l.livestream.filter((v) => !v.official).length})
                </summary>
                <div className="stream-list">
                  {l.livestream
                    .filter((v) => !v.official)
                    .map((v) => (
                      <SourceLink key={v.url} url={v.url}>
                        {v.title} · unofficial
                      </SourceLink>
                    ))}
                </div>
              </details>
            )}
          </section>
          <section className="detail-section" id="sources">
            <h2>{t("Sources")}</h2>
            <p>
              Source links and confidence are preserved with each mission.
              Official updates take priority when verified.
            </p>
            <div className="source-list">
              {l.sources.map((s, i) => (
                <div className="source-item" key={s.sourceUrl + i}>
                  <div>
                    <SourceLink url={s.sourceUrl}>{s.name}</SourceLink>
                    <span className="source-priority">
                      {s.confidence.toUpperCase()} · P{s.sourcePriority}
                    </span>
                  </div>
                  <small>
                    {new URL(s.sourceUrl).hostname} · Updated{" "}
                    {formatDate(s.lastUpdated, "UTC")}{" "}
                    {formatTime(s.lastUpdated, "UTC")}
                  </small>
                </div>
              ))}
            </div>
            <p className="settings-note">
              Mission photographs are provided by the original sources. Their
              rights remain with their creators; consult the source before
              reusing an image.
            </p>
          </section>
        </div>
        <aside>
          {near && (
            <div className="live-module">
              <div className="live-module-head">
                <Radio size={15} />
                LIVE TRACKING MODE
              </div>
              <p>
                Monitoring published mission status. Countdown uses the latest
                confirmed launch time.
              </p>
              {l.latestUpdate && (
                <div className="latest-update">
                  <span className="eyebrow">LATEST SOURCE UPDATE</span>
                  <p>{l.latestUpdate.text}</p>
                  <span className="muted" style={{ fontSize: 10 }}>
                    {formatDate(l.latestUpdate.time, "UTC")} ·{" "}
                    {formatTime(l.latestUpdate.time, "UTC")}
                  </span>
                  {l.latestUpdate.sourceUrl && (
                    <div style={{ marginTop: 8 }}>
                      <SourceLink url={l.latestUpdate.sourceUrl}>
                        Read update
                      </SourceLink>
                    </div>
                  )}
                </div>
              )}
              <div className="live-no-telemetry">
                SOURCE UPDATES · NO REAL-TIME TELEMETRY
              </div>
              {official[0] && (
                <a
                  href={official[0].url}
                  target="_blank"
                  rel="noreferrer"
                  className="button primary"
                >
                  <Radio size={15} />
                  {t("Watch live")}
                  <ExternalLink size={14} />
                </a>
              )}
            </div>
          )}
          <div className="detail-info-box">
            <h3>Mission at a glance</h3>
            <dl className="data-list">
              <Fact label="Status" value={<Status launch={l} />} />
              <Fact label="Launch date" value={launchDate(l, zone)} />
              <Fact
                label="Launch time"
                value={
                  hasExactTime(l)
                    ? formatTime(l.net, zone)
                    : "Unconfirmed · " + l.precision
                }
              />
              <Fact
                label="Launch window"
                value={
                  hasExactTime(l) && l.windowStart
                    ? formatTime(l.windowStart, zone) +
                      " — " +
                      formatTime(l.windowEnd, zone)
                    : "Not precisely confirmed"
                }
              />
              <Fact
                label="Rocket"
                value={
                  <Link href={"/rocket/" + l.rocket.id}>{l.rocket.name}</Link>
                }
              />
              <Fact
                label="Provider"
                value={
                  <Link href={"/agency/" + l.agency.id}>{l.agency.name}</Link>
                }
              />
              <Fact label="Target orbit" value={l.orbit} />
              <Fact label="Country" value={l.launchPad.country} />
              <Fact
                label="Weather GO probability"
                value={
                  l.probability !== null
                    ? l.probability + "% (source forecast)"
                    : "Not published"
                }
              />
              <Fact
                label="Weather concerns"
                value={l.weather || "Not published"}
              />
              <Fact
                label="Last updated"
                value={
                  formatDate(l.lastUpdated, "UTC") +
                  " " +
                  formatTime(l.lastUpdated, "UTC")
                }
              />
            </dl>
            <button
              className="button secondary"
              style={{ width: "100%", marginTop: 20, fontSize: 12 }}
              onClick={() => setRemind(true)}
            >
              <Bell size={15} />
              {reminder ? "Manage reminder" : "Set a launch reminder"}
            </button>
            <p className="settings-note">
              All launch times are subject to change. Status updates follow
              source reports and may be delayed.
            </p>
          </div>
        </aside>
      </div>
      <Modal
        open={remind}
        onOpenChange={setRemind}
        title="Mission reminder"
        description={`${l.mission.name} · Stored on this device`}
      >
        <div className="reminder-options">
          {[
            { value: 1440, label: "1 day before" },
            { value: 360, label: "6 hours before" },
            { value: 60, label: "1 hour before" },
            { value: 10, label: "10 minutes before" },
            { value: 0, label: "At launch time" },
          ].map((o) => (
            <button
              key={o.value}
              className={offset === o.value ? "selected" : ""}
              aria-pressed={offset === o.value}
              onClick={() => setOffset(o.value)}
            >
              {o.label}
              {offset === o.value ? <Check size={16} /> : <Clock size={15} />}
            </button>
          ))}
        </div>
        <label className="toggle-row">
          <span>
            Launch time & status changes
            <small>Includes reported delays and holds.</small>
          </span>
          <Switch.Root
            checked={changes}
            onCheckedChange={setChanges}
            className="switch"
          >
            <Switch.Thumb className="switch-thumb" />
          </Switch.Root>
        </label>
        <p className="settings-note">
          Reminders are checked while ORBITAL is open. Calendar alarms can work
          when it is closed. Browser notifications require permission and
          browser support.
        </p>
        <button
          className="text-link"
          onClick={async () => {
            if ("Notification" in window) {
              const p = await Notification.requestPermission();
              toast(
                p === "granted"
                  ? "Browser notifications enabled"
                  : "Browser notifications are unavailable or blocked",
              );
            } else toast("Notifications are not supported in this browser");
          }}
        >
          Enable browser notifications
        </button>
        <div className="modal-actions">
          {reminder && (
            <button
              className="button ghost"
              onClick={() => {
                removeReminder(l.id);
                setRemind(false);
                toast("Reminder removed");
              }}
            >
              Remove
            </button>
          )}
          <button className="button primary" onClick={save}>
            Save reminder
          </button>
        </div>
      </Modal>
      <Modal
        fullscreen
        open={fullscreen}
        onOpenChange={setFullscreen}
        title={l.mission.name}
        description="Countdown to the currently published launch time."
      >
        <div style={{ padding: "35px 0" }}>
          <Countdown launch={l} />
          <div style={{ marginTop: 25 }}>
            <Status launch={l} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
function Fact({ label, value }: { label: string; value: React.ReactNode }) {
  const { t } = useOrbital();
  return (
    <div>
      <dt>{t(label)}</dt>
      <dd>{value}</dd>
    </div>
  );
}
function CalendarMenu({ launch: l }: { launch: Launch }) {
  const { toast } = useOrbital();
  return (
    <Popover.Root>
      <Popover.Trigger asChild>
        <button className="icon-button" aria-label="Add to calendar">
          <CalendarPlus size={18} />
        </button>
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content
          className="popover more-menu"
          sideOffset={8}
          align="start"
        >
          {hasExactTime(l) ? (
            <>
              <Popover.Close asChild>
                <button
                  className="button ghost"
                  onClick={() => {
                    downloadICS(l);
                    toast("Calendar file downloaded");
                  }}
                >
                  Apple Calendar / Outlook · .ics
                </button>
              </Popover.Close>
              <a href={googleCalendarURL(l)} target="_blank" rel="noreferrer">
                Google Calendar
                <ExternalLink size={14} />
              </a>
            </>
          ) : (
            <p style={{ padding: 12, fontSize: 12, maxWidth: 260 }}>
              Calendar export is available once a precise launch time is
              published.
            </p>
          )}
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}
