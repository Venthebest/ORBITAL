const CACHE = "orbital-a6e408cfbdff";
self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      await cache.addAll([
        "/",
        "/favicon.svg",
        "/earth-horizon.webp",
        "/world-map.svg",
        "/manifest.webmanifest",
        "/icon-192.png",
        "/fonts/dm-sans.ttf",
        "/fonts/manrope.ttf",
      ]);
      const home = await cache.match("/");
      const html = await home.text();
      const assets = [
        ...new Set(
          [
            ...html.matchAll(/(?:src|href)="([^" ]*\/_next\/static\/[^" ]+)"/g),
          ].map((match) => match[1]),
        ),
      ];
      await Promise.allSettled(
        assets.map(async (url) => {
          const response = await fetch(url);
          if (response.ok) await cache.put(url, response);
        }),
      );
      await self.skipWaiting();
    })(),
  );
});
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((key) => key !== CACHE).map((key) => caches.delete(key)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET" || url.origin !== self.location.origin)
    return;
  const store = (response) => {
    if (response.ok) {
      const copy = response.clone();
      event.waitUntil(
        caches.open(CACHE).then((cache) => cache.put(event.request, copy)),
      );
    }
    return response;
  };
  if (url.pathname.startsWith("/api/") || event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then(store)
        .catch(async () => {
          const cached = await caches.match(event.request);
          if (cached) return cached;
          if (event.request.mode === "navigate")
            return (
              (await caches.match("/")) ||
              new Response(
                "ORBITAL is offline. Visit a page online before using it offline.",
                { status: 503 },
              )
            );
          return new Response('{"error":"Offline"}', {
            status: 503,
            headers: { "Content-Type": "application/json" },
          });
        }),
    );
    return;
  }
  if (
    url.pathname.startsWith("/_next/static/") ||
    url.pathname.startsWith("/vendor/") ||
    /\.(jpg|webp|png|svg|geojson|ttf|webmanifest)$/.test(url.pathname)
  ) {
    event.respondWith(
      caches
        .match(event.request)
        .then((cached) => cached || fetch(event.request).then(store)),
    );
  }
});
