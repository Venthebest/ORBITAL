import type { Launch, UserSettings } from "@/types";
export function zoneFor(settings: UserSettings, launch?: Launch) {
  return settings.timezone === "utc"
    ? "UTC"
    : settings.timezone === "site" && launch
      ? launch.launchPad.timezone
      : undefined;
}
export function formatDate(
  value: string | null,
  zone?: string,
  options: Intl.DateTimeFormatOptions = {
    month: "short",
    day: "numeric",
    year: "numeric",
  },
) {
  if (!value) return "Date to be determined";
  return new Intl.DateTimeFormat("en-US", {
    ...options,
    timeZone: zone,
  }).format(new Date(value));
}
export function formatTime(value: string | null, zone?: string) {
  if (!value) return "TBD";
  return new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZoneName: "short",
    timeZone: zone,
  }).format(new Date(value));
}
export function dateKey(value: string | Date, zone?: string) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    timeZone: zone,
  }).formatToParts(new Date(value));
  const part = (type: string) => parts.find((p) => p.type === type)!.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}
export function hasExactTime(l: Launch) {
  return (
    !!l.net &&
    ["second", "minute"].includes(l.precision) &&
    !["tbd", "tbc", "hold", "cancelled", "delayed"].includes(l.status)
  );
}
export function launchDate(l: Launch, zone?: string) {
  if (!l.net) return "Date to be determined";
  const year = new Date(l.net).getUTCFullYear();
  if (l.precision === "quarter")
    return `NET Q${Math.floor(new Date(l.net).getUTCMonth() / 3) + 1} ${year}`;
  if (l.precision === "half-year")
    return `NET H${new Date(l.net).getUTCMonth() < 6 ? 1 : 2} ${year}`;
  if (l.precision === "week") return `NET week of ${formatDate(l.net, zone)}`;
  if (l.precision === "unknown" || l.precision === "decade")
    return l.precisionLabel === "Unconfirmed"
      ? "Target date unconfirmed"
      : `NET · ${l.precisionLabel}`;
  if (l.precision === "month")
    return `NET ${formatDate(l.net, zone, { month: "long", year: "numeric" })}`;
  if (l.precision === "year")
    return `NET ${formatDate(l.net, zone, { year: "numeric" })}`;
  return (hasExactTime(l) ? "" : "NET ") + formatDate(l.net, zone);
}
export function hasConfirmedDay(l: Launch) {
  return !!l.net && ["second", "minute", "hour", "day"].includes(l.precision);
}
export function calendarWeekRange(now: number, zone?: string) {
  const today = dateKey(new Date(now), zone),
    d = new Date(today + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
  const first = d.toISOString().slice(0, 10);
  d.setUTCDate(d.getUTCDate() + 6);
  return { start: first, end: d.toISOString().slice(0, 10) };
}
export function ago(value: string, now: number) {
  const m = Math.max(0, Math.floor((now - new Date(value).getTime()) / 60000));
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  if (m < 1440) return `${Math.floor(m / 60)}h ago`;
  return `${Math.floor(m / 1440)} days ago`;
}
export function countdown(l: Launch, now: number) {
  if (l.status === "hold") return "HOLD";
  if (["success", "failure", "partial-success"].includes(l.status))
    return l.status === "success" ? "MISSION COMPLETE" : "MISSION ENDED";
  if (l.status === "cancelled") return "CANCELLED";
  if (!hasExactTime(l))
    return l.status === "tbd"
      ? "TBD"
      : l.status === "tbc"
        ? "TBC · " + launchDate(l).replace(/^NET /, "")
        : launchDate(l);
  const d = new Date(l.net!).getTime() - now;
  if (d <= 0) return l.status === "in-flight" ? "IN FLIGHT" : "AWAITING UPDATE";
  const s = Math.floor(d / 1000);
  return `T−${String(Math.floor(s / 86400)).padStart(2, "0")}:${String(Math.floor((s % 86400) / 3600)).padStart(2, "0")}:${String(Math.floor((s % 3600) / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}
export function isUpcoming(l: Launch) {
  return !["success", "failure", "partial-success", "cancelled"].includes(
    l.status,
  );
}
export const statusLabel: Record<Launch["status"], string> = {
  scheduled: "Scheduled",
  tbc: "TBC",
  go: "Go for launch",
  tbd: "TBD",
  delayed: "Delayed",
  hold: "On hold",
  "in-flight": "In flight",
  success: "Success",
  failure: "Failure",
  "partial-success": "Partial success",
  cancelled: "Cancelled",
};
